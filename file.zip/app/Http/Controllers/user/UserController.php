<?php

namespace App\Http\Controllers\user;

use Illuminate\Http\Request;
use Auth;
use Session;
use DB;
use Crypt;
use Rule;
use Mail;

use Validator;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class UserController extends Controller
{ 
   



	
public function loginuser(Request $request){ 
 return view('user/login');
 }
  
  
  
    public function loginuserpost(Request $request)
    {
 

    	$this->validate($request,[
    			'email' => 'required',
    			'pass' => 'required'
    		],[
    			'email.required' => 'نام کاربری نامعتبر است',
    			'pass.required' => 'رمزعبور نامعتبر است',
    			
    		]);
    		
    		
    		}
  
  
	
public function paneluseruser(Request $request){ 
 return view('user/paneluser');
 }
   


	
public function userlogin(Request $request){



	Session::set('idlang', '3');
if (Session::has('idlang')){ } else {
$demolang=\DB::table('superadminselanats') ->where([['id', '=',  1],])->orderBy('id', 'desc')->first();		
Session::set('idlang', $demolang->supelan_demolang); }	
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();	
DB::table('statics')->insert([
    ['static_ip' => $request->ip() ,  'static_url' => $request->url() ,    'static_name' => "$lngmenu->lng_wlogus" ,   'static_createdatdate' =>  date('Y-m-d H:i:s') ]
]);
 return view('user/sign-in', ['lngmenus' => $lngmenus , 'lngmenu' => $lngmenu ]);


 
 //return redirect('/sign-in');
 
 }
   
 
 
	
    public function userloginpost(Request $request)
    {
  $lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();  	


    	$this->validate($request,[
    			'firstname' => 'required',
    			'lastname' => 'required'
    		],[
    			'firstname.required' => $lngmenu->lng_wusername.' ! '.$lngmenu->lng_wnotelq,
    			'lastname.required' => $lngmenu->lng_wpassword.' ! '.$lngmenu->lng_wnotelq,
    			
    		]);

$admins = DB::table('user')->where([
    ['user_username',  $request->firstname],
])->first();
if($admins){

$password_db= $admins->user_password; 
$decryptedPassword =  Crypt::decrypt($password_db);
$userscou = DB::table('user')->where([
    ['user_username',  $request->firstname],
])->count();
$id_db= $admins->id;
$activeadmin= $admins->user_active; 
$name_db= $admins->user_name; 
$username_db= $admins->user_username; 
$password_db= $admins->user_password; 
$username_log = $request->firstname; 
if(($username_log == $username_db)&&( $decryptedPassword == $request->lastname)){
	
	Session::set('iduser', $id_db);
	Session::set('signname', $name_db);
	Session::set('signuser', $username_db);
	Session::set('activeuser', $activeadmin);
	Session::set('idlang', '3');

$adminslp = \DB::table('user')->where('id', '=', $id_db)  ->orderBy('id', 'desc')->first();
$logindatepas=$adminslp->user_loginatdate;	

$admimg=$adminslp->user_img;
if(empty($admimg)){$admimg='user2x.png';}	
	Session::set('logindatepasus', $logindatepas);
	Session::set('usimg', $admimg);
	$updatee = \DB::table('user')->where('id', '=', Session::get('iduser'))  ->update(['user_loginatdate' => date('Y-m-d H:i:s') ,    'user_ip' => $request->ip()  ]); 
			return redirect('user/panel'); 
		} else 
			 $nametr = Session::flash('statust',  $lngmenu->lng_werrornot);
				return redirect('user/sign-in'); 	
			
}
		else if(empty($admins)) {
			 $nametr = Session::flash('statust',  $lngmenu->lng_werrornot);
				return redirect('user/sign-in'); 
		}
  }

	
	
			
			
public function paneluser(){
	if (Session::has('signuser')){ 

 

 $updatee = \DB::table('user')->where('id', '=', Session::get('iduser'))  ->update(['user_tellactive' => 1   ]);
	Session::set('idlang', '3');

	$admins = DB::table('user')->where([
    ['id',  Session::get('iduser')],
])->first();
$activeadmin= $admins->user_active; 
Session::set('activeuser', $activeadmin);

		if (Session::get('activeuser')==1){ 
		

	
$tickread = DB::table('user') 
->join('ticket', 'user.id', '=', 'ticket.tik_fromid')->where([
    ['ticket.tik_fromarou', '=', 4],
    ['ticket.tik_toarou', '=', 2],
    ['ticket.tik_fromid', '=', Session::get('iduser')],
    ['ticket.tik_fromsh', '=', 1],
    ['ticket.tik_fromread', '=', 0],])
    ->orderBy('ticket.id', 'desc')->count();
	Session::set('tickreaduser', $tickread);  


$elanread = DB::table('user') 
->join('ticket', 'user.id', '=', 'ticket.tik_toid')->where([
    ['ticket.tik_fromarou', '=', 1],
    ['ticket.tik_toarou', '=', 4],
    ['ticket.tik_toid', '=', Session::get('iduser')],
    ['ticket.tik_tosh', '=', 1],
    ['ticket.tik_toread', '=', 0],])
    ->orderBy('ticket.id', 'desc')->count();
	Session::set('elanreaduser', $elanread);  
	
 
	
 return view('user/panel'  , [  'admins' => $admins  ]); 
			
	 
	
				
			}	
else if (Session::get('activeuser')==0){    return redirect('user/activition'); }
else if (empty(Session::has('signuser'))){   return redirect('user/sign-in'); }
}
	}	
    

	
	public function paneluserid($id){
if (Session::has('signuser')){ 
$lngmenu=\DB::table('language') ->where([['id', '=',  $id],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->first();
	Session::set('idlang', $id);
return redirect('user/panel');}	
else{ return redirect('user/sign-in'); }
}
	

 
 

	public function usersignout(){	
	Session::forget('iduser');	
	Session::forget('signuser');
	Session::forget('signname');
	Session::forget('logindatepasus');
	Session::forget('usimg');
	Session::forget('activeuser');
	Session::forget('idimg');
	Session::forget('tickreaduser');

		return redirect('/');
		}
			 
	
			
		 
	public function editprofiledetcharge($id){
if (Session::has('signuser')){  


  

$admins = \DB::table('user') 
->join('marsole', 'user.user_ncode', '=', 'marsole.mar_codmoshtari')  
->join('finicals', 'marsole.id', '=', 'finicals.finical_marid')  
->where([  
    ['finicals.id', '=', $id] ,  
    ['finicals.finical_iduser', '=', Session::get('iduser')],
    ['finicals.finical_payment', '=', 1], 
    ['finicals.finical_arou', '=', '4'] , ])
    ->orderBy('finicals.id', 'desc')->get();


 

$getwaypays=\DB::table('getwaypay')->where('getway_active', '=', 1)   ->orderBy('id' )->get();
 
 return view('user.detcharge' , [ 'admins' => $admins  , 'getwaypays' => $getwaypays     ]);

 

} else{ return redirect('user/sign-in'); }
				}
   	 
	
			
		 
	public function editprofileusercharge(){
if (Session::has('signuser')){  



//mycharge 
$charges = \DB::table('user') 
->join('charge', 'user.id', '=', 'charge.charge_iduser') 
->join('finicals', 'charge.charge_finical', '=', 'finicals.id') 
->where([
    ['charge.charge_arou', '=', 4],
    ['charge.charge_iduser', '=', Session::get('iduser')],
    ['finicals.finical_payment', '=', 1],
    ['finicals.finical_inc', '=', 5],])
    ->orderBy('charge.charge_id', 'desc')->get();
$chargepaymy=0;
foreach($charges as $charge){ $chargepaymy=$charge->charge_pay+$chargepaymy; }




 //supcharge  
$charges = \DB::table('user') 
->join('charge', 'user.id', '=', 'charge.charge_iduser')  
->join('finicals', 'charge.charge_finical', '=', 'finicals.id') 
->where([
    ['charge.charge_arou', '=', 4],
    ['charge.charge_iduser', '=', Session::get('iduser')],
    ['finicals.finical_payment', '=', 1],
    ['finicals.finical_inc', '=', 6],])
    ->orderBy('charge.charge_id', 'desc')->get();
$chargepaysup=0;
foreach($charges as $charge){ $chargepaysup=$charge->charge_pay+$chargepaysup; }



 //odat  
$charges = \DB::table('user') 
->join('charge', 'user.id', '=', 'charge.charge_iduser')  
->join('finicals', 'charge.charge_finical', '=', 'finicals.id') 
->where([
    ['charge.charge_arou', '=', 4],
    ['charge.charge_iduser', '=', Session::get('iduser')],
    ['finicals.finical_payment', '=', 1],
    ['finicals.finical_inc', '=', 7],])
    ->orderBy('charge.charge_id', 'desc')->get();
$chargepayodat=0;
foreach($charges as $charge){ $chargepayodat=$charge->charge_pay+$chargepayodat; }



//pardakht 
$charges = \DB::table('user') 
->join('charge', 'user.id', '=', 'charge.charge_iduser')  
->join('finicals', 'charge.charge_finical', '=', 'finicals.id') 
->where([
    ['charge.charge_arou', '=', 4],
    ['charge.charge_iduser', '=', Session::get('iduser')],
    ['finicals.finical_payment', '=', 1],
    ['finicals.finical_inc', '=', 3],])
    ->orderBy('charge.charge_id', 'desc')->get();
$chargepaypar=0;
foreach($charges as $charge){ $chargepaypar=$charge->charge_pay+$chargepaypar; }




 //bisinis  
$charges = \DB::table('user') 
->join('charge', 'user.id', '=', 'charge.charge_iduser')  
->join('finicals', 'charge.charge_finical', '=', 'finicals.id') 
->where([
    ['charge.charge_arou', '=', 4],
    ['charge.charge_iduser', '=', Session::get('iduser')],
    ['finicals.finical_payment', '=', 1],
    ['finicals.finical_inc', '=', 8],])
    ->orderBy('charge.charge_id', 'desc')->get();
$chargepaybisi=0;
foreach($charges as $charge){ $chargepaybisi=$charge->charge_pay+$chargepaybisi; }


//jamkol
$chargepay= ($chargepaysup +  $chargepaymy  + $chargepaybisi ) -  ($chargepaypar + $chargepayodat) ;
 

 

$chargeac=$chargepay;



 

$chargesas = \DB::table('user') 
->join('charge', 'user.id', '=', 'charge.charge_iduser')  
->join('finicals', 'charge.charge_finical', '=', 'finicals.id') 
->where([
    ['charge.charge_arou', '=', 4],
    ['charge.charge_iduser', '=', Session::get('iduser')],
    ['finicals.finical_payment', '=', 1], 
    ['finicals.finical_inc', '<>', 0],])
    ->orderBy('charge.charge_id', 'desc')->get();



return view('user.viewscharge', [  'chargesas' => $chargesas  ,'chargeac' => $chargeac ]); 






		 }	
else{ return redirect('user/sign-in'); }
				}
   	 
		
		
	public function inccharge(){
if (Session::has('signuser')){ 
		
$admins='0';

return view('user.inccharge', ['admins' => $admins   ]);	
		 }	
else{ return redirect('user/sign-in'); }
				}
   	 
		
	public function incchargepost(Request $request){
if (Session::has('signuser')){ 


    	$this->validate($request,[
    			'tit' => 'required|numeric' 
    		],[
    			'tit.required' => 'لطفا مبلغ شارژ را وارد نمایید',
    			'tit.numeric' => 'مبلغ شارژ نامعتبر است', 
    		]);
    	if ($request->tit < 1000){
			
  return redirect('user/inccharge');
		}

DB::table('finicals')->insert([
    ['finical_pay' => $request->tit ,     'finical_createdatdate' =>  date('Y-m-d H:i:s') , 'finical_inc' => 5 , 'finical_payment' => 0 ,  'finical_arou' => 4 ,  'finical_iduser' => Session::get('iduser')  ]
]);

$chargefinical=\DB::table('finicals') ->where([['finical_inc', '=',  5 ],['finical_arou', '=',  4 ],['finical_iduser', '=',  Session::get('iduser')],])->orderBy('id', 'desc')->first();	
		    	
DB::table('charge')->insert([
    ['charge_pay' => $request->tit ,     'charge_createdatdate' =>  date('Y-m-d H:i:s') , 'charge_arou' => 4 ,  'charge_iduser' => Session::get('iduser') ,  'charge_finical' => $chargefinical->id  ]
]);	    	

 
  return redirect('zarinpal/epayo.php?id='.$chargefinical->id.'');
 


		 }	
else{ return redirect('user/sign-in'); }
				}
   	 
		 
	public function editprofileuser(){
if (Session::has('signuser')){ 
  $lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();  	

$admins = \DB::table('user')->where('id', '=', Session::get('iduser'))  ->orderBy('id', 'desc')->get();
$user = \DB::table('user')->where('id', '=', Session::get('iduser'))  ->orderBy('id', 'desc')->first();
$admimg=$user->user_img;
if(empty($admimg)){$admimg='user2x.png';}	
	Session::set('usimg', $admimg);
	Session::set('activeuser', $user->user_active);
 




return view('user.myprofile', ['admins' => $admins , 'lngmenus' => $lngmenus , 'lngmenu' => $lngmenu     ]); }	
else{ return redirect('user/sign-in'); }
				}
   




		
	public function editprofileuserPost( Request $request ){
if (Session::has('signuser')){ 

 
$this->validate($request,[
    			'name' => 'required|min:3|max:35', 
    			'tell' => 'required|numeric',
    			'email' => 'required|email',
    			'adres' => 'required|min:3|max:555'
    		],[
    			'name.required' => 'نام و نام خانوادگی را وارد نمایید',
    			'name.min' => 'نام کوتاه است',
    			'name.max' => 'نام غیقابل قبول',
    			'tell.required' => 'شماره تلفن را بصورت صحیح وارد کنید',
    			'tell.numeric' => 'شماره غیرقابل قبول است',
    			'email.required' => 'ایمیل را بصورت صحیح وارد کنید',
    			'email.email' => 'فرمت ایمیل غیرقابل قبول است',
    			'adres.required' => 'آدرس را بصورت صحیح وارد کنید',
    			'adres.min' => 'دآدرس کوتاه است',
    			'adres.max' => 'آدرس خیلی بلند است',
    			
    		]);

 


$user = \DB::table('user')->where('id', '=', Session::get('iduser'))  ->orderBy('id', 'desc')->first();

 		if ( $request->email ==  $user->user_email   ){  $activeemail =  $user->user_emailactive ; }
 else   if ( $request->email !=  $user->user_email   ){  $activeemail ='0';}
 
 
$updatee = \DB::table('user')->where('id', '=', Session::get('iduser'))  ->update(['user_name' => $request->name   ,  'user_tell' => $request->tell ,  'user_email' => $request->email ,  'user_adres' => $request->adres,  'user_emailactive' => $activeemail ,  'user_tellactive' => 1 ]); 

$user = \DB::table('user')->where('id', '=', Session::get('iduser'))  ->orderBy('id', 'desc')->first();
if ( ($user->user_emailactive == 1) &&  ($user->user_tellactive == 1)   ){  $active=1;}
if ( ($user->user_emailactive == 0) ||  ($user->user_tellactive == 0)   ){  $active=0;}
$updatee = \DB::table('user')->where('id', '=', Session::get('iduser'))  ->update(['user_active' => $active   ]);

$admins = \DB::table('user')->where('id', '=', Session::get('iduser'))  ->orderBy('id', 'desc')->get();
$nametr = Session::flash('statust',  'ویرایش پروفایل من باموفقیت انجام شد');
$nametrt = Session::flash('sessurl', 'myprofile/edit');
 return view('user.success' ); 
}	else{ return redirect('user/sign-in'); }
}
		




 
 
   
   
   
 

public function dropzoneStoreuserprofile(Request $request)
    {
        $image = $request->file('file');
        $imageName = time().$image->getClientOriginalName();
        $image->move(public_path('images'),$imageName);        
$updatee = \DB::table('user')->where('id', '=', Session::get('iduser'))  ->update(['user_img' => $imageName   ]);
        return response()->json(['success'=>$imageName]);
    }
		    

		
		
	public function securityuserprofile( Request $request ){
if (Session::has('signuser')){ 
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();
  	$this->validate($request,[
    			'userpassword' => 'required|min:5|max:35|confirmed',
    			'tell' => 'required',
    			'email' => 'required',
    		],[
    			'userpassword.required' => 'لطفا رمز ورود را وارد نمایید',
    			'userpassword.min' => ' رمز کوتاه است',
    			'userpassword.max' => ' رمزعبور طولانی است ',
    			'userpassword.confirmed' => 'رمزعبور با تکرار آن مطابقت ندارد ',
    			'tell.required' => 'دقت نمایید تا زمانی که شماره تلفن شما ثبت نشده باشد شما نمی توانید رمز خود را تغییر دهید',
    			'email.required' => 'دقت نمایید تا زمانی که ایمیل شما ثبت نشده باشد شما نمی توانید رمز خود را تغییر دهید',
    		]);
 
$encryptedPassword =  Crypt::encrypt($request->userpassword);
$decryptedPassword =  Crypt::decrypt($encryptedPassword);

$updatee = \DB::table('user')->where('id', '=', Session::get('iduser'))  ->update(['user_password' => $encryptedPassword   ]); 

$admins = \DB::table('user')->where('id', '=',  Session::get('iduser'))  ->orderBy('id', 'desc')->first();
 
$nametr = Session::flash('statust', 'رمزعبور باموفقیت تغییر کرد');
$nametrt = Session::flash('sessurl', 'myprofile/edit');
   	
$user = \DB::table('user')->where('id', '=', Session::get('iduser'))  ->orderBy('id', 'desc')->first();

$superadminselanats =  DB::table('superadminselanats')  ->orderBy('id', 'desc')->first(); 
 
 		

 return view('user.success' ); 

}	
else{ return redirect('user/sign-in'); }
				}
		





	public function webservicemyuser(){
	if (Session::has('signuser')){ 
		if (Session::get('activeuser')==1){ 
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();
 

$adminss = \DB::table('mngindex') ->where('id', '=', '1')->orderBy('id', 'desc')->get();	
$admins = \DB::table('user')->where('id', '=', Session::get('iduser'))  ->orderBy('id', 'desc')->get();

return view('user.webserviceuser', ['admins' => $admins , 'adminss' => $adminss ,  'lngmenus' => $lngmenus , 'lngmenu' => $lngmenu ]);


}	else if (Session::get('activeuser')==0){    return redirect('user/activition'); }
else if (empty(Session::has('signstudent'))){   return redirect('user/sign-in'); } }
}		







	public function webservicemyuserpost(){
	if (Session::has('signuser')){ 
		if (Session::get('activeuser')==1){ 
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();
 

$characters_on_image = 24;  
$possible_letters = '1234567890abcdefghigklmnopqrstuvwxyz';
$code = '';
$i = 0;
while ($i < $characters_on_image) { 
$code .= substr($possible_letters, mt_rand(0, strlen($possible_letters)-1), 1);
$i++;
}
		
$updatee = \DB::table('user')->where('id', '=', Session::get('iduser') )  ->update(['user_api' => $code   ]);   
$nametr = Session::flash('statust',  $lngmenu->lng_wsuccess);
$nametrt = Session::flash('sessurl', 'myprofile/webservice');		  	
 return view('user.success', ['lngmenus' => $lngmenus , 'lngmenu' => $lngmenu ]); 

}	else if (Session::get('activeuser')==0){    return redirect('user/activition'); }
else if (empty(Session::has('signstudent'))){   return redirect('user/sign-in'); } }
}		











	
			
public function activitionuser(){
if (Session::has('signuser')){ 
 
$admins = \DB::table('user') ->where('id', '=', Session::get('iduser'))   ->orderBy('id', 'desc')->get();
return view('user.activition', [ 'admins' => $admins   ]);
}	 else{ return redirect('user/sign-in'); }
}



  
 
		
	public function emailuseractivitionverfy( Request $request ){
if (Session::has('signuser')){ 
 
    	$this->validate($request,[
    			'email' => 'required',
    		],[
    			'email.required' => 'پر کردن فیلد ایمیل اجباری است ',
    		]);  		
 $rnd=rand(1, 99999);    		
$updatee = \DB::table('user')->where('id', '=', Session::get('iduser'))  ->update(['user_emailverfy' => $rnd   ]); 
$admins = \DB::table('user')->where('id', '=',  Session::get('iduser'))  ->orderBy('id', 'desc')->first();
			$nametr = Session::flash('statust', 'کد وریفای ایمیل باموفقیت به ایمیل من ارسال شد');
		  	$nametrt = Session::flash('sessurl', 'activition');		  	
$user = \DB::table('user')->where('id', '=', Session::get('iduser'))  ->orderBy('id', 'desc')->first();
 	 $usernamee = $user->user_username; 
 $titmes = 'ارسال کد فعالسازی به ایمیل من';
 $mestt = 'کد فعالسازی';
 $mesnot =  $user->user_emailverfy ; 
   Mail::send('superadmin.mail', ['user' => $user , 'usernamee' => $usernamee, 'mesnot' => $mesnot, 'titmes' => $titmes , 'mestt' => $mestt], function ($m) use ($user) {
         $m->from('info@info.com', 'کد فعالسازی ایمیل');
            $m->to($user->user_email, $user->user_email)->subject('کد فعالسازی ایمیل');
        }); 	
return view('user.success' );
}	
else{ return redirect('user/sign-in'); }
}
		  
   
   
   

		
		
		
		
		
	public function emailuseractivition( Request $request ){
if (Session::has('signuser')){ 

 $lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first(); 
$slngmenu=\DB::table('languages') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();	
    	$this->validate($request,[
    			'codemail' => 'required',
    		],[
    			'codemail.required' => $lngmenu->lng_wcodeactive.' ! '.$lngmenu->lng_wnotelq,
    		]);
$user = \DB::table('user')->where('id', '=', Session::get('iduser'))  ->orderBy('id', 'desc')->first();      
if ( $request->codemail ==  $user->user_emailverfy   ){  
$updatee = \DB::table('user')->where('id', '=', Session::get('iduser'))  ->update(['user_emailactive' => 1   ]);

$user = \DB::table('user')->where('id', '=', Session::get('iduser'))  ->orderBy('id', 'desc')->first();
if ( ($user->user_emailactive == 1) &&  ($user->user_tellactive == 1)   ){  $active=1;


$superadminselanats =  DB::table('superadminselanats')  ->orderBy('id', 'desc')->first();
 if($superadminselanats->supelan_emailaccuser == '1'){
 $usernamee = $user->user_username; 
 $titmes=$lngmenu->lng_wactivedon;
 $mestt=$lngmenu->lng_wpassword;
 $mesnot = Crypt::decrypt($user->user_password); 
   Mail::send('superadmin.mail', ['user' => $user , 'usernamee' => $usernamee, 'mesnot' => $mesnot, 'titmes' => $titmes , 'mestt' => $mestt], function ($m) use ($user) {
        
$decryptedPassword =  Crypt::decrypt($user->user_password);

            $m->from('info@site.com', 'فعالسازی');

            $m->to($user->user_email, $user->user_email)->subject('Account activation');
        }); 	
 }	 	
 
 	
 if($superadminselanats->supelan_smsaccuser == '1'){	
   
$admins = \DB::table('user')->where('id', '=',  Session::get('iduser'))  ->orderBy('id', 'desc')->first();
$panelsms = \DB::table('panelsms')->where('id', '=',  1)  ->orderBy('id', 'desc')->first();
include(app_path().'/../sms/api_send_sms.php');
$message=$lngmenu->lng_whi.' '.$admins->user_name.' '.$lngmenu->lng_wactivedon  .' ';
$result = Send_SMS($panelsms->sms_username, $panelsms->sms_password, $panelsms->sms_fromnumber, $admins->user_tell, $message , 0, false) ; }

}
if ( ($user->user_emailactive == 0) ||  ($user->user_tellactive == 0)   ){  $active=0;}
$updatee = \DB::table('user')->where('id', '=', Session::get('iduser'))  ->update(['user_active' => $active   ]);
Session::set('activeuser', $active);	


$admins = \DB::table('user')->where('id', '=',  Session::get('iduser'))  ->orderBy('id', 'desc')->first();
$nametr = Session::flash('statust', $slngmenu->lng_wactiveemailsuc );
$nametrt = Session::flash('sessurl', 'activition');		  	
$user = \DB::table('user')->where('id', '=', Session::get('iduser'))  ->orderBy('id', 'desc')->first();
$usernamee = $user->user_username; 
 $titmes=$slngmenu->lng_wactiveemailsuc ;
 $mestt=' ';
 $mesnot = ' ';
   Mail::send('superadmin.mail', ['user' => $user , 'usernamee' => $usernamee, 'mesnot' => $mesnot, 'titmes' => $titmes , 'mestt' => $mestt], function ($m) use ($user) {
$m->from('info@site.com', 'فعالسازی');
$m->to($user->user_email, $user->user_email)->subject('Email activation');
}); 	
return view('user.success', [  'lngmenus' => $lngmenus , 'lngmenu' => $lngmenu , 'slngmenu' => $slngmenu ]);
}			 
 else   if ( $request->codemail !=  $user->user_emailverfy   ){  
$nametr = Session::flash('statust',   $slngmenu->lng_wcodeactiveerror );
$nametrt = Session::flash('sessurl', 'activition');	
return view('user.error', [  'lngmenus' => $lngmenus , 'lngmenu' => $lngmenu , 'slngmenu' => $slngmenu   ]);
 }
else if (empty(Session::has('signuser'))){ return redirect('user/sign-in'); }
}
}












		
	public function telluseractivitionverfy( Request $request ){
if (Session::has('signuser')){ 
 $lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first(); 
$slngmenu=\DB::table('languages') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();	
    	$this->validate($request,[
    			'tell' => 'required',
    		],[
    			'tell.required' => $lngmenu->lng_wtell.' ! '.$lngmenu->lng_wnotelq,
    		]);  		
 $rnd=rand(1, 99999);    		
$updatee = \DB::table('user')->where('id', '=', Session::get('iduser'))  ->update(['user_tellverfy' => $rnd   ]); 
$admins = \DB::table('user')->where('id', '=',  Session::get('iduser'))  ->orderBy('id', 'desc')->first();


$panelsms = \DB::table('panelsms')->where('id', '=',  1)  ->orderBy('id', 'desc')->first();

include(app_path().'/../sms/api_send_sms.php');
$message=$lngmenu->lng_whi.' '.$admins->user_name.' '.$lngmenu->lng_wcodeactive  .':'.$rnd.'';
if (($result = Send_SMS($panelsms->sms_username, $panelsms->sms_password, $panelsms->sms_fromnumber, $admins->user_tell, $message , 0, false)) === '0')
{ 
			 $nametr = Session::flash('statust', $slngmenu->lng_wsendverfytellsuc);
		  	$nametrt = Session::flash('sessurl', 'activition');	 
		  	return view('user.success', [  'lngmenus' => $lngmenus , 'lngmenu' => $lngmenu , 'slngmenu' => $slngmenu  ]);		  	
 
} else if ($result !== '') {   
			 $nametr = Session::flash('statust',$lngmenu->lng_werror);
		  	$nametrt = Session::flash('sessurl', 'activition');
		  	  
		  	 return view('user.error', [  'lngmenus' => $lngmenus , 'lngmenu' => $lngmenu , 'slngmenu' => $slngmenu  ]);
 }



        
		  	return view('user.success', [  'lngmenus' => $lngmenus , 'lngmenu' => $lngmenu , 'slngmenu' => $slngmenu   ]);	
}	
else{ return redirect('user/sign-in'); }
}
		
			
		



		
	public function telluseractivition( Request $request ){
if (Session::has('signuser')){ 
 $lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first(); 
$slngmenu=\DB::table('languages') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();	

    	$this->validate($request,[
    			'codtell' => 'required',
    		],[
    			'codtell.required' => $lngmenu->lng_wtell.' ! '.$lngmenu->lng_wnotelq,
    		]);
$user = \DB::table('user')->where('id', '=', Session::get('iduser'))  ->orderBy('id', 'desc')->first();      
if ( $request->codtell ==  $user->user_tellverfy   ){  
$updatee = \DB::table('user')->where('id', '=', Session::get('iduser'))  ->update(['user_tellactive' => 1   ]);
$user = \DB::table('user')->where('id', '=', Session::get('iduser'))  ->orderBy('id', 'desc')->first();
if ( ($user->user_emailactive == 1) &&  ($user->user_tellactive == 1)   ){  $active=1;



$superadminselanats =  DB::table('superadminselanats')  ->orderBy('id', 'desc')->first();
 if($superadminselanats->supelan_emailaccuser == '1'){
 $usernamee = $user->user_username; 
 $titmes=$lngmenu->lng_wactivedon;
 $mestt=$lngmenu->lng_wpassword;
 $mesnot = Crypt::decrypt($user->user_password); 
   Mail::send('superadmin.mail', ['user' => $user , 'usernamee' => $usernamee, 'mesnot' => $mesnot, 'titmes' => $titmes , 'mestt' => $mestt], function ($m) use ($user) {
        
$decryptedPassword =  Crypt::decrypt($user->user_password);

            $m->from('info@site.com', 'Account activation');

            $m->to($user->user_email, $user->user_email)->subject('Account activation');
        }); 	
 }	 	
 
 	
 if($superadminselanats->supelan_smsaccuser == '1'){	
   
$admins = \DB::table('user')->where('id', '=',  Session::get('iduser'))  ->orderBy('id', 'desc')->first();
$panelsms = \DB::table('panelsms')->where('id', '=',  1)  ->orderBy('id', 'desc')->first();
include(app_path().'/../sms/api_send_sms.php');
$message=$lngmenu->lng_whi.' '.$admins->user_name.' '.$lngmenu->lng_wactivedon  .' ';
$result = Send_SMS($panelsms->sms_username, $panelsms->sms_password, $panelsms->sms_fromnumber, $admins->user_tell, $message , 0, false) ; }


}
if ( ($user->user_emailactive == 0) ||  ($user->user_tellactive == 0)   ){  $active=0;}
$updatee = \DB::table('user')->where('id', '=', Session::get('iduser'))  ->update(['user_active' => $active   ]);
Session::set('activeuser', $active);	
$admins = \DB::table('user')->where('id', '=',  Session::get('iduser'))  ->orderBy('id', 'desc')->first();
$nametr = Session::flash('statust', $slngmenu->lng_wactivetellsuc );
$nametrt = Session::flash('sessurl', 'activition');		  	
$user = \DB::table('user')->where('id', '=', Session::get('iduser'))  ->orderBy('id', 'desc')->first();
$usernamee = $user->user_username; 
 $titmes=$slngmenu->lng_wactivetellsuc;
 $mestt=' ';
 $mesnot = ' ';
 
 
 
 /*
   Mail::send('superadmin.mail', ['user' => $user , 'usernamee' => $usernamee, 'mesnot' => $mesnot, 'titmes' => $titmes , 'mestt' => $mestt], function ($m) use ($user) {
$m->from('info@site.com', 'فعالسازی ایمیل');
$m->to($user->admin_email, $user->admin_email)->subject('ایمیل فعال شد');
}); 
*/



	
	return view('user.success', [  'lngmenus' => $lngmenus , 'lngmenu' => $lngmenu  , 'slngmenu' => $slngmenu ]);
}			 
 else   if ( $request->codtell !=  $user->user_tellverfy   ){  
$nametr = Session::flash('statust',   $slngmenu->lng_wcodeactiveerror );
$nametrt = Session::flash('sessurl', 'activition');	
	return view('user.error', [  'lngmenus' => $lngmenus , 'lngmenu' => $lngmenu  , 'slngmenu' => $slngmenu ]);
 }
else if (empty(Session::has('signuser'))){ return redirect('user/sign-in'); }
}
}



				
	public function addsefareshuser(){
	if (Session::has('signuser')){ 
		if (Session::get('activeuser')==1){ 



$users =  \DB::table('user')->where('id', '=', Session::get('iduser'))  ->orderBy('id', 'desc')->first();
$showadres=$users->user_showadres;
if($showadres=='0'){   return redirect('user/buyadresturkey'); } else {


$admins =  \DB::table('user')->where('id', '=', Session::get('iduser'))  ->orderBy('id', 'desc')->first();
$mngindexs = \DB::table('mngindex') ->where('id', '=', '1')->orderBy('id', 'desc')->first();
$creditcards = \ DB::table('creditcard')->where('crd_active', '=', '1')->get();
return view('user.addproduct', ['admins' => $admins , 'mngindexs' => $mngindexs  , 'creditcards' => $creditcards   ]);



	
}


 
}	else if (Session::get('activeuser')==0){    return redirect('user/activition'); }
else if (empty(Session::has('signuser'))){   return redirect('user/sign-in'); } }
		}			   
   


				
	public function regcredit(){
	if (Session::has('signuser')){ 
		if (Session::get('activeuser')==1){ 

$users =  \DB::table('user')->where('id', '=', Session::get('iduser'))  ->orderBy('id', 'desc')->first();
$showadres=$users->user_showadres;
if($showadres=='0'){   return redirect('user/buyadresturkey'); } else {


$admins =  \DB::table('user')->where('id', '=', Session::get('iduser'))  ->orderBy('id', 'desc')->first();
$mngindexs = \DB::table('mngindex') ->where('id', '=', '1')->orderBy('id', 'desc')->first();
$creditcards = \ DB::table('creditcard')->where('crd_active', '=', '1')->get();


return view('user.regcredit', ['admins' => $admins , 'mngindexs' => $mngindexs  , 'creditcards' => $creditcards   ]);

}
 
}	else if (Session::get('activeuser')==0){    return redirect('user/activition'); }
else if (empty(Session::has('signuser'))){   return redirect('user/sign-in'); } }
		}			   
   




				
	public function regcreditpost(Request $request){
	if (Session::has('signuser')){ 
		if (Session::get('activeuser')==1){ 




$this->validate($request,[
    			'name' => 'required',
    			'typcredcard' => 'required',
    			'des' => 'required', 
    		],[  
    			'name.required' => 'لطفا نام مرسوله را وارد نمایید',  
    			'typcredcard.required' => 'لطفا کردیت کارت را انتخاب نمایید',   
    			'des.required' => 'لطفا توضیحات سفارش را وارد نمایید',      
    			
    		]);
  
if($request->typcredcard=='0'){  $idcredcard=0; $creditcardspay=0; } elseif($request->typcredcard!='0') { $idcredcard=$request->typcredcard; 
$creditcardcounts = \ DB::table('creditcard')->where([ 
    ['creditcard.id', '=', $idcredcard] ,
    ['creditcard.id', '<>', '0' ] ,])
    ->orderBy('creditcard.id', 'desc')->count(); 
    if($creditcardcounts=='0'){ $creditcardspay=0; } else {
		 
$creditcards = \ DB::table('creditcard')->where([ 
    ['creditcard.id', '=', $idcredcard] ,
    ['creditcard.id', '<>', '0' ] ,])
    ->orderBy('creditcard.id', 'desc')->first();   $creditcardspay=$creditcards->crd_price;
		
	} 
    
    
    
    }    		

 
$admins =  \DB::table('user')->where('id', '=', Session::get('iduser'))  ->orderBy('id', 'desc')->first();
$codmoshtari=$admins->user_ncode;
 
  $arobuy='2';       

  
 
DB::table('marsole')->insert([
    ['mar_name'  =>  $request->name   ,'mar_fiziki'  =>  '1' ,'mar_credcard'  => $idcredcard ,'mar_codmoshtari'  =>   $codmoshtari,'mar_paycredit'  =>   $creditcardspay ,'mar_des'  =>  $request->des   ,'mar_status'  =>  '1'   ,'mar_crdflg'  =>  '1'   ,'mar_arobuy'  =>  $arobuy  , 'mar_createdatdate'  =>   date('Y-m-d H:i:s')     ]
]); 

$marsoles =  \DB::table('marsole')->where('mar_codmoshtari', '=', $codmoshtari)  ->orderBy('id', 'desc')->first();
$marsolesid=$marsoles->id;  

 

DB::table('finicals')->insert([
    ['finical_marid' => $marsolesid ,  'finical_pay' => $creditcardspay ,    'finical_createdatdate' => date('Y-m-d H:i:s') ,   'finical_inc' =>  '3' ,   'finical_iduser' =>  Session::get('iduser') ,   'finical_arou' =>  '4' ,   'finical_marpay' =>  '1' ]
]); 



 	
$nametr = Session::flash('statust', 'سفارش خرید کریدت کارت شما با موفقیت ثبت شد. ');
$nametrt = Session::flash('sessurl', 'viewssefaresh');
		  return view('user.success'); 
  


 
 
}	else if (Session::get('activeuser')==0){    return redirect('user/activition'); }
else if (empty(Session::has('signuser'))){   return redirect('user/sign-in'); } }
		}			   
   




	
	public function addsefareshuserpost(Request $request){
	if (Session::has('signuser')){ 
		if (Session::get('activeuser')==1){ 



$this->validate($request,[
    			'name' => 'required',
    			'usernamee' => 'required',
    			'passwordd' => 'required',
    			'link' => 'required',
    			'fiziki' => 'required',
    			'credcard' => 'required',
    			'des' => 'required', 
    		],[  
    			'name.required' => 'لطفا نام مرسوله را وارد نمایید', 
    			'usernamee.required' => 'لطفا نام کاربری را وارد نمایید',   
    			'passwordd.required' => 'لطفا رمزعبور را وارد نمایید',   
    			'link.required' => 'لطفا لینک را وارد نمایید',   
    			'fiziki.required' => 'لطفا نوع فیزیکی یا مجازی کارت را مشخص نمایید',   
    			'credcard.required' => 'لطفا وضعیت درخواست کریدت کارت را مشخص نمایید',   
    			'des.required' => 'لطفا توضیحات سفارش را وارد نمایید',      
    			
    		]);
  
if($request->typcredcard=='0'){  $idcredcard=0; $creditcardspay=0; } elseif($request->typcredcard!='0') { $idcredcard=$request->typcredcard; 
$creditcardcounts = \ DB::table('creditcard')->where([ 
    ['creditcard.id', '=', $idcredcard] ,
    ['creditcard.id', '<>', '0' ] ,])
    ->orderBy('creditcard.id', 'desc')->count(); 
    if($creditcardcounts=='0'){ $creditcardspay=0; } else {
		 
$creditcards = \ DB::table('creditcard')->where([ 
    ['creditcard.id', '=', $idcredcard] ,
    ['creditcard.id', '<>', '0' ] ,])
    ->orderBy('creditcard.id', 'desc')->first();   $creditcardspay=$creditcards->crd_price;
		
	} 
    
    
    
    }    		

 
$admins =  \DB::table('user')->where('id', '=', Session::get('iduser'))  ->orderBy('id', 'desc')->first();
$codmoshtari=$admins->user_ncode;
 
if($request->fiziki=='1'){ $arobuy='4';  } elseif($request->fiziki=='0'){  $arobuy='3';  }      

  
 
DB::table('marsole')->insert([
    ['mar_name'  =>  $request->name ,'mar_username'  =>  $request->usernamee ,'mar_password'  =>  $request->passwordd ,'mar_link'  =>  $request->link ,'mar_fiziki'  =>  $request->fiziki ,'mar_credcard'  => $idcredcard ,'mar_codmoshtari'  =>   $codmoshtari,'mar_paycredit'  =>   $creditcardspay ,'mar_des'  =>  $request->des   ,'mar_status'  =>  '0'   ,'mar_arobuy'  =>  $arobuy  , 'mar_createdatdate'  =>   date('Y-m-d H:i:s')     ]
]); 
 	
$nametr = Session::flash('statust', 'سفارش شما با موفقیت ثبت شد. ');
$nametrt = Session::flash('sessurl', 'viewssefaresh');
		  return view('user.success'); 
  


}	else if (Session::get('activeuser')==0){    return redirect('user/activition'); }
else if (empty(Session::has('signuser'))){   return redirect('user/sign-in'); } }
		}			   
    


	public function addproject(){
		if (Session::has('signuser')){
$admins =  \DB::table('user')->where('id', '=', Session::get('iduser'))  ->orderBy('id', 'desc')->first();
 return view('user.addproject', [  'admins' => $admins    ]); }	
else{ return redirect('user/sign-in'); }
		}			   




public function addprojectpost(Request $request){
if (Session::has('signuser')){    	
  	
    	$this->validate($request,[
    			'name' => 'required',
    			'nameemployer' => 'required',
    			'fileplanfoor' => 'required',
    		],[
    			'name.required' => 'لطفا نام پروژه را وارد نمایید', 
    			'nameemployer.required' => 'لطفا نام کارفرما را وارد نمایید', 
    			'fileplanfoor.required' => 'لطفا فایل پلان طبقات را آپلود نمایید', 
    		]);
    		
    		
    		
    	 if( $request->hasFile('fileplanfoor')){ 
        $image = $request->file('fileplanfoor');
        $imageName = time().$image->getClientOriginalName();
        $image->move(public_path('css'),$imageName);    
    } else { $imageName=''; }
 
    		
    	
DB::table('project')->insert([
    ['project_name' => $request->name , 'project_address' => $request->nameemployer , 'project_plan_file_id' => $imageName,     'project_createdatdate' =>  date('Y-m-d H:i:s')  ]
]);
 
			 $nametr = Session::flash('statust', 'پروژه با موفقیت ثبت شد ');
		  	$nametrt = Session::flash('sessurl', 'viewsprojects');
		  return view('user.success'); }	
else{ return redirect('user/sign-in'); }    
 }  






				
	public function addticketuser(){
		if (Session::has('signuser')){
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();

 return view('user.addticket', [  'lngmenus' => $lngmenus , 'lngmenu' => $lngmenu  ]); }	
else{ return redirect('user/sign-in'); }
		}			   
   


public function addticketuserPost(Request $request){
if (Session::has('signuser')){    	
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();    	
    	$this->validate($request,[
    			'tit' => 'required|min:3|max:99',
    			'des' => 'required|min:5|max:999'
    		],[
    			'tit.required' => $lngmenu->lng_wtit.' ! '.$lngmenu->lng_wnotelq,
    			'tit.min' => $lngmenu->lng_wtit.' ! '.$lngmenu->lng_wshort,
    			'tit.max' => $lngmenu->lng_wtit.' ! '.$lngmenu->lng_wlong,
    			'des.required' => $lngmenu->lng_wtext.' ! '.$lngmenu->lng_wnotelq,
    			'des.min' => $lngmenu->lng_wtext.' ! '.$lngmenu->lng_wshort,
    			'des.max' => $lngmenu->lng_wtext.' ! '.$lngmenu->lng_wlong,
    		]);
    	
DB::table('ticket')->insert([
    ['tik_tit' => $request->tit ,     'tik_createdatdate' =>  date('Y-m-d H:i:s') ,     'tik_date' =>  date('Y-m-d H:i:s') , 'tik_fromarou' => 4 , 'tik_toarou' => 2 , 'tik_fromid' => Session::get('iduser') ,  'tik_fromsh' => 1 , 'tik_tosh' => 1 , 'tik_active' => 1 , 'tik_fromread' => 1 , 'tik_toread' => 0]
]);

$users = DB::table('ticket')->where('tik_tit', $request->tit)->orderBy('id', 'desc')->first(); 

$idtik= $users->id;   

DB::table('message')->insert([
    ['mes_ticket' => $idtik ,  'mes_des' => $request->des   , 'mes_createdatdate' =>  date('Y-m-d H:i:s') , 'mes_flg' =>  1    ]
]);
			 $nametr = Session::flash('statust', $lngmenu->lng_wsuccess);
		  	$nametrt = Session::flash('sessurl', 'viewstickets');
		  return view('user.success', ['lngmenus' => $lngmenus , 'lngmenu' => $lngmenu ]); }	
else{ return redirect('user/sign-in'); }    
 }  




	public function viewsticketsuser(){
		if (Session::has('signuser')){ 
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();

$admins = \DB::table('user') 
->join('ticket', 'user.id', '=', 'ticket.tik_fromid') 
->where([
    ['ticket.tik_fromarou', '=', 4],
    ['ticket.tik_toarou', '=', 2],
    ['ticket.tik_fromid', '=', Session::get('iduser')],
    ['ticket.tik_fromsh', '=', 1],])
    ->orderBy('ticket.tik_date', 'desc')->get();


$tickread = DB::table('user') 
->join('ticket', 'user.id', '=', 'ticket.tik_fromid')->where([
    ['ticket.tik_fromarou', '=', 4],
    ['ticket.tik_toarou', '=', 2],
    ['ticket.tik_fromid', '=', Session::get('iduser')],
    ['ticket.tik_fromsh', '=', 1],
    ['ticket.tik_fromread', '=', 0],])
    ->orderBy('ticket.id', 'desc')->count();
 
	Session::set('tickreaduser', $tickread);   
    
    
return view('user.viewstickets', ['admins' => $admins ,   'lngmenus' => $lngmenus , 'lngmenu' => $lngmenu ]);
}	else{ return redirect('user/sign-in'); }
}	





	public function ticketuser($id){
if (Session::has('signuser')){ 
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first(); 
	Session::put('idimg', $id);
$tickets = \DB::table('user') 
->join('ticket', 'user.id', '=', 'ticket.tik_fromid')->where([
    ['ticket.id', '=', $id],
    ['tik_fromarou', '=', 4],
    ['tik_toarou', '=', 2],
    ['tik_fromid', '=', Session::get('iduser')],
    ['tik_fromsh', '=', 1],])  ->orderBy('ticket.id', 'desc')->get();
$messages = \DB::table('message')->where('mes_ticket', '=', $id)  ->orderBy('id')->get();

$updatee = \DB::table('user') 
->join('ticket', 'user.id', '=', 'ticket.tik_fromid')->where([
    ['ticket.id', '=', $id],
    ['tik_fromarou', '=', 4],
    ['tik_toarou', '=', 2],
    ['tik_fromid', '=', Session::get('iduser')],
    ['tik_fromsh', '=', 1],])  ->update(['tik_fromread' => 1   ]); 
    
$tickread = DB::table('user') 
->join('ticket', 'user.id', '=', 'ticket.tik_fromid')->where([
    ['ticket.tik_fromarou', '=', 4],
    ['ticket.tik_toarou', '=', 2],
    ['ticket.tik_fromid', '=', Session::get('iduser')],
    ['ticket.tik_fromsh', '=', 1],
    ['ticket.tik_fromread', '=', 0],])
    ->orderBy('ticket.id', 'desc')->count();
 
	Session::set('tickreaduser', $tickread); 
 
return view('user.ticket', ['tickets' => $tickets  ,  'messages' => $messages ,   'lngmenus' => $lngmenus , 'lngmenu' => $lngmenu ]); }	
else{ return redirect('user/sign-in'); }
				}
	   

		
	public function ticketuserPost($id  , Request $request ){
if (Session::has('signuser')){ 
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first(); 
$this->validate($request,[
    			'des' => 'required|min:2|max:666',
    		],[
    			'des.required' => $lngmenu->lng_wtext.' ! '.$lngmenu->lng_wnotelq,
    			'des.min' => $lngmenu->lng_wtext.' ! '.$lngmenu->lng_wshort,
    			'des.max' => $lngmenu->lng_wtext.' ! '.$lngmenu->lng_wlong,
    		]);


    
    DB::table('message')->insert([
    ['mes_ticket' => $id ,  'mes_des' => $request->des   , 'mes_createdatdate' =>  date('Y-m-d H:i:s') , 'mes_flg' =>  1    ]
]);

 $updatee = \DB::table('user') 
->join('ticket', 'user.id', '=', 'ticket.tik_fromid')->where([
    ['ticket.id', '=', $id],
    ['tik_fromarou', '=', 4],
    ['tik_toarou', '=', 2],
    ['tik_fromid', '=', Session::get('iduser')],
    ['tik_fromsh', '=', 1],])  ->update(['tik_toread' => 0  , 'tik_active' => 1 ,     'tik_date' =>  date('Y-m-d H:i:s')   ]); 

$nametr = Session::flash('statust', $lngmenu->lng_wsuccess);  
$nametrt = Session::flash('sessurl', 'viewstickets/ticket/'.$id.'');
return view('user.success', ['lngmenus' => $lngmenus , 'lngmenu' => $lngmenu ]);
 
}	else{ return redirect('user/sign-in'); }
}


	public function deletticketuser($id){
if (Session::has('signuser')){ 
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first(); 	
 $updatee = \DB::table('user') 
->join('ticket', 'user.id', '=', 'ticket.tik_fromid')->where([
    ['ticket.id', '=', $id],
    ['tik_fromarou', '=', 4],
    ['tik_toarou', '=', 2],
    ['tik_fromid', '=', Session::get('iduser')],
    ['tik_fromsh', '=', 1],])  ->update(['tik_fromsh' => 0   ]); 

$nametr = Session::flash('statust', $lngmenu->lng_wsuccess);  
$nametrt = Session::flash('sessurl', 'viewstickets');
return view('user.success', ['lngmenus' => $lngmenus , 'lngmenu' => $lngmenu ]);

 }	else{ return redirect('user/sign-in'); }
				}
	



	public function viewselanatsuser(){
		if (Session::has('signuser')){ 
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first(); 	
 
$admins = \DB::table('user') 
->join('ticket', 'user.id', '=', 'ticket.tik_toid') 
->where([
    ['ticket.tik_fromarou', '=', 1],
    ['ticket.tik_toarou', '=', 4],
    ['ticket.tik_toid', '=', Session::get('iduser')],
    ['ticket.tik_tosh', '=', 1],])
    ->orderBy('ticket.id', 'desc')->get();


$elanread = DB::table('user') 
->join('ticket', 'user.id', '=', 'ticket.tik_toid')->where([
    ['ticket.tik_fromarou', '=', 1],
    ['ticket.tik_toarou', '=', 4],
    ['ticket.tik_toid', '=', Session::get('iduser')],
    ['ticket.tik_tosh', '=', 1],
    ['ticket.tik_toread', '=', 0],])
    ->orderBy('ticket.id', 'desc')->count();
 
	Session::set('elanreaduser', $elanread);   
    
    
return view('user.viewselanats', ['admins' => $admins , 'lngmenus' => $lngmenus , 'lngmenu' => $lngmenu]);
}	else{ return redirect('user/sign-in'); }
}	


 





	public function viewordersusersidpay(Request $request , $id){
	if (Session::has('signuser')){ 
		if (Session::get('activeuser')==1){ 




$updatee = \DB::table('user') 
->join('marsole', 'user.user_ncode', '=', 'marsole.mar_codmoshtari') 
->where([ 
    ['user.id', '=', Session::get('iduser')] ,
    ['marsole.mar_status', '=', '5'] ,
    ['marsole.id', '=', $id ] ,])
    ->update(['mar_status' => '6'   ]); 



$updatee = \DB::table('finicals')  
->where([ 
    ['finicals.finical_iduser', '=', Session::get('iduser')] , 
    ['finicals.finical_inc', '=', '3'] ,
    ['finicals.finical_arou', '=', '4'] ,
    ['finicals.finical_marpay', '=', '5'] ,
    ['finicals.finical_marid', '=', $id ] ,])
    ->update(['finical_payment' => '1'  , 'finical_paymentdate' => date('Y-m-d H:i:s')  ]); 


$chargefinical=\DB::table('finicals') ->where([['finical_inc', '=',  3 ],['finical_marid', '=',  $id ],['finical_arou', '=',  4 ],['finical_iduser', '=',  Session::get('iduser')],])->orderBy('id', 'desc')->first();	
		    	
DB::table('charge')->insert([
    ['charge_pay' => $chargefinical->finical_pay ,     'charge_createdatdate' =>  date('Y-m-d H:i:s') , 'charge_arou' => 4 ,  'charge_iduser' => Session::get('iduser') ,  'charge_finical' => $chargefinical->id  ]
]);	    	

    
		  	
		  	$nametr = Session::flash('statust', 'هزینه باربری سفارش با موفقیت پرداخت شد. ');
		  	$nametrt = Session::flash('sessurl', 'viewssefaresh/order/'.$id.'');	
		  	
		  	
$user = \DB::table('marsole')  ->where([   ['id', '=', $id ] ,]) ->orderBy('id', 'desc')->first();
$codmoshtari = $user->mar_codmoshtari;
$user = \DB::table('user')  ->where([   ['user_ncode', '=', $codmoshtari ] ,]) ->orderBy('id', 'desc')->first();	  	 
$elanatorders =  DB::table('elanatorders')  ->orderBy('id', 'desc')->first();
 if($elanatorders->elanord_paykargomail == '1'){
 	if ( $user->user_email != '')  {
 $usernamee = $user->user_name; 
 $titmes='هزینه باربری سفارش با موفقیت پرداخت شد';
 $mestt='هزینه قابل پرداخت';
 $mesnot =  $chargefinical->finical_pay.' ريال '; 
   Mail::send('superadmin.mail', ['user' => $user , 'usernamee' => $usernamee, 'mesnot' => $mesnot, 'titmes' => $titmes , 'mestt' => $mestt], function ($m) use ($user) {
         

            $m->from('info@site.com', 'کارگو');

            $m->to($user->user_email, $user->user_email)->subject('پرداخت هزینه باربری');
        }); 	
 }	 }	
 
 	
 if($elanatorders->elanord_paykargosms == '1'){	
    
$panelsms = \DB::table('panelsms')->where('id', '=',  1)  ->orderBy('id', 'desc')->first();
include(app_path().'/../sms/api_send_sms.php');
$message='با عرض سلام '.$user->user_name.' عزیز. هزینه باربری سفارش با موفقیت پرداخت شد';
if (($result = Send_SMS($panelsms->sms_username, $panelsms->sms_password, $panelsms->sms_fromnumber, $user->user_tell, $message , 0, false)) === '0')
{ 
		
	return view('user.success');
} else if ($result !== '') {   
		
	return view('user.success');
 }


 }
 
		  	
		  	
		  	
return view('user.success' );
	
}	else if (Session::get('activeuser')==0){    return redirect('user/activition'); }
else if (empty(Session::has('signuser'))){   return redirect('user/sign-in'); } }
}	





	public function paypostiran(Request $request , $id){
	if (Session::has('signuser')){ 
		if (Session::get('activeuser')==1){ 




$updatee = \DB::table('user') 
->join('marsole', 'user.user_ncode', '=', 'marsole.mar_codmoshtari') 
->where([ 
    ['user.id', '=', Session::get('iduser')] ,
    ['marsole.mar_status', '=', '8'] ,
    ['marsole.id', '=', $id ] ,])
    ->update(['mar_status' => '9'   ]); 
    

$updatee = \DB::table('finicals')  
->where([ 
    ['finicals.finical_iduser', '=', Session::get('iduser')] , 
    ['finicals.finical_inc', '=', '3'] ,
    ['finicals.finical_arou', '=', '4'] ,
    ['finicals.finical_marpay', '=', '8'] ,
    ['finicals.finical_marid', '=', $id ] ,])
    ->update(['finical_payment' => '1'  , 'finical_paymentdate' => date('Y-m-d H:i:s')  ]); 

 
$chargefinical=\DB::table('finicals') ->where([['finical_inc', '=',  3 ],['finical_marid', '=',  $id ],['finical_arou', '=',  4 ],['finical_iduser', '=',  Session::get('iduser')],])->orderBy('id', 'desc')->first();	
		    	
DB::table('charge')->insert([
    ['charge_pay' => $chargefinical->finical_pay ,     'charge_createdatdate' =>  date('Y-m-d H:i:s') , 'charge_arou' => 4 ,  'charge_iduser' => Session::get('iduser') ,  'charge_finical' => $chargefinical->id  ]
]);	    	

    
		  	
		  	$nametr = Session::flash('statust', 'هزینه پستی داخل ایران با موفقیت پرداخت شد. ');
		  	$nametrt = Session::flash('sessurl', 'viewssefaresh/order/'.$id.'');	
	  	
$user = \DB::table('marsole')  ->where([   ['id', '=', $id ] ,]) ->orderBy('id', 'desc')->first();
$codmoshtari = $user->mar_codmoshtari;
$user = \DB::table('user')  ->where([   ['user_ncode', '=', $codmoshtari ] ,]) ->orderBy('id', 'desc')->first();	  	 
$elanatorders =  DB::table('elanatorders')  ->orderBy('id', 'desc')->first();
 if($elanatorders->elanord_paypostmail == '1'){
 	if ( $user->user_email != '')  {
 $usernamee = $user->user_name; 
 $titmes='هزینه پستی داخل ایران با موفقیت پرداخت شد';
 $mestt='هزینه قابل پرداخت';
 $mesnot =  $chargefinical->finical_pay.' ريال '; 
   Mail::send('superadmin.mail', ['user' => $user , 'usernamee' => $usernamee, 'mesnot' => $mesnot, 'titmes' => $titmes , 'mestt' => $mestt], function ($m) use ($user) {
         

            $m->from('info@site.com', 'کارگو');

            $m->to($user->user_email, $user->user_email)->subject('پرداخت هزینه پستی');
        }); 	
 }	 }	
 
 	
 if($elanatorders->elanord_paypostsms == '1'){	
    
$panelsms = \DB::table('panelsms')->where('id', '=',  1)  ->orderBy('id', 'desc')->first();
include(app_path().'/../sms/api_send_sms.php');
$message='با عرض سلام '.$user->user_name.' عزیز. هزینه پستی داخل ایران با موفقیت پرداخت شد';
if (($result = Send_SMS($panelsms->sms_username, $panelsms->sms_password, $panelsms->sms_fromnumber, $user->user_tell, $message , 0, false)) === '0')
{ 
		
	return view('user.success');
} else if ($result !== '') {   
		
	return view('user.success');
 }


 }
 

return view('user.success' );
	
}	else if (Session::get('activeuser')==0){    return redirect('user/activition'); }
else if (empty(Session::has('signuser'))){   return redirect('user/sign-in'); } }
}	




	public function recvordfinalus($id){
	if (Session::has('signuser')){ 
		if (Session::get('activeuser')==1){ 




$updatee = \DB::table('user') 
->join('marsole', 'user.user_ncode', '=', 'marsole.mar_codmoshtari') 
->where([ 
    ['user.id', '=', Session::get('iduser')] ,
    ['marsole.mar_status', '=', '10'] ,
    ['marsole.id', '=', $id ] ,])
    ->update(['mar_status' => '11' ,   'mar_daterecv' =>  date('Y-m-d H:i:s')   ]); 
    
    
    
		  	
		  	$nametr = Session::flash('statust', 'سفارش با موفقیت تحویل مشتری شد  ');
		  	$nametrt = Session::flash('sessurl', 'viewssefaresh/order/'.$id.'');	


$user = \DB::table('marsole')  ->where([   ['id', '=', $id ] ,]) ->orderBy('id', 'desc')->first();
$codmoshtari = $user->mar_codmoshtari;
$user = \DB::table('user')  ->where([   ['user_ncode', '=', $codmoshtari ] ,]) ->orderBy('id', 'desc')->first();	  	 
$elanatorders =  DB::table('elanatorders')  ->orderBy('id', 'desc')->first();
 if($elanatorders->elanord_recvordmail == '1'){
 	if ( $user->user_email != '')  {
 $usernamee = $user->user_name; 
 $titmes='سفارش با موفقیت تحویل شما گردید';
 $mestt='';
 $mesnot = ''; 
   Mail::send('superadmin.mail', ['user' => $user , 'usernamee' => $usernamee, 'mesnot' => $mesnot, 'titmes' => $titmes , 'mestt' => $mestt], function ($m) use ($user) {
         

            $m->from('info@site.com', 'کارگو');

            $m->to($user->user_email, $user->user_email)->subject('تحویل مرسوله خدمت کاربر');
        }); 	
 }	 }	
 
 	
 if($elanatorders->elanord_recvordsms == '1'){	
    
$panelsms = \DB::table('panelsms')->where('id', '=',  1)  ->orderBy('id', 'desc')->first();
include(app_path().'/../sms/api_send_sms.php');
$message='با عرض سلام '.$user->user_name.' عزیز. سفارش با موفقیت تحویل شما گردید';
if (($result = Send_SMS($panelsms->sms_username, $panelsms->sms_password, $panelsms->sms_fromnumber, $user->user_tell, $message , 0, false)) === '0')
{ 
		
	return view('user.success');
} else if ($result !== '') {   
		
	return view('user.success');
 }


 }
 
		  	
		  	
return view('user.success' );
	
}	else if (Session::get('activeuser')==0){    return redirect('user/activition'); }
else if (empty(Session::has('signuser'))){   return redirect('user/sign-in'); } }
}	






	public function viewadresturkey(){
	if (Session::has('signuser')){ 
		if (Session::get('activeuser')==1){ 



$users =  \DB::table('user')->where('id', '=', Session::get('iduser'))  ->orderBy('id', 'desc')->first();
$showadres=$users->user_showadres;
if($showadres=='0'){   return redirect('user/buyadresturkey'); } else {

$adres1='';
$adres2='';

$admins = \DB::table('adresturkey') ->where('id', '=', '1')->orderBy('id', 'desc')->first();
$adres11 = explode("demo",$admins->adr_adres1);  $adres1=$adres11['0'].' '.$users->user_ncode.' '.$adres11['1']; 
$adres22 = explode("demo",$admins->adr_adres2);  $adres2=$adres22['0'].' '.$users->user_ncode.' '.$adres22['1']; 

	return view('user.adresturkey', ['admins' => $admins , 'users' => $users , 'adres1'=>$adres1 , 'adres2'=>$adres2]); 

	
}

	
}	else if (Session::get('activeuser')==0){    return redirect('user/activition'); }
else if (empty(Session::has('signuser'))){   return redirect('user/sign-in'); } }
}	



	public function buyadresturkeypost($id , Request $request){
	if (Session::has('signuser')){ 
		if (Session::get('activeuser')==1){ 


 return redirect('zarinpal/epayo.php?id='.$id.'');


}	else if (Session::get('activeuser')==0){    return redirect('user/activition'); }
else if (empty(Session::has('signuser'))){   return redirect('user/sign-in'); } }
}	



	public function buyadresturkey(){
	if (Session::has('signuser')){ 
		if (Session::get('activeuser')==1){ 

$users =  \DB::table('user')->where('id', '=', Session::get('iduser'))  ->orderBy('id', 'desc')->first();
$showadres=$users->user_showadres;
if($showadres=='1'){   return redirect('user/viewadresturkey'); } else {


$admins =  \DB::table('user')->where('id', '=', Session::get('iduser'))  ->orderBy('id', 'desc')->first();
$mngindex =  \DB::table('mngindex')->where('id', '=', '1')  ->orderBy('id', 'desc')->first();



$getwaypays=\DB::table('getwaypay')->where('id', '=', '2')   ->orderBy('id' )->get();



//mycharge 
$charges = \DB::table('user') 
->join('charge', 'user.id', '=', 'charge.charge_iduser') 
->join('finicals', 'charge.charge_finical', '=', 'finicals.id') 
->where([
    ['charge.charge_arou', '=', 4],
    ['charge.charge_iduser', '=', Session::get('iduser')],
    ['finicals.finical_payment', '=', 1],
    ['finicals.finical_inc', '=', 5],])
    ->orderBy('charge.charge_id', 'desc')->get();
$chargepaymy=0;
foreach($charges as $charge){ $chargepaymy=$charge->charge_pay+$chargepaymy; }




 //supcharge  
$charges = \DB::table('user') 
->join('charge', 'user.id', '=', 'charge.charge_iduser')  
->join('finicals', 'charge.charge_finical', '=', 'finicals.id') 
->where([
    ['charge.charge_arou', '=', 4],
    ['charge.charge_iduser', '=', Session::get('iduser')],
    ['finicals.finical_payment', '=', 1],
    ['finicals.finical_inc', '=', 6],])
    ->orderBy('charge.charge_id', 'desc')->get();
$chargepaysup=0;
foreach($charges as $charge){ $chargepaysup=$charge->charge_pay+$chargepaysup; }



 //odat  
$charges = \DB::table('user') 
->join('charge', 'user.id', '=', 'charge.charge_iduser')  
->join('finicals', 'charge.charge_finical', '=', 'finicals.id') 
->where([
    ['charge.charge_arou', '=', 4],
    ['charge.charge_iduser', '=', Session::get('iduser')],
    ['finicals.finical_payment', '=', 1],
    ['finicals.finical_inc', '=', 7],])
    ->orderBy('charge.charge_id', 'desc')->get();
$chargepayodat=0;
foreach($charges as $charge){ $chargepayodat=$charge->charge_pay+$chargepayodat; }



//pardakht 
$charges = \DB::table('user') 
->join('charge', 'user.id', '=', 'charge.charge_iduser')  
->join('finicals', 'charge.charge_finical', '=', 'finicals.id') 
->where([
    ['charge.charge_arou', '=', 4],
    ['charge.charge_iduser', '=', Session::get('iduser')],
    ['finicals.finical_payment', '=', 1],
    ['finicals.finical_inc', '=', 3],])
    ->orderBy('charge.charge_id', 'desc')->get();
$chargepaypar=0;
foreach($charges as $charge){ $chargepaypar=$charge->charge_pay+$chargepaypar; }


 //bisinis  
$charges = \DB::table('user') 
->join('charge', 'user.id', '=', 'charge.charge_iduser')  
->join('finicals', 'charge.charge_finical', '=', 'finicals.id') 
->where([
    ['charge.charge_arou', '=', 4],
    ['charge.charge_iduser', '=', Session::get('iduser')],
    ['finicals.finical_payment', '=', 1],
    ['finicals.finical_inc', '=', 8],])
    ->orderBy('charge.charge_id', 'desc')->get();
$chargepaybisi=0;
foreach($charges as $charge){ $chargepaybisi=$charge->charge_pay+$chargepaybisi; }


//jamkol
$chargepay= ($chargepaysup +  $chargepaymy  + $chargepaybisi ) -  ($chargepaypar + $chargepayodat) ;
 

 

$chargeac=$chargepay;




if($chargeac >= $mngindex->ind_taxp){ $inc='3'; } else if($chargeac < $mngindex->ind_taxp){ $inc='4'; }



 
 $delets = \DB::table('finicals')->where([['finical_iduser', '=', Session::get('iduser')],['finical_marid', '=', '0'],['finical_payment', '=', '0'],['finical_arou', '=', '4'], ])  ->delete(); 	


DB::table('finicals')->insert([
    ['finical_pay' => $mngindex->ind_taxp ,     'finical_createdatdate' =>  date('Y-m-d H:i:s') , 'finical_inc' => $inc , 'finical_payment' => 0 ,  'finical_arou' => 4 ,  'finical_iduser' => Session::get('iduser')  ]
]);
 
 
 
$chargefinical=\DB::table('finicals') ->where([['finical_inc', '=',  $inc ],['finical_marid', '=',  '0' ],['finical_arou', '=',  4 ],['finical_iduser', '=',  Session::get('iduser')],['finical_payment', '=',  '0'],])->orderBy('id', 'desc')->first();	
	
 $delets = \DB::table('charge')->where([ ['charge_finical', '=', $chargefinical->id], ])  ->delete(); 	
		  	
		  	    	
DB::table('charge')->insert([
    ['charge_pay' => $mngindex->ind_taxp ,     'charge_createdatdate' =>  date('Y-m-d H:i:s') , 'charge_arou' => 4 ,  'charge_iduser' => Session::get('iduser') ,  'charge_finical' => $chargefinical->id  ]
]);	    	
 



	return view('user.finicaladres', ['admins' => $admins , 'mngindex' => $mngindex ,   'getwaypays' => $getwaypays , 'chargeac' => $chargeac , 'chargefinical'=> $chargefinical  ]); 
}
	
}	else if (Session::get('activeuser')==0){    return redirect('user/activition'); }
else if (empty(Session::has('signuser'))){   return redirect('user/sign-in'); } }
}	







	public function buyadresturkeypay($id , Request $request){
	if (Session::has('signuser')){ 
		if (Session::get('activeuser')==1){ 

 

$updatee = \DB::table('finicals')  
->where([ 
    ['finicals.finical_iduser', '=', Session::get('iduser')] ,  
    ['finicals.finical_arou', '=', '4'] , 
    ['finicals.id', '=', $id ] ,])
    ->update(['finical_payment' => '1'  , 'finical_paymentdate' => date('Y-m-d H:i:s')   , 'finical_inc' => '3'  ]); 

 


$updatee = \DB::table('user')  
->where([ 
    ['user.id', '=', Session::get('iduser')] ,  ])
    ->update(['user_showadres' => '1'     ]); 


		  	$nametr = Session::flash('statust', 'خرید آدرس با موفقیت انجام شد . ');
		  	$nametrt = Session::flash('sessurl', 'viewadresturkey');	

return view('user.success' );
  
 
	
}	else if (Session::get('activeuser')==0){    return redirect('user/activition'); }
else if (empty(Session::has('signuser'))){   return redirect('user/sign-in'); } }
}	





 



	public function viewordersusers(){
	if (Session::has('signuser')){ 
		if (Session::get('activeuser')==1){  
 
 $marsoles = \DB::table('user') 
->join('marsole', 'user.user_ncode', '=', 'marsole.mar_codmoshtari') 
->where([ 
    ['user.id', '=', Session::get('iduser')] ,
    ['marsole.id', '<>', '0' ] ,])
    ->orderBy('marsole.id', 'desc')->get();
 
    
return view('user.viewssefaresh', ['marsoles' => $marsoles  ]);
  
    
return view('user.viewsorder', ['admins' => $admins  ]);
}	else if (Session::get('activeuser')==0){    return redirect('user/activition'); }
else if (empty(Session::has('signuser'))){   return redirect('user/sign-in'); } }
}	





	public function viewordersusersid($id){
	if (Session::has('signuser')){ 
		if (Session::get('activeuser')==1){  
 

$marcount = \DB::table('user') 
->join('marsole', 'user.user_ncode', '=', 'marsole.mar_codmoshtari') 
->where([ 
    ['user.id', '=', Session::get('iduser')] ,
    ['marsole.id', '=', $id ] ,])
    ->orderBy('marsole.id', 'desc')->count();
    
    
if($marcount=='0'){
	$marsoles='';	$creditcards='';
} else {
$marsoles = \DB::table('user') 
->join('marsole', 'user.user_ncode', '=', 'marsole.mar_codmoshtari') 
->where([ 
    ['user.id', '=', Session::get('iduser')] ,
    ['marsole.id', '=', $id ] ,])
    ->orderBy('marsole.id', 'desc')->get();
 foreach($marsoles as $marsol){ $creditcards=$marsol->mar_credcard;  }     
$creditcards = \ DB::table('creditcard')->where([ 
    ['creditcard.id', '=', $creditcards] ,
    ['creditcard.id', '<>', '0' ] ,])
    ->orderBy('creditcard.id', 'desc')->first();	
}

   
return view('user.sefaaresh', ['marsoles' => $marsoles  , 'creditcards' => $creditcards    ]);
}	else if (Session::get('activeuser')==0){    return redirect('user/activition'); }
else if (empty(Session::has('signuser'))){   return redirect('user/sign-in'); } }
}	



	public function editorderid($id){
	if (Session::has('signuser')){ 
		if (Session::get('activeuser')==1){  
 

$marsoles = \DB::table('user') 
->join('marsole', 'user.user_ncode', '=', 'marsole.mar_codmoshtari') 
->where([ 
    ['user.id', '=', Session::get('iduser')] ,
    ['marsole.mar_status', '=', '0'] ,    
    ['marsole.id', '=', $id ] ,])
    ->orderBy('marsole.id', 'desc')->get();
 foreach($marsoles as $marsol){ $creditcards=$marsol->mar_credcard;  }     
$creditcards = \ DB::table('creditcard')->where([ 
    ['creditcard.id', '=', $creditcards] ,
    ['creditcard.id', '<>', '0' ] ,])
    ->orderBy('creditcard.id', 'desc')->first();
 
   
return view('user.editorder', ['marsoles' => $marsoles , 'creditcards' => $creditcards  ]);
}	else if (Session::get('activeuser')==0){    return redirect('user/activition'); }
else if (empty(Session::has('signuser'))){   return redirect('user/sign-in'); } }
}	


public function cancellordus($id  ){
	if (Session::has('signuser')){ 
		if (Session::get('activeuser')==1){  


$updatee = \DB::table('user') 
->join('marsole', 'user.user_ncode', '=', 'marsole.mar_codmoshtari') 
->where([ 
    ['user.id', '=', Session::get('iduser')] ,
    ['marsole.mar_status', '<', '2'] ,
    ['marsole.id', '=', $id ] ,])
    ->update(['mar_status' => '3'   ]); 
    
    
		  	$nametr = Session::flash('statust', 'سفارش باموفقیت لغو شد. ');
		  	$nametrt = Session::flash('sessurl', 'viewssefaresh/order/'.$id.'');	

return view('user.success' );
  

}	else if (Session::get('activeuser')==0){    return redirect('user/activition'); }
else if (empty(Session::has('signuser'))){   return redirect('user/sign-in'); } }
}	



public function payfinical($id  ){
	if (Session::has('signuser')){ 
		if (Session::get('activeuser')==1){  



$admins = \DB::table('finicals')  
->where([ 
    ['finicals.finical_iduser', '=', Session::get('iduser')] ,  
    ['finicals.finical_marid', '=', $id] ,  
    ['finicals.finical_arou', '=', '4'] ,  
    ['finicals.finical_payment', '=', '0'] , ])
    ->orderBy('finicals.id', 'desc')->first();

  return redirect('user/viewsfinical/finical/'.$admins->id.''); 


}	else if (Session::get('activeuser')==0){    return redirect('user/activition'); }
else if (empty(Session::has('signuser'))){   return redirect('user/sign-in'); } }
}	



public function paysefaresh(Request $request , $id  ){
	if (Session::has('signuser')){ 
		if (Session::get('activeuser')==1){  


$user = \DB::table('marsole')  ->where([   ['id', '=', $id ] ,]) ->orderBy('id', 'desc')->first();
$mar_crdflg = $user->mar_crdflg;
if($mar_crdflg=='1'){ $mar_status='7'; }  elseif($mar_crdflg=='0'){ $mar_status='2'; } 


$updatee = \DB::table('user') 
->join('marsole', 'user.user_ncode', '=', 'marsole.mar_codmoshtari') 
->where([ 
    ['user.id', '=', Session::get('iduser')] ,
    ['marsole.mar_status', '=', '1'] ,
    ['marsole.id', '=', $id ] ,])
    ->update(['mar_status' => $mar_status  ]); 
    


$updatee = \DB::table('finicals')  
->where([ 
    ['finicals.finical_iduser', '=', Session::get('iduser')] , 
    ['finicals.finical_inc', '=', '3'] ,
    ['finicals.finical_arou', '=', '4'] ,
    ['finicals.finical_marpay', '=', '1'] ,
    ['finicals.finical_marid', '=', $id ] ,])
    ->update(['finical_payment' => '1'  , 'finical_paymentdate' => date('Y-m-d H:i:s')  ]); 


$chargefinical=\DB::table('finicals') ->where([['finical_inc', '=',  3 ],['finical_marid', '=',  $id ],['finical_arou', '=',  4 ],['finical_iduser', '=',  Session::get('iduser')],])->orderBy('id', 'desc')->first();	
		    	
DB::table('charge')->insert([
    ['charge_pay' => $chargefinical->finical_pay ,     'charge_createdatdate' =>  date('Y-m-d H:i:s') , 'charge_arou' => 4 ,  'charge_iduser' => Session::get('iduser') ,  'charge_finical' => $chargefinical->id  ]
]);	    	

    


    
		  	$nametr = Session::flash('statust', 'هزینه خرید مرسوله با موفقیت پرداخت شد . ');
		  	$nametrt = Session::flash('sessurl', 'viewssefaresh/order/'.$id.'');	
		  	
		  	
$user = \DB::table('marsole')  ->where([   ['id', '=', $id ] ,]) ->orderBy('id', 'desc')->first();
$codmoshtari = $user->mar_codmoshtari;
$user = \DB::table('user')  ->where([   ['user_ncode', '=', $codmoshtari ] ,]) ->orderBy('id', 'desc')->first();	  	 
$elanatorders =  DB::table('elanatorders')  ->orderBy('id', 'desc')->first();
 if($elanatorders->elanord_payordermail == '1'){
 	if ( $user->user_email != '')  {
 $usernamee = $user->user_name; 
 $titmes='هزینه خرید مرسوله با موفقیت پرداخت شد';
 $mestt='هزینه قابل پرداخت';
 $mesnot =  $chargefinical->finical_pay.' ريال '; 
   Mail::send('superadmin.mail', ['user' => $user , 'usernamee' => $usernamee, 'mesnot' => $mesnot, 'titmes' => $titmes , 'mestt' => $mestt], function ($m) use ($user) {
         

            $m->from('info@site.com', 'کارگو');

            $m->to($user->user_email, $user->user_email)->subject('پرداخت هزینه سفارش');
        }); 	
 }	 }	
 
 	
 if($elanatorders->elanord_payordersms == '1'){	
    
$panelsms = \DB::table('panelsms')->where('id', '=',  1)  ->orderBy('id', 'desc')->first();
include(app_path().'/../sms/api_send_sms.php');
$message='با عرض سلام '.$user->user_name.' عزیز.    هزینه خرید مرسوله با موفقیت پرداخت شد';
if (($result = Send_SMS($panelsms->sms_username, $panelsms->sms_password, $panelsms->sms_fromnumber, $user->user_tell, $message , 0, false)) === '0')
{ 
		
	return view('user.success');
} else if ($result !== '') {   
		
	return view('user.success');
 }


 }
 
		  	


return view('user.success' );

  

}	else if (Session::get('activeuser')==0){    return redirect('user/activition'); }
else if (empty(Session::has('signuser'))){   return redirect('user/sign-in'); } }
}	



public function editorderidpost($id , Request $request){
	if (Session::has('signuser')){ 
		if (Session::get('activeuser')==1){  



$marsoles = \DB::table('user') 
->join('marsole', 'user.user_ncode', '=', 'marsole.mar_codmoshtari') 
->where([ 
    ['user.id', '=', Session::get('iduser')] ,
    ['marsole.mar_status', '=', '0'] ,
    ['marsole.id', '=', $id ] ,])
    ->orderBy('marsole.id', 'desc')->first();

if($marsoles->mar_status=='0'){
	

$this->validate($request,[
    			'name' => 'required',
    			'usernamee' => 'required',
    			'passwordd' => 'required',
    			'link' => 'required', 
    			'des' => 'required', 
    		],[  
    			'name.required' => 'لطفا نام مرسوله را وارد نمایید', 
    			'usernamee.required' => 'لطفا نام کاربری را وارد نمایید',   
    			'passwordd.required' => 'لطفا رمزعبور را وارد نمایید',   
    			'link.required' => 'لطفا لینک را وارد نمایید',     
    			'des.required' => 'لطفا توضیحات سفارش را وارد نمایید',      
    			
    		]);
  

$updatee = \DB::table('user') 
->join('marsole', 'user.user_ncode', '=', 'marsole.mar_codmoshtari') 
->where([ 
    ['user.id', '=', Session::get('iduser')] ,
    ['marsole.id', '=', $id ] ,])
    ->update(['mar_name' => $request->name , 'mar_username' => $request->usernamee , 'mar_password' => $request->passwordd , 'mar_link' => $request->link , 'mar_des' => $request->des    ]); 
    
    
		  	$nametr = Session::flash('statust', 'سفارش با موفقیت ویرایش شد. ');
		  	$nametrt = Session::flash('sessurl', 'viewssefaresh/order/'.$id.'');	

return view('user.success', [ 'marsoles' => $marsoles   ]);
  
  
}

 




}	else if (Session::get('activeuser')==0){    return redirect('user/activition'); }
else if (empty(Session::has('signuser'))){   return redirect('user/sign-in'); } }
}	




	public function elanatuser($id){
if (Session::has('signuser')){
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first(); 	
 
	Session::put('idimg', $id);
$tickets = \DB::table('user') 
->join('ticket', 'user.id', '=', 'ticket.tik_toid')->where([
    ['ticket.id', '=', $id],
    ['tik_fromarou', '=', 1],
    ['tik_toarou', '=', 4],
    ['tik_toid', '=', Session::get('iduser')],
    ['tik_tosh', '=', 1],])  ->orderBy('ticket.id', 'desc')->get();
$messages = \DB::table('message')->where('mes_ticket', '=', $id)  ->orderBy('id')->get();

$updatee = \DB::table('user') 
->join('ticket', 'user.id', '=', 'ticket.tik_toid')->where([
    ['ticket.id', '=', $id],
    ['tik_fromarou', '=', 1],
    ['tik_toarou', '=', 4],
    ['tik_toid', '=', Session::get('iduser')],
    ['tik_tosh', '=', 1],])  ->update(['tik_toread' => 1 , 'tik_active' => 2   ]); 
    
$elanread = DB::table('user') 
->join('ticket', 'user.id', '=', 'ticket.tik_toid')->where([
    ['ticket.tik_fromarou', '=', 1],
    ['ticket.tik_toarou', '=', 4],
    ['ticket.tik_toid', '=', Session::get('iduser')],
    ['ticket.tik_tosh', '=', 1],
    ['ticket.tik_toread', '=', 0],])
    ->orderBy('ticket.id', 'desc')->count();
 
	Session::set('elanreaduser', $elanread);  
 
return view('user.elanat', ['tickets' => $tickets , 'messages' => $messages ,'lngmenus' => $lngmenus , 'lngmenu' => $lngmenu ]); }	
else{ return redirect('user/sign-in'); }
				}




	
	public function rezervbelit(){
	if (Session::has('signuser')){ 
		if (Session::get('activeuser')==1){ 
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first(); 
$citys= \DB::table('city') ->where([['id', '<>',  '0'],['cit_active', '=',  '1'],])->orderBy('cit_name')->get();
$currencys=\DB::table('currency') ->where([['id', '<>',  '0'],['cur_active', '=',  '1'],])->orderBy('cur_nem')->get();

$admins = \DB::table('belitsearch')->where([['id', '<>',  '0'],['bls_active', '=',  '0'],['bls_origin', '=',  Session::get('origin')],['bls_desti', '=',  Session::get('desti')] ,['bls_datefly', '=',  Session::get('datefly')] ,])->orderBy('id', 'desc')->get();
 return view('user.rezervbelit' , ['lngmenus' => $lngmenus , 'lngmenu' => $lngmenu, 'citys' => $citys , 'currencys' => $currencys   , 'admins' => $admins     ]);
}	else if (Session::get('activeuser')==0){    return redirect('user/activition'); }
else if (empty(Session::has('signstudent'))){   return redirect('user/sign-in'); } }
}		










public function rezervbelitsearch(Request $request){
if (Session::has('signuser')){ 
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();   	    

 if($request->origin == $request->desti ){
$nrepeatl = Session::flash('repeat', '2');
return redirect('user/rezervbelit'); } 


    		
    			 $this->validate($request,[
    			'origin' => 'required',
    			'desti' => 'required',
    			'datepicker' => 'required',
    		],[
    			'origin.required' => $lngmenu->lng_worigin.' ! '.$lngmenu->lng_wnotelq,
    			'desti.required' => $lngmenu->lng_wdesti.' ! '.$lngmenu->lng_wnotelq,
    			'datepicker.required' => $lngmenu->lng_wdatefly.' ! '.$lngmenu->lng_wnotelq,
    		 ]);  


$nrepeatl = Session::flash('origin', $request->origin);
$nrepeatl = Session::flash('desti', $request->desti);

$date=date('m/d/Y', strtotime($request->datepicker));
$nrepeatl = Session::flash('datefly', $date);  


$nrepeatl = Session::flash('repeat', '3');
return redirect('user/rezervbelit');
     	 }	
else{ return redirect('user/sign-in'); }    	  
}
	





	
	public function rezerv($id){
	if (Session::has('signuser')){ 
		if (Session::get('activeuser')==1){ 
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first(); 
$admins = \DB::table('belit')->where([['id', '<>',  '0'],['bel_bls', '=',  $id], ])->orderBy('id', 'desc')->limit(1)->get();
 return view('user.rezerv' , ['lngmenus' => $lngmenus , 'lngmenu' => $lngmenu, 'admins' => $admins     ]);
}	else if (Session::get('activeuser')==0){    return redirect('user/activition'); }
else if (empty(Session::has('signstudent'))){   return redirect('user/sign-in'); } }
}		




	
	public function rezervpost($id , Request $request){
	if (Session::has('signuser')){ 
		if (Session::get('activeuser')==1){ 
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first(); 

    			 $this->validate($request,[
    			'numberbelit' => 'required|numeric',
    		],[
    			'numberbelit.required' => $lngmenu->lng_wnumberbelit.' ! '.$lngmenu->lng_wnotelq,
    			'numberbelit.numeric' => $lngmenu->lng_wnumberbelit.' ! '.$lngmenu->lng_wnotelq,
    		 ]);  
$numberbelit = $request->numberbelit ;  
$count = \DB::table('belit')->where([['bel_bls', '=',  $id],['bel_status', '=',  '0'],])->orderBy('id')->count();
$first = \DB::table('belit')->where([['bel_bls', '=',  $id],['bel_status', '=',  '0'],])->orderBy('id')->first();
$firstid=$first->id;
$sum=$request->numberbelit*($first->bel_rateuser+$first->bel_cost);

 if(($numberbelit > $count)||($numberbelit=='0') ){
$nrepeatl = Session::flash('repeat', '1');
return redirect('user/rezervbelit/'.$id.'/rezerv'); }  		 


   $rnd=rand(1, 999999999);  
   
    DB::table('belitrezerv')->insert([
    [ 'blr_codrezerv' => $rnd , 'blr_number' => $request->numberbelit , 'blr_sum' => $sum , 'blr_codbelit' => $first->bel_bls , 'blr_arou' => '4'  , 'blr_from' =>  Session::get('iduser')  , 'blr_status' => '1'    ]
]);   

$i=0;
while($i < $request->numberbelit ){

$updatee = \DB::table('belit')
->where([['belit.bel_bls', '=', $id],['belit.id', '=', $firstid+$i ],['belit.bel_status', '=', '0'], ])  ->
 update(['bel_status' => 1 ,'bel_arou' => 4 ,  'bel_iduser' =>  Session::get('iduser') ,  'bel_codrezerv' =>  $rnd , 'bel_daterezerv' => date('Y-m-d H:i:s')   ]);     
 $i++;	    
    }


   $finicalnumber=rand(1, 999999999);
   
    DB::table('finicals')->insert([
    [ 'finical_codrezerv' => $rnd , 'finical_number' => $finicalnumber , 'finical_pay' => $sum  , 'finical_arou' => '4'  ,  'finical_inc' => '4'  ,  'finical_payment' => '0'  , 'finical_iduser' =>  Session::get('iduser') , 'finical_createdatdate' =>  date('Y-m-d H:i:s')    ]
]);   

    
 
$countp = \DB::table('belit')->where([['bel_bls', '=',  $id],['bel_status', '=',  '0'],])->orderBy('id')->count();   
if($countp==0){
$updatee = \DB::table('belitsearch')
->where([['belitsearch.bls_codbelit', '=', $id],['belitsearch.bls_active', '=', '0'], ])  ->
 update(['belitsearch.bls_active' => 1  , 'belitsearch.bls_remain' => $countp   ]);  	
}
elseif($countp!=0){ 
$updatee = \DB::table('belitsearch')
->where([['belitsearch.bls_codbelit', '=', $id],['belitsearch.bls_active', '=', '0'], ])  ->
 update(['belitsearch.bls_active' => 0  , 'belitsearch.bls_remain' => $countp   ]);
}

$nametr = Session::flash('statust',  $lngmenu->lng_wsuccess);
$nametrt = Session::flash('sessurl', 'viewsmybelit');
return view('user.success', [ 'lngmenus' => $lngmenus , 'lngmenu' => $lngmenu ]);

    		 



}	else if (Session::get('activeuser')==0){    return redirect('user/activition'); }
else if (empty(Session::has('signstudent'))){   return redirect('user/sign-in'); } }
}		



	
	public function viewsmybelit(){
	if (Session::has('signuser')){ 
		if (Session::get('activeuser')==1){ 
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first(); 
$admins = \DB::table('belitrezerv')
->join('belitsearch', 'belitrezerv.blr_codbelit', '=', 'belitsearch.bls_codbelit')
->join('user', 'belitrezerv.blr_from', '=', 'user.id')
->where([['belitrezerv.id', '<>',  '0'], ['belitrezerv.blr_arou', '=',  '4'], ['belitrezerv.blr_from', '=',  Session::get('iduser')],  ])->orderBy('belitrezerv.id', 'desc')->get();
 return view('user.viewsmybelit' , ['lngmenus' => $lngmenus , 'lngmenu' => $lngmenu, 'admins' => $admins     ]);
}	else if (Session::get('activeuser')==0){    return redirect('user/activition'); }
else if (empty(Session::has('signstudent'))){   return redirect('user/sign-in'); } }
}		


	
	public function mybelituser($id){
	if (Session::has('signuser')){ 
		if (Session::get('activeuser')==1){ 
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();
 
$admins = \DB::table('belitrezerv')
->join('belit', 'belitrezerv.blr_codrezerv', '=', 'belit.bel_codrezerv')
->join('user', 'belitrezerv.blr_from', '=', 'user.id')
->where([['belitrezerv.id', '<>',  '0'], ['belitrezerv.blr_status', '=',  '2'], ['belitrezerv.blr_arou', '=',  '4'], ['belit.bel_codrezerv', '=',  $id], ['belitrezerv.blr_arou', '=',  '4'] , ['belitrezerv.blr_from', '=',  Session::get('iduser')],  ])->orderBy('belitrezerv.id', 'desc')->limit(1)->get();

 
 return view('user.mybelit' , ['lngmenus' => $lngmenus , 'lngmenu' => $lngmenu, 'admins' => $admins     ]);
}	else if (Session::get('activeuser')==0){    return redirect('user/activition'); }
else if (empty(Session::has('signstudent'))){   return redirect('user/sign-in'); } }
}		



	
	public function mybelituserprint($id){
	if (Session::has('signuser')){ 
		if (Session::get('activeuser')==1){ 
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();
 
$admins = \DB::table('belitrezerv')
->join('belit', 'belitrezerv.blr_codrezerv', '=', 'belit.bel_codrezerv')
->join('user', 'belitrezerv.blr_from', '=', 'user.id')
->where([['belitrezerv.id', '<>',  '0'], ['belitrezerv.blr_status', '=',  '2'], ['belitrezerv.blr_arou', '=',  '4'], ['belit.bel_codrezerv', '=',  $id], ['belitrezerv.blr_arou', '=',  '4'] , ['belitrezerv.blr_from', '=',  Session::get('iduser')],  ])->orderBy('belitrezerv.id', 'desc')->limit(1)->get();

 
 return view('user.mybelitprint' , ['lngmenus' => $lngmenus , 'lngmenu' => $lngmenu, 'admins' => $admins     ]);
}	else if (Session::get('activeuser')==0){    return redirect('user/activition'); }
else if (empty(Session::has('signstudent'))){   return redirect('user/sign-in'); } }
}		


	
	public function deletmybelit($id){
	if (Session::has('signuser')){ 
		if (Session::get('activeuser')==1){ 
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();
 
$belit=\DB::table('belit') ->where([['bel_codrezerv', '=',  $id],['bel_arou', '=',  4],['bel_iduser', '=',  Session::get('iduser')],])->orderBy('id', 'desc')->first(); 

$admins = \DB::table('belit')->where([['bel_codrezerv', '=',  $id],['bel_arou', '=',  4],['bel_iduser', '=',  Session::get('iduser')],])->delete();

$admins = \DB::table('belitrezerv')->where([['blr_codrezerv', '=',  $id],['blr_arou', '=',  4],['blr_from', '=',  Session::get('iduser')],])->delete();

$count=\DB::table('belit') ->where([['bel_bls', '=',  $belit->bel_bls],['bel_status', '=',  '0'],])->orderBy('id', 'desc')->count(); 

$countnumber=\DB::table('belit') ->where([['bel_bls', '=',  $belit->bel_bls] ,])->orderBy('id', 'desc')->count(); 	

if($count==0){
		$admins = \DB::table('belitsearch')->where('bls_codbelit', '=', $belit->bel_bls)->delete(); 	
}	else if($count!=0){
$updatee = \DB::table('belitsearch')
->where([['belitsearch.bls_codbelit', '=', $belit->bel_bls], ])  ->
 update(['belitsearch.bls_remain' => $count  ,  'belitsearch.bls_number' => $countnumber ]);  
}

		  	$nametr = Session::flash('statust',  $lngmenu->lng_wsuccess);
		  	$nametrt = Session::flash('sessurl', 'viewsmybelit');		  	
return view('user.success', ['lngmenus' => $lngmenus , 'lngmenu' => $lngmenu ]);
 
}	else if (Session::get('activeuser')==0){    return redirect('user/activition'); }
else if (empty(Session::has('signstudent'))){   return redirect('user/sign-in'); } }
}		




	
	public function viewsfinical(){
	if (Session::has('signuser')){ 
		if (Session::get('activeuser')==1){ 
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();
 
$admins = \DB::table('user') 
->join('marsole', 'user.user_ncode', '=', 'marsole.mar_codmoshtari')  
->join('finicals', 'marsole.id', '=', 'finicals.finical_marid')  
->where([ 
    ['finicals.finical_iduser', '=', Session::get('iduser')] ,  
    ['finicals.finical_arou', '=', '4'] , ])
    ->orderBy('finicals.id', 'desc')->get();

 


 
 return view('user.viewsfinical' , ['lngmenus' => $lngmenus , 'lngmenu' => $lngmenu, 'admins' => $admins     ]);
}	else if (Session::get('activeuser')==0){    return redirect('user/activition'); }
else if (empty(Session::has('signstudent'))){   return redirect('user/sign-in'); } }
}		





	public function finicaluser($id  ){
	if (Session::has('signuser')){ 
		if (Session::get('activeuser')==1){ 
 


$users =  \DB::table('user')->where('id', '=', Session::get('iduser'))  ->orderBy('id', 'desc')->first();
$showadres=$users->user_showadres;
if($showadres=='0'){   return redirect('user/buyadresturkey'); } else {

$admins = \DB::table('user') 
->join('marsole', 'user.user_ncode', '=', 'marsole.mar_codmoshtari')  
->join('finicals', 'marsole.id', '=', 'finicals.finical_marid')  
->where([ 
    ['finicals.finical_iduser', '=', Session::get('iduser')] ,  
    ['finicals.id', '=', $id] ,  
    ['finicals.finical_arou', '=', '4'] , ])
    ->orderBy('finicals.id', 'desc')->get();



$getwaypays=\DB::table('getwaypay')->where('id', '=', '2')   ->orderBy('id' )->get();



//mycharge 
$charges = \DB::table('user') 
->join('charge', 'user.id', '=', 'charge.charge_iduser') 
->join('finicals', 'charge.charge_finical', '=', 'finicals.id') 
->where([
    ['charge.charge_arou', '=', 4],
    ['charge.charge_iduser', '=', Session::get('iduser')],
    ['finicals.finical_payment', '=', 1],
    ['finicals.finical_inc', '=', 5],])
    ->orderBy('charge.charge_id', 'desc')->get();
$chargepaymy=0;
foreach($charges as $charge){ $chargepaymy=$charge->charge_pay+$chargepaymy; }




 //supcharge  
$charges = \DB::table('user') 
->join('charge', 'user.id', '=', 'charge.charge_iduser')  
->join('finicals', 'charge.charge_finical', '=', 'finicals.id') 
->where([
    ['charge.charge_arou', '=', 4],
    ['charge.charge_iduser', '=', Session::get('iduser')],
    ['finicals.finical_payment', '=', 1],
    ['finicals.finical_inc', '=', 6],])
    ->orderBy('charge.charge_id', 'desc')->get();
$chargepaysup=0;
foreach($charges as $charge){ $chargepaysup=$charge->charge_pay+$chargepaysup; }



 //odat  
$charges = \DB::table('user') 
->join('charge', 'user.id', '=', 'charge.charge_iduser')  
->join('finicals', 'charge.charge_finical', '=', 'finicals.id') 
->where([
    ['charge.charge_arou', '=', 4],
    ['charge.charge_iduser', '=', Session::get('iduser')],
    ['finicals.finical_payment', '=', 1],
    ['finicals.finical_inc', '=', 7],])
    ->orderBy('charge.charge_id', 'desc')->get();
$chargepayodat=0;
foreach($charges as $charge){ $chargepayodat=$charge->charge_pay+$chargepayodat; }



//pardakht 
$charges = \DB::table('user') 
->join('charge', 'user.id', '=', 'charge.charge_iduser')  
->join('finicals', 'charge.charge_finical', '=', 'finicals.id') 
->where([
    ['charge.charge_arou', '=', 4],
    ['charge.charge_iduser', '=', Session::get('iduser')],
    ['finicals.finical_payment', '=', 1],
    ['finicals.finical_inc', '=', 3],])
    ->orderBy('charge.charge_id', 'desc')->get();
$chargepaypar=0;
foreach($charges as $charge){ $chargepaypar=$charge->charge_pay+$chargepaypar; }


 //bisinis  
$charges = \DB::table('user') 
->join('charge', 'user.id', '=', 'charge.charge_iduser')  
->join('finicals', 'charge.charge_finical', '=', 'finicals.id') 
->where([
    ['charge.charge_arou', '=', 4],
    ['charge.charge_iduser', '=', Session::get('iduser')],
    ['finicals.finical_payment', '=', 1],
    ['finicals.finical_inc', '=', 8],])
    ->orderBy('charge.charge_id', 'desc')->get();
$chargepaybisi=0;
foreach($charges as $charge){ $chargepaybisi=$charge->charge_pay+$chargepaybisi; }


//jamkol
$chargepay= ($chargepaysup +  $chargepaymy  + $chargepaybisi ) -  ($chargepaypar + $chargepayodat) ;
 

 

$chargeac=$chargepay;




 
 return view('user.finicaluser' , [ 'admins' => $admins  , 'getwaypays' => $getwaypays , 'chargeac' => $chargeac     ]);
 }
 
}	else if (Session::get('activeuser')==0){    return redirect('user/activition'); }
else if (empty(Session::has('signstudent'))){   return redirect('user/sign-in'); } }
}		




		
	public function finicaluserpost($id , Request $request){
if (Session::has('signuser')){ 

 
$updatee = \DB::table('finicals')
->where([['finical_iduser', '=', Session::get('iduser')],['id', '=', $id],['finical_arou', '=', '4'], ])  ->
 update([  'finical_inc' => '4' ,    ]); 
 
	
 $admins = \DB::table('charge')->where([ ['charge_finical', '=', $id], ])  ->delete(); 	
		  	
		  	    	
DB::table('charge')->insert([
    ['charge_pay' => $request->pay ,     'charge_createdatdate' =>  date('Y-m-d H:i:s') , 'charge_arou' => 4 ,  'charge_iduser' => Session::get('iduser') ,  'charge_finical' => $id  ]
]);	    	

  
  return redirect('zarinpal/epayo.php?id='.$id.'');
 


		 }	
else{ return redirect('user/sign-in'); }
				}
   	 







	public function finicalpost($id , $num , Request $request){
	if (Session::has('signuser')){ 
		if (Session::get('activeuser')==1){ 
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();
 
  	$this->validate($request,[
    			'name' => 'required',
    		],[
    			'name.required' => $lngmenu->lng_wgetway.' ! '.$lngmenu->lng_wnotelq,
    		]);  


$admins = \DB::table('belitrezerv')
->join('belit', 'belitrezerv.blr_codrezerv', '=', 'belit.bel_codrezerv')
->join('user', 'belitrezerv.blr_from', '=', 'user.id')
->join('finicals', 'belitrezerv.blr_codrezerv', '=', 'finicals.finical_codrezerv')
->where([['belitrezerv.id', '<>',  '0'] , ['user.id', '=',  Session::get('iduser')], ['belitrezerv.blr_arou', '=',  '4'], ['belit.bel_bls', '=', $id],['belit.bel_codrezerv', '=', $num], ]) ->orderBy('belit.bel_codrezerv', 'desc')->limit(1)->first();	

if($request->name == '1' ){
 require_Once(public_path('/../bmt/lib/nusoap.php'));
 include_once(public_path('/../bmt/lib/class.payrequest.php'));	
return redirect('bmt/epayo.php?id='.$admins->finical_codrezerv.'');
}

else if($request->name == '2' ){
return redirect('zarinpal/epayo.php?id='.$admins->finical_number.'');
}		
 
 	 

}	else if (Session::get('activeuser')==0){    return redirect('user/activition'); }
else if (empty(Session::has('signstudent'))){   return redirect('user/sign-in'); } }
}		





	public function zarinpal($id){
	if (Session::has('signuser')){ 
		if (Session::get('activeuser')==1){ 
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();
 
$admins = \DB::table('finicals')
->where([['finicals.id', '=', $id],['finicals.finical_iduser', '=', Session::get('idstudent')], ]) ->orderBy('finicals.id', 'desc')->first();		

return redirect('zarinpal/request.php?id='.$admins->finical_number.'');  

}	else if (Session::get('activeuser')==0){    return redirect('user/activition'); }
else if (empty(Session::has('signstudent'))){   return redirect('user/sign-in'); } }
}		


	 
			 
  	public function errorstudent(){
	if (Session::has('signuser')){ 
		if (Session::get('activeuser')==1){ 
		
 
$nametr = Session::flash('statust',  'پرداخت فاکتور انجام نشد ');
$nametrt = Session::flash('sessurl', 'viewsfinical');	
return view('user.error');

}	else if (Session::get('activeuser')==0){    return redirect('user/activition'); }
else if (empty(Session::has('signstudent'))){   return redirect('user/sign-in'); } }
}		

		


			 
  	public function successfinical(){
	if (Session::has('signuser')){ 
		if (Session::get('activeuser')==1){ 
		
 
$nametr = Session::flash('statust',  'پرداخت فاکتور باموفقیت انجام شد ');
$nametrt = Session::flash('sessurl', 'viewsfinical');	
return view('user.success');

}	else if (Session::get('activeuser')==0){    return redirect('user/activition'); }
else if (empty(Session::has('signstudent'))){   return redirect('user/sign-in'); } }
}		

		



		
	public function adduserfruser(Request $request){	

$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();
 
 
 
DB::table('statics')->insert([
    ['static_ip' => $request->ip() ,  'static_url' => $request->url() ,    'static_name' => "$lngmenu->lng_wregus" ,   'static_createdatdate' =>  date('Y-m-d H:i:s') ]
]);

 return view('user.adduser' , ['lngmenus' => $lngmenus , 'lngmenu' => $lngmenu    ]);
 
				}




public function adduserfruserPost(Request $request)
    {   	
 $lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();
  	
    	$this->validate($request,[
    			'username' => 'required|min:5|max:35|unique:user,user_username,$request->username',
    			'userpassword' => 'required|min:5|max:35|confirmed'
    		],[
    			'username.required' => $lngmenu->lng_wusername.' ! '.$lngmenu->lng_wnotelq,
    			'username.min' => $lngmenu->lng_wusername.' ! '.$lngmenu->lng_wshort,
    			'username.max' => $lngmenu->lng_wusername.' ! '.$lngmenu->lng_wlong,
    			'username.unique' => $lngmenu->lng_welquser,
    			'userpassword.required' =>  $lngmenu->lng_wpassword.' ! '.$lngmenu->lng_wnotelq,
    			'userpassword.min' =>  $lngmenu->lng_wpassword.' ! '.$lngmenu->lng_wshort,
    			'userpassword.max' =>  $lngmenu->lng_wpassword.' ! '.$lngmenu->lng_wlong,
    			'userpassword.confirmed' =>  $lngmenu->lng_wconfpassword,
    		]);
  $img='demowhite.jpg';     		 
$encryptedPassword = \Crypt::encrypt($request->userpassword);
$decryptedPassword = \Crypt::decrypt($encryptedPassword);
		
DB::table('user')->insert([
    ['user_username' => $request->username , 'user_password' => $encryptedPassword ,   'user_createdatdate' =>  date('Y-m-d H:i:s') , 'user_active' => 0 , 'user_img' => $img]
]);

$users = DB::table('user')->where('user_username', $request->username)->first();
$userscou = DB::table('user')->where('user_username', $request->username)->count();

$id_db= $users->id; 
$password_db= $users->user_password; 
 

$admins = DB::table('user')->where([
    ['user_username',  $request->username],
])->first();
if($admins){

$password_db= $admins->user_password; 
$decryptedPassword =  Crypt::decrypt($password_db);
$userscou = DB::table('user')->where([
    ['user_username',  $request->username],
])->count();
$id_db= $admins->id;
$activeadmin= $admins->user_active; 
$username_db= $admins->user_username; 
$password_db= $admins->user_password; 
$username_log = $request->username; 
if(($username_log == $username_db)&&( $decryptedPassword == $request->userpassword)){
	
	Session::set('iduser', $id_db);
	Session::set('signuser', $username_db);
	Session::set('activeuser', $activeadmin);

$adminslp = \DB::table('user')->where('id', '=', $id_db)  ->orderBy('id', 'desc')->first();
$logindatepas=$adminslp->user_loginatdate;	

$admimg=$adminslp->user_img;
if(empty($admimg)){$admimg='user2x.png';}	
	Session::set('logindatepasus', $logindatepas);
	Session::set('usimg', $admimg);
	$updatee = \DB::table('user')->where('id', '=', Session::get('iduser'))  ->update(['user_loginatdate' => date('Y-m-d H:i:s') ,    'user_ip' => $request->ip()  ]); 
			return redirect('user/panel'); 
		} 
   }
   }
	





	
	public function marketing(){
	if (Session::has('signuser')){ 
		if (Session::get('activeuser')==1){ 
		
 
$admins = \DB::table('user')    
->where([ 
    ['user.user_idmoaref', '=', Session::get('iduser')] ,    ]) ->orderBy('user.id', 'desc')->get();
 
$users = \DB::table('user')    
->where([ 
    ['user.id', '=', Session::get('iduser')] ,    ]) ->orderBy('user.id', 'desc')->first();
 
 
$mngindexs = \DB::table('mngindex') ->where('id', '=', '1')->orderBy('id', 'desc')->first();
 
 return view('user.viewsmarketing' , [ 'admins' => $admins ,  'users' => $users ,  'mngindexs' => $mngindexs    ]);
 
 
}	else if (Session::get('activeuser')==0){    return redirect('user/activition'); }
else if (empty(Session::has('signstudent'))){   return redirect('user/sign-in'); } }
}		





	   
		
		
	public function viewsperiodsstudent(){

	if (Session::has('signstudent')){ 
		if (Session::get('activestudent')==1){ 
		
$admins = \DB::table('level')
->join('period', 'level.id', '=', 'period.period_level')
->where([['period.period_active', '=', 1], ])  ->orderBy('period.id', 'desc')->get();

return view('student.viewsperiods', ['admins' => $admins ]);
}	else if (Session::get('activestudent')==0){    return redirect('student/activition'); }
else if (empty(Session::has('signstudent'))){   return redirect('student/sign-in'); } }
}		





		
		
	public function viewsmyperiodsstudent(){

	if (Session::has('signstudent')){ 
		if (Session::get('activestudent')==1){ 
		
$admins = \DB::table('students')
->join('liststudentterm', 'students.id', '=', 'liststudentterm.liststud_idstudent')
->join('finicals', 'liststudentterm.liststud_finical', '=', 'finicals.id')
->join('period', 'liststudentterm.liststud_period', '=', 'period.id')
->where([['finicals.finical_payment', '=', 1],['finicals.finical_iduser', '=', Session::get('idstudent')], ]) ->orderBy('period.id', 'desc')->get();

return view('student.viewsmyperiods', ['admins' => $admins ]);
}	else if (Session::get('activestudent')==0){    return redirect('student/activition'); }
else if (empty(Session::has('signstudent'))){   return redirect('student/sign-in'); } }
}		



				

	public function editperiodsstudent($id){
	if (Session::has('signstudent')){ 
		if (Session::get('activestudent')==1){ 
	Session::put('idimg', $id);
	
$admins = \DB::table('level')
->join('period', 'level.id', '=', 'period.period_level')
->where([['period.period_active', '=', 1], ['period.id', '=', $id], ])  ->orderBy('period.id', 'desc')->get();
	 
$levels = \DB::table('level') ->orderBy('id', 'desc')->get();
$terms = \DB::table('term')->where([['term_period', '=', $id ], ['term_active', '=', 1 , ]])  ->orderBy('id', 'desc')->get();

return view('student.editperiod', ['admins' => $admins , 'levels' => $levels, 'terms' => $terms  ]);

}	else if (Session::get('activestudent')==0){    return redirect('student/activition'); }
else if (empty(Session::has('signstudent'))){   return redirect('student/sign-in'); } }
}




	public function edittermstudent($id){
	if (Session::has('signstudent')){ 
		if (Session::get('activestudent')==1){  
	Session::put('idimg', $id);
	
		
$admins = \DB::table('period')
->join('term', 'period.id', '=', 'term.term_period')
->where([['period.period_active', '=', 1],['term.term_active', '=', 1], ['term.id', '=', $id], ])  ->orderBy('term.id', 'desc')->get();

$plts = \DB::table('lesson')
->join('perslesonterm', 'lesson.id', '=', 'perslesonterm.plt_lesson')
->where('perslesonterm.plt_term', '=', $id)  ->orderBy('perslesonterm.id', 'desc')->get();

$clases = \DB::table('lesson')
->join('clas', 'lesson.id', '=', 'clas.clas_lesson')
->where([['clas.clas_term', '=', $id ],['clas.clas_active', '=', 1 ], ])  ->orderBy('clas.id', 'desc')->get();
	 
$levels = \DB::table('period') ->orderBy('id', 'desc')->get();
$terms = \DB::table('term')->where('id', '=', $id)   ->orderBy('id', 'desc')->get();
$lessons=\DB::table('lesson')->where('lesson_active', '=', 1)   ->orderBy('id', 'desc')->get();

$wperiod = \ DB::table('term')->where('id', $id)->first();
$wlevel = \ DB::table('period')->where('id', $wperiod->term_period)->first();


$count = \DB::table('students')
->join('liststudentterm', 'students.id', '=', 'liststudentterm.liststud_idstudent')
->join('period', 'liststudentterm.liststud_period', '=', 'period.id')
->join('finicals', 'liststudentterm.liststud_finical', '=', 'finicals.id')
->where([['period.id', '=', $wperiod->term_period],['finicals.finical_iduser', '=', Session::get('idstudent')],['finicals.finical_payment', '=', 1], ]) ->orderBy('finicals.id', 'desc')->count();



return view('student.editterm', ['admins' => $admins , 'levels' => $levels, 'terms' => $terms , 'lessons' => $lessons , 'plts' => $plts  , 'clases' => $clases  , 'wperiod' => $wperiod , 'wlevel' => $wlevel    , 'count' => $count    ]); 
}	else if (Session::get('activestudent')==0){    return redirect('student/activition'); }
else if (empty(Session::has('signstudent'))){   return redirect('student/sign-in'); } }
}

 

	public function finical($id){
	if (Session::has('signstudent')){ 
		if (Session::get('activestudent')==1){  
$_SESSION['signstudent']=true;

$admins = \DB::table('students')
->join('liststudentterm', 'students.id', '=', 'liststudentterm.liststud_idstudent')
->join('period', 'liststudentterm.liststud_period', '=', 'period.id')
->join('finicals', 'liststudentterm.liststud_finical', '=', 'finicals.id')
->where([['finicals.id', '=', $id],['finicals.finical_iduser', '=', Session::get('idstudent')], ]) ->orderBy('finicals.id', 'desc')->get();


$getwaypays=\DB::table('getwaypay')->where('getway_active', '=', 1)   ->orderBy('id' )->get();


return view('student.finical', ['admins' => $admins  , 'getwaypays' => $getwaypays    ]); 

}	else if (Session::get('activestudent')==0){    return redirect('student/activition'); }
else if (empty(Session::has('signstudent'))){   return redirect('student/sign-in'); } }
}

 











	public function edittermstudentstudentPost($id , Request $request){
	if (Session::has('signstudent')){ 
		if (Session::get('activestudent')==1){  
		
 	$this->validate($request,[
    			'tuition' => 'required|max:10',
    		],[
    			'tuition.required' => 'مبلغ شهریه تعریف نشده است',
    			'tuition.max' => 'مبلغ شهریه نامعتبر',
    		]);   



$count = \DB::table('students')
->join('liststudentterm', 'students.id', '=', 'liststudentterm.liststud_idstudent')
->join('period', 'liststudentterm.liststud_period', '=', 'period.id')
->join('finicals', 'liststudentterm.liststud_finical', '=', 'finicals.id')
->where([['period.period_active', '=', 1],['finicals.finical_iduser', '=', Session::get('idstudent')],['period.id', '=', $request->wperiod], ])  ->orderBy('finicals.id', 'desc')->count();

if($count!='0'){
$nametr = Session::flash('statust', 'متاسفانه شما چون قبلا در این دوره ثبت نام نموده اید امکان ثبت دوباره وجود ندارد. شما می توانید از طریق پرداخت فاکتور این دوره را ثبت نام نمایید.');
		  	$nametrt = Session::flash('sessurl', 'viewsmyperiods');
	 	return view('student.error');

	
}	 	
else if ($count=='0'){ 	 	
    			
   $rnd=rand(1, 9999999);   		
DB::table('finicals')->insert([
    ['finical_arou' => 4 ,  'finical_number' => $rnd ,  'finical_inc' => 4 ,  'finical_pay' => $request->tuition   ,    'finical_payment' => 0   ,   'finical_createdatdate' =>  date('Y-m-d H:i:s')  ,   'finical_iduser' =>  Session::get('idstudent')	  ]
]); 

$users = DB::table('finicals')->where([['finical_number', '=' , $rnd],['finical_iduser', '=' ,  Session::get('idstudent')], ])  ->orderBy('id', 'desc')->first(); 

$finical= $users->id;  
DB::table('liststudentterm')->insert([
    ['liststud_idstudent' => Session::get('idstudent') ,  'liststud_level' => $request->wlevel ,  'liststud_period' => $request->wperiod ,  'liststud_term' => $id   ,    'liststud_finical' => $finical   ,   'liststud_createdatdate' =>  date('Y-m-d H:i:s')     ]
]); 
 
 
return redirect('student/viewsfinicals/finical/'.$finical.''); 
}




}	else if (Session::get('activestudent')==0){    return redirect('student/activition'); }
else if (empty(Session::has('signstudent'))){   return redirect('student/sign-in'); } }
}







		
	public function viewsfinicalsstudent(){

	if (Session::has('signstudent')){ 
		if (Session::get('activestudent')==1){ 
		
$admins = \DB::table('students')
->join('liststudentterm', 'students.id', '=', 'liststudentterm.liststud_idstudent')
->join('period', 'liststudentterm.liststud_period', '=', 'period.id')
->join('finicals', 'liststudentterm.liststud_finical', '=', 'finicals.id')
->where([['period.period_active', '=', 1],['finicals.finical_iduser', '=', Session::get('idstudent')], ])  ->orderBy('finicals.id', 'desc')->get();

return view('student.viewsfinicals', ['admins' => $admins ]);
}	else if (Session::get('activestudent')==0){    return redirect('student/activition'); }
else if (empty(Session::has('signstudent'))){   return redirect('student/sign-in'); } }
}









  




 


		
	public function viewsmyclases(){
	if (Session::has('signstudent')){ 
		if (Session::get('activestudent')==1){  

 $clases= \DB::table('lesson')
->join('clas', 'lesson.id', '=', 'clas.clas_lesson')
->join('term', 'clas.clas_term', '=', 'term.id')
->join('period', 'term.term_period', '=', 'period.id')
->where('clas.clas_term', '<>', 0)  ->orderBy('clas.id', 'desc')->get();

 $adminss= \DB::table('lesson')
->join('clas', 'lesson.id', '=', 'clas.clas_lesson')
->where([['clas.clas_term', '<>', 0],['clas.clas_active', '=', 1], ])  ->orderBy('clas.id', 'desc')->get();

$admins =  \DB::table('students')
->join('liststudentterm', 'students.id', '=', 'liststudentterm.liststud_idstudent')
->join('finicals', 'liststudentterm.liststud_finical', '=', 'finicals.id')
->join('clas', 'liststudentterm.liststud_term', '=', 'clas.clas_term')
->where([['finicals.finical_payment', '=', 1],['finicals.finical_iduser', '=', Session::get('idstudent')], ]) ->orderBy('clas.id', 'desc')->get();

return view('student.viewsclases', ['admins' => $admins , 'clases' => $clases ]);

}	else if (Session::get('activestudent')==0){    return redirect('student/activition'); }
else if (empty(Session::has('signstudent'))){   return redirect('student/sign-in'); } }
}		






	public function editmyclas($id){
	if (Session::has('signstudent')){ 
		if (Session::get('activestudent')==1){  
	Session::put('idimg', $id);
	
 $professors= \DB::table('professors')->where('professor_active', '=', 1)  ->orderBy('id', 'desc')->get();
 
 
$admins = \DB::table('students')
->join('liststudentterm', 'students.id', '=', 'liststudentterm.liststud_idstudent')
->join('period', 'liststudentterm.liststud_period', '=', 'period.id')
->join('finicals', 'liststudentterm.liststud_finical', '=', 'finicals.id')
->where([['period.period_active', '=', 1],['finicals.finical_iduser', '=', Session::get('idstudent')], ])  ->orderBy('finicals.id', 'desc')->get();
 
 
 
 
 
 $count= \DB::table('lesson')
->join('clas', 'lesson.id', '=', 'clas.clas_lesson')
->join('period', 'clas.clas_period', '=', 'period.id')
->join('liststudentterm', 'period.id', '=', 'liststudentterm.liststud_period')
->join('finicals', 'liststudentterm.liststud_finical', '=', 'finicals.id')
->where([['period.period_active', '=', 1],['clas.id', '=', $id],['finicals.finical_payment', '=', 1], ['liststudentterm.liststud_idstudent', '=', Session::get('idstudent')], ])  ->orderBy('clas.id', 'desc')->count();

if($count=='0'){
$nametr = Session::flash('statust', 'شما تا زمان ثبت نام در دوره مربوطه ، دسترسی به کلاسهای آن دوره را ندارید.');
		  	$nametrt = Session::flash('sessurl', 'viewsmyperiods');
	 	return view('student.error');

	
}	 	
else if ($count!='0'){ 


 $admins= \DB::table('lesson')
->join('clas', 'lesson.id', '=', 'clas.clas_lesson')
->where('clas.id', '=', $id)  ->orderBy('clas.id', 'desc')->get();





 $adminsp= \DB::table('clas')->where('id', '=', $id)  ->orderBy('id', 'desc')->first();

 $terms= \DB::table('term')->where('id', '=', $adminsp->clas_term)  ->orderBy('id', 'desc')->get();

 $sisions= \DB::table('sision')->where([['sision_clas', '=', $id],['sision_active', '=', 1], ])  ->orderBy('id', 'desc')->get();

 $professorsselecs= \DB::table('professors')->where('id', '=', $adminsp->clas_professor)  ->orderBy('id', 'desc')->get();

$ways = \DB::table('period')
->join('term', 'period.id', '=', 'term.term_period')
->join('clas', 'term.id', '=', 'clas.clas_term')
->where('clas.id', '=', $id)  ->orderBy('term.id', 'desc')->get(); 




 $listexams= \DB::table('exam')
->join('listexam', 'exam.id', '=', 'listexam.listex_exam')
->where([
    ['exam.exam_arou', '=', 1],
    ['listexam.listex_clas', '=', $id],])
  ->orderBy('listexam.id', 'desc')->get();


 


 $listquiz= \DB::table('exam')
->join('listexam', 'exam.id', '=', 'listexam.listex_exam')
->where([
    ['exam.exam_arou', '=', 2],
    ['listexam.listex_clas', '=', $id],])
  ->orderBy('listexam.id', 'desc')->get();


 




return view('student.editclas', ['admins' => $admins , 'ways' => $ways   , 'professors' => $professors  , 'professorsselecs' => $professorsselecs  , 'terms' => $terms   , 'sisions' => $sisions  , 'listexams' => $listexams  ,   'listquiz' => $listquiz    ]); 
}

}	else if (Session::get('activestudent')==0){    return redirect('student/activition'); }
else if (empty(Session::has('signstudent'))){   return redirect('student/sign-in'); } }
}




	public function editmysision($id){
	if (Session::has('signstudent')){ 
		if (Session::get('activestudent')==1){  
	Session::put('idimg', $id);
	

 $professors= \DB::table('professors')->where('professor_active', '=', 1)  ->orderBy('id', 'desc')->get();
 $admins= \DB::table('lesson')
->join('clas', 'lesson.id', '=', 'clas.clas_lesson')
->join('sision', 'clas.id', '=', 'sision.sision_clas')
->where('sision.id', '=', $id)  ->orderBy('sision.id', 'desc')->get();

 $adminsp= \DB::table('sision')->where('id', '=', $id)  ->orderBy('id', 'desc')->first(); 
 $terms= \DB::table('clas')->where('id', '=', $adminsp->sision_clas)  ->orderBy('id', 'desc')->get();
 $sisions= \DB::table('sision')->where('sision_clas', '=', $id)  ->orderBy('id', 'desc')->get();

$ways = \DB::table('period')
->join('term', 'period.id', '=', 'term.term_period')
->join('clas', 'term.id', '=', 'clas.clas_term')
->join('sision', 'clas.id', '=', 'sision.sision_clas')
->where('sision.id', '=', $id)  ->orderBy('term.id', 'desc')->get(); 

 $wsisions= \DB::table('sision')->where('id', '=', $id)  ->orderBy('id', 'desc')->first(); 
 $wasisions= \DB::table('sision')->where('id', '=', $id)  ->orderBy('id', 'desc')->get(); 
 
 $wclases= \DB::table('clas')->where('id', '=', $wsisions->sision_clas)   ->first();
 $waclases= \DB::table('clas')->where('id', '=', $wsisions->sision_clas)  ->orderBy('id', 'desc')->get();
 
 $wterms= \DB::table('term')->where('id', '=', $wclases->clas_term)  ->orderBy('id', 'desc')->first();
 $waterms= \DB::table('term')->where('id', '=', $wclases->clas_term)  ->orderBy('id', 'desc')->get();
 
 $wperiods= \DB::table('period')->where('id', '=', $wterms->term_period)  ->orderBy('id', 'desc')->first();
 $waperiods= \DB::table('period')->where('id', '=', $wterms->term_period)  ->orderBy('id', 'desc')->get();
 
 $professorsselecs= \DB::table('professors')->where('id', '=', $wclases->clas_professor)  ->orderBy('id', 'desc')->get();

return view('student.editsision', ['admins' => $admins , 'ways' => $ways   , 'professors' => $professors  , 'professorsselecs' => $professorsselecs  , 'terms' => $terms   , 'sisions' => $sisions   , 'wasisions' => $wasisions   , 'waclases' => $waclases   , 'waterms' => $waterms   , 'waperiods' => $waperiods   ]); 

}	else if (Session::get('activestudent')==0){    return redirect('student/activition'); }
else if (empty(Session::has('signstudent'))){   return redirect('student/sign-in'); } }
}



		
	public function viewsmypresent(){
	if (Session::has('signstudent')){ 
		if (Session::get('activestudent')==1){  

 $clases= \DB::table('lesson')
->join('clas', 'lesson.id', '=', 'clas.clas_lesson')
->join('term', 'clas.clas_term', '=', 'term.id')
->join('period', 'term.term_period', '=', 'period.id')
->where('clas.clas_term', '<>', 0)  ->orderBy('clas.id', 'desc')->get();

 $adminss= \DB::table('lesson')
->join('clas', 'lesson.id', '=', 'clas.clas_lesson')
->where([['clas.clas_term', '<>', 0],['clas.clas_active', '=', 1], ])  ->orderBy('clas.id', 'desc')->get();

$admins =  \DB::table('students')
->join('liststudentterm', 'students.id', '=', 'liststudentterm.liststud_idstudent')
->join('finicals', 'liststudentterm.liststud_finical', '=', 'finicals.id')
->join('clas', 'liststudentterm.liststud_term', '=', 'clas.clas_term')
->where([['finicals.finical_payment', '=', 1],['finicals.finical_iduser', '=', Session::get('idstudent')], ]) ->orderBy('clas.id', 'desc')->get();

return view('student.viewspresent', ['admins' => $admins , 'clases' => $clases ]);

}	else if (Session::get('activestudent')==0){    return redirect('student/activition'); }
else if (empty(Session::has('signstudent'))){   return redirect('student/sign-in'); } }
}		











	public function editpresent($id){
	if (Session::has('signstudent')){ 
		if (Session::get('activestudent')==1){  
	Session::put('idimg', $id);
	
 $professors= \DB::table('professors')->where('professor_active', '=', 1)  ->orderBy('id', 'desc')->get();
 
 
$admins = \DB::table('students')
->join('liststudentterm', 'students.id', '=', 'liststudentterm.liststud_idstudent')
->join('period', 'liststudentterm.liststud_period', '=', 'period.id')
->join('finicals', 'liststudentterm.liststud_finical', '=', 'finicals.id')
->where([['period.period_active', '=', 1],['finicals.finical_iduser', '=', Session::get('idstudent')], ])  ->orderBy('finicals.id', 'desc')->get();
 
 $count= \DB::table('lesson')
->join('clas', 'lesson.id', '=', 'clas.clas_lesson')
->join('period', 'clas.clas_period', '=', 'period.id')
->join('liststudentterm', 'period.id', '=', 'liststudentterm.liststud_period')
->join('finicals', 'liststudentterm.liststud_finical', '=', 'finicals.id')
->where([['period.period_active', '=', 1],['clas.id', '=', $id],['finicals.finical_payment', '=', 1], ['liststudentterm.liststud_idstudent', '=', Session::get('idstudent')], ])  ->orderBy('clas.id', 'desc')->count();

if($count=='0'){
$nametr = Session::flash('statust', 'شما تا زمان ثبت نام در دوره مربوطه ، دسترسی به کلاسهای آن دوره را ندارید.');
		  	$nametrt = Session::flash('sessurl', 'viewsmyperiods');
	 	return view('student.error');
	
}	 	
else if ($count!='0'){ 

 $admins= \DB::table('lesson')
->join('clas', 'lesson.id', '=', 'clas.clas_lesson')
->where('clas.id', '=', $id)  ->orderBy('clas.id', 'desc')->get();

 $adminsp= \DB::table('clas')->where('id', '=', $id)  ->orderBy('id', 'desc')->first();

 $terms= \DB::table('term')->where('id', '=', $adminsp->clas_term)  ->orderBy('id', 'desc')->get();

 $sisions= \DB::table('sision')->where([['sision_clas', '=', $id],['sision_active', '=', 1], ])  ->orderBy('id', 'desc')->get();



$liststudentts = \DB::table('students')
->join('liststudentsision', 'students.id', '=', 'liststudentsision.listsis_idstudent')
->join('sision', 'liststudentsision.listsis_sision', '=', 'sision.id')
->where([['liststudentsision.listsis_clas', '=', $id],['students.id', '=', Session::get('idstudent') ],['sision.sision_active', '=', 1  ], ])->orderBy('liststudentsision.listsis_sision', 'desc')->get();  
 


 $professorsselecs= \DB::table('professors')->where('id', '=', $adminsp->clas_professor)  ->orderBy('id', 'desc')->get();

$ways = \DB::table('period')
->join('term', 'period.id', '=', 'term.term_period')
->join('clas', 'term.id', '=', 'clas.clas_term')
->where('clas.id', '=', $id)  ->orderBy('term.id', 'desc')->get(); 



return view('student.editpresent', ['admins' => $admins , 'ways' => $ways   , 'professors' => $professors  , 'professorsselecs' => $professorsselecs  , 'terms' => $terms   , 'sisions' => $sisions  , 'liststudentts' => $liststudentts    ]); 
}

}	else if (Session::get('activestudent')==0){    return redirect('student/activition'); }
else if (empty(Session::has('signstudent'))){   return redirect('student/sign-in'); } }
}










		
	public function viewsmyexam(){
	if (Session::has('signstudent')){ 
		if (Session::get('activestudent')==1){  
 
$admins =  \DB::table('students')
->join('liststudentterm', 'students.id', '=', 'liststudentterm.liststud_idstudent')
->join('finicals', 'liststudentterm.liststud_finical', '=', 'finicals.id')
->join('clas', 'liststudentterm.liststud_term', '=', 'clas.clas_term')
->join('listexam', 'clas.id', '=', 'listexam.listex_clas')
->join('exam', 'listexam.listex_exam', '=', 'exam.id')
->where([['finicals.finical_payment', '=', 1],['finicals.finical_iduser', '=', Session::get('idstudent')],['exam.exam_arou', '=', 1], ]) ->orderBy('listexam.id', 'desc')->get();

return view('student.viewsexams', ['admins' => $admins ]);

}	else if (Session::get('activestudent')==0){    return redirect('student/activition'); }
else if (empty(Session::has('signstudent'))){   return redirect('student/sign-in'); } }
}		





	public function editexamst($id){
	if (Session::has('signstudent')){ 
		if (Session::get('activestudent')==1){   


$countt =  \DB::table('students')
->join('liststudentterm', 'students.id', '=', 'liststudentterm.liststud_idstudent')
->join('finicals', 'liststudentterm.liststud_finical', '=', 'finicals.id')
->join('clas', 'liststudentterm.liststud_term', '=', 'clas.clas_term')
->join('listexam', 'clas.id', '=', 'listexam.listex_clas')
->join('exam', 'listexam.listex_exam', '=', 'exam.id')
->where([['finicals.finical_payment', '=', 1],['finicals.finical_iduser', '=', Session::get('idstudent')],['exam.exam_arou', '=', 1],['exam.id', '=', $id], ]) ->orderBy('listexam.id', 'desc')->count();


if($countt=='0'){
$nametr = Session::flash('statust', 'متاسفانه شما دسترسی به تمرین مربوطه را تا ثبت نام در دوره مربوطه نخواهید داشت.');
		  	$nametrt = Session::flash('sessurl', 'viewsexams');
	 	return view('student.error');
	
}	 	
else if ($countt!='0'){ 
	
 $examcount= \DB::table('exam') 
->join('examtest', 'exam.id', '=', 'examtest.examtest_idexam') 
->where([
    ['exam.id', '=', $id],
    ['exam.exam_arou', '=', 1],
    ['examtest.examtest_idstudent', '=', Session::get('idstudent') ], ])
    ->orderBy('examtest.id', 'desc')->count();
    
if($examcount=='0'){
DB::table('examtest')->insert([
    ['examtest_idstudent' => Session::get('idstudent') ,     'examtest_date' =>  date('Y-m-d H:i:s') , 'examtest_idexam' => $id   , 'examtest_flg' => 0      ]
]);	
}
	
 $examstests= \DB::table('exam') 
->join('examtest', 'exam.id', '=', 'examtest.examtest_idexam') 
->where([
    ['exam.id', '=', $id],
    ['exam.exam_arou', '=', 1],
    ['examtest.examtest_idstudent', '=', Session::get('idstudent') ], ])
    ->orderBy('examtest.id', 'desc')->get();
 
 $exams= \DB::table('professors') 
->join('exam', 'professors.id', '=', 'exam.exam_professor') 
->where([
    ['exam.id', '=', $id],
    ['exam.exam_arou', '=', 1], ])
    ->orderBy('exam.id', 'desc')->get();
 
 $tests= \DB::table('exam') 
->join('test', 'exam.id', '=', 'test.test_exam') 
->where([
    ['exam.id', '=', $id],
    ['exam.exam_arou', '=', 1], ])
    ->orderBy('test.id')->get();
 
 $count= \DB::table('exam') 
->join('test', 'exam.id', '=', 'test.test_exam') 
->where([
    ['exam.id', '=', $id],
    ['exam.exam_arou', '=', 1], ])
    ->orderBy('test.id', 'desc')->count();


 $examstestscount= \DB::table('examtest') 
->join('answertest', 'examtest.id', '=', 'answertest.answ_examtest') 
->where([
    ['examtest.examtest_idexam', '=', $id],
    ['answertest.answ_qst', '<>', 0],
    ['examtest.examtest_idstudent', '=', Session::get('idstudent') ], ])
    ->orderBy('examtest.id', 'desc')->count();
 
	
 $examstestscounttrue= \DB::table('examtest') 
->join('answertest', 'examtest.id', '=', 'answertest.answ_examtest') 
->where([
    ['examtest.examtest_idexam', '=', $id],
    ['answertest.answ_testtrue', '=', 1],
    ['examtest.examtest_idstudent', '=', Session::get('idstudent') ], ])
    ->orderBy('examtest.id', 'desc')->count();
 
   $examstestscountfalse=$examstestscount-$examstestscounttrue; 
   $countdontrep=$count-$examstestscount;
   $poin=(100/$count)*$examstestscounttrue;
   
   if($examcount!='0'){
   	
$updatee = \DB::table('examtest')
->where([['examtest_idstudent', '=', Session::get('idstudent')],['examtest_idexam', '=', $id], ])  ->
 update([  'examtest_poin' => $poin   ]); 
    
   	 }
   
    
return view('student.editexam', ['exams' => $exams , 'tests' => $tests   , 'count' => $count    , 'examstests' => $examstests , 'examstestscount' => $examstestscount  , 'examstestscounttrue' => $examstestscounttrue  , 'examstestscountfalse' => $examstestscountfalse  , 'countdontrep' => $countdontrep   , 'poin' => $poin   ]); 	
}
}	else if (Session::get('activestudent')==0){    return redirect('student/activition'); }
else if (empty(Session::has('signstudent'))){   return redirect('student/sign-in'); } }
}





	public function editexamstPost($id ,  Request $request ){
	if (Session::has('signstudent')){ 
		if (Session::get('activestudent')==1){   

 $tests= \DB::table('exam') 
->join('test', 'exam.id', '=', 'test.test_exam') 
->where([
    ['exam.id', '=', $id],
    ['exam.exam_arou', '=', 1], ])
    ->orderBy('test.id')->get();
    
$users = DB::table('examtest')->where([['examtest_idstudent', '=', Session::get('idstudent')],['examtest_idexam', '=', $id], ])  ->orderBy('id', 'desc')->first(); 
$idexamtest= $users->id; 

		  	$admins = \DB::table('answertest')->where([ ['answ_examtest', '=', $idexamtest], ])  ->delete(); 
		  	
$updatee = \DB::table('examtest')
->where([['examtest_idstudent', '=', Session::get('idstudent')],['examtest_idexam', '=', $id], ])  ->
 update(['examtest_flg' => 1 , 'examtest_date' => date('Y-m-d H:i:s')   ]); 
    
    foreach($tests as $test){

DB::table('answertest')->insert([
    ['answ_examtest' => $idexamtest , 'answ_idtest' =>  $test->id  ,'answ_qst' =>  0 , 'answ_key' =>  $test->test_key     ]
]);
 	
$myCheckboxes = $request->input('my_checkbo'.$test->id.'x');

if($myCheckboxes != NULL)  {
foreach($myCheckboxes as $quan) { 

if($quan==$test->test_key){ $answtesttrue=1; } else if($quan!=$test->test_key){ $answtesttrue=0; }

$updatee = \DB::table('answertest')
->where([['answ_idtest', '=', $test->id],['answ_examtest', '=', $idexamtest], ])  ->
 update(['answ_qst' => $quan , 'answ_testtrue' => $answtesttrue   ]); 
}  } 
}	
$nametr = Session::flash('statust', 'شما تمرین را با موفقیت به اتمام رساندید.');
$nametrt = Session::flash('sessurl', 'viewsexams/exam/'.$id.'');
		  return view('student.success');

}	else if (Session::get('activestudent')==0){    return redirect('student/activition'); }
else if (empty(Session::has('signstudent'))){   return redirect('student/sign-in'); } } 
}








		
	public function viewsmyquiz(){
	if (Session::has('signstudent')){ 
		if (Session::get('activestudent')==1){  
 
$admins =  \DB::table('students')
->join('liststudentterm', 'students.id', '=', 'liststudentterm.liststud_idstudent')
->join('finicals', 'liststudentterm.liststud_finical', '=', 'finicals.id')
->join('clas', 'liststudentterm.liststud_term', '=', 'clas.clas_term')
->join('listexam', 'clas.id', '=', 'listexam.listex_clas')
->join('exam', 'listexam.listex_exam', '=', 'exam.id')
->where([['finicals.finical_payment', '=', 1],['finicals.finical_iduser', '=', Session::get('idstudent')],['exam.exam_arou', '=', 2], ]) ->orderBy('listexam.id', 'desc')->get();

return view('student.viewsquiz', ['admins' => $admins ]);

}	else if (Session::get('activestudent')==0){    return redirect('student/activition'); }
else if (empty(Session::has('signstudent'))){   return redirect('student/sign-in'); } }
}		






	public function ediquizs($id){
	if (Session::has('signstudent')){ 
		if (Session::get('activestudent')==1){   


$countt =  \DB::table('students')
->join('liststudentterm', 'students.id', '=', 'liststudentterm.liststud_idstudent')
->join('finicals', 'liststudentterm.liststud_finical', '=', 'finicals.id')
->join('clas', 'liststudentterm.liststud_term', '=', 'clas.clas_term')
->join('listexam', 'clas.id', '=', 'listexam.listex_clas')
->join('exam', 'listexam.listex_exam', '=', 'exam.id')
->where([['finicals.finical_payment', '=', 1],['finicals.finical_iduser', '=', Session::get('idstudent')],['exam.exam_arou', '=', 2],['exam.id', '=', $id], ]) ->orderBy('listexam.id', 'desc')->count();


if($countt=='0'){
$nametr = Session::flash('statust', 'متاسفانه شما دسترسی به آزمون مربوطه را تا ثبت نام در دوره مربوطه نخواهید داشت.');
		  	$nametrt = Session::flash('sessurl', 'viewsquiz');
	 	return view('student.error');
	
}	 	
else if ($countt!='0'){ 
	
 $examcount= \DB::table('exam') 
->join('examtest', 'exam.id', '=', 'examtest.examtest_idexam') 
->where([
    ['exam.id', '=', $id],
    ['exam.exam_arou', '=', 2],
    ['examtest.examtest_idstudent', '=', Session::get('idstudent') ], ])
    ->orderBy('examtest.id', 'desc')->count();
    
if($examcount=='0'){
DB::table('examtest')->insert([
    ['examtest_idstudent' => Session::get('idstudent') ,     'examtest_date' =>  date('Y-m-d H:i:s') , 'examtest_idexam' => $id   , 'examtest_flg' => 0      ]
]);	
}
	
 $examstests= \DB::table('exam') 
->join('examtest', 'exam.id', '=', 'examtest.examtest_idexam') 
->where([
    ['exam.id', '=', $id],
    ['exam.exam_arou', '=', 2],
    ['examtest.examtest_idstudent', '=', Session::get('idstudent') ], ])
    ->orderBy('examtest.id', 'desc')->get();
 
 $exams= \DB::table('professors') 
->join('exam', 'professors.id', '=', 'exam.exam_professor') 
->where([
    ['exam.id', '=', $id],
    ['exam.exam_arou', '=', 2], ])
    ->orderBy('exam.id', 'desc')->get();
 
 $tests= \DB::table('exam') 
->join('test', 'exam.id', '=', 'test.test_exam') 
->where([
    ['exam.id', '=', $id],
    ['exam.exam_arou', '=', 2], ])
    ->orderBy('test.id')->get();
 
 $count= \DB::table('exam') 
->join('test', 'exam.id', '=', 'test.test_exam') 
->where([
    ['exam.id', '=', $id],
    ['exam.exam_arou', '=', 2], ])
    ->orderBy('test.id', 'desc')->count();


 $examstestscount= \DB::table('examtest') 
->join('answertest', 'examtest.id', '=', 'answertest.answ_examtest') 
->where([
    ['examtest.examtest_idexam', '=', $id],
    ['answertest.answ_qst', '<>', 0],
    ['examtest.examtest_idstudent', '=', Session::get('idstudent') ], ])
    ->orderBy('examtest.id', 'desc')->count();
 
	
 $examstestscounttrue= \DB::table('examtest') 
->join('answertest', 'examtest.id', '=', 'answertest.answ_examtest') 
->where([
    ['examtest.examtest_idexam', '=', $id],
    ['answertest.answ_testtrue', '=', 1],
    ['examtest.examtest_idstudent', '=', Session::get('idstudent') ], ])
    ->orderBy('examtest.id', 'desc')->count();
 
   $examstestscountfalse=$examstestscount-$examstestscounttrue; 
   $countdontrep=$count-$examstestscount;
   $poin=(100/$count)*$examstestscounttrue;
   
   if($examcount!='0'){
   	
$updatee = \DB::table('examtest')
->where([['examtest_idstudent', '=', Session::get('idstudent')],['examtest_idexam', '=', $id], ])  ->
 update([ 'examtest_poin' => $poin   ]); 
    
   	 }
   	 
  
 $answtests= \DB::table('test') 
->join('answertest', 'test.id', '=', 'answertest.answ_idtest') 
->where([
    ['test.test_exam', '=', $id], ])
    ->orderBy('test.id', 'desc')->get();
 
   	  
   
    
return view('student.editquiz', ['exams' => $exams , 'tests' => $tests   , 'count' => $count    , 'examstests' => $examstests , 'examstestscount' => $examstestscount  , 'examstestscounttrue' => $examstestscounttrue  , 'examstestscountfalse' => $examstestscountfalse  , 'countdontrep' => $countdontrep   , 'poin' => $poin   , 'answtests' => $answtests   ]); 	
}
}	else if (Session::get('activestudent')==0){    return redirect('student/activition'); }
else if (empty(Session::has('signstudent'))){   return redirect('student/sign-in'); } }
}




	public function ediquizspost($id ,  Request $request ){
	if (Session::has('signstudent')){ 
		if (Session::get('activestudent')==1){   

 $tests= \DB::table('exam') 
->join('test', 'exam.id', '=', 'test.test_exam') 
->where([
    ['exam.id', '=', $id],
    ['exam.exam_arou', '=', 2], ])
    ->orderBy('test.id')->get();
    
$users = DB::table('examtest')->where([['examtest_idstudent', '=', Session::get('idstudent')],['examtest_idexam', '=', $id], ])  ->orderBy('id', 'desc')->first(); 
$idexamtest= $users->id; 

		  	$admins = \DB::table('answertest')->where([ ['answ_examtest', '=', $idexamtest], ])  ->delete(); 
		  	
$updatee = \DB::table('examtest')
->where([['examtest_idstudent', '=', Session::get('idstudent')],['examtest_idexam', '=', $id], ])  ->
 update(['examtest_flg' => 1 , 'examtest_date' => date('Y-m-d H:i:s')   ]); 
    
    foreach($tests as $test){

DB::table('answertest')->insert([
    ['answ_examtest' => $idexamtest , 'answ_idtest' =>  $test->id  ,'answ_qst' =>  0 , 'answ_key' =>  $test->test_key     ]
]);
 	
$myCheckboxes = $request->input('my_checkbo'.$test->id.'x');

if($myCheckboxes != NULL)  {
foreach($myCheckboxes as $quan) { 

if($quan==$test->test_key){ $answtesttrue=1; } else if($quan!=$test->test_key){ $answtesttrue=0; }

$updatee = \DB::table('answertest')
->where([['answ_idtest', '=', $test->id],['answ_examtest', '=', $idexamtest], ])  ->
 update(['answ_qst' => $quan , 'answ_testtrue' => $answtesttrue   ]); 
}  } 
}	
$nametr = Session::flash('statust', 'شما آزمون را با موفقیت به اتمام رساندید.');
$nametrt = Session::flash('sessurl', 'viewsquiz/editquiz/'.$id.'');
		  return view('student.success');

}	else if (Session::get('activestudent')==0){    return redirect('student/activition'); }
else if (empty(Session::has('signstudent'))){   return redirect('student/sign-in'); } } 
}





		
	public function viewslistedvst(){
	if (Session::has('signstudent')){ 
		if (Session::get('activestudent')==1){  
$admins = \DB::table('students')
->join('listedivence', 'students.id', '=', 'listedivence.listedv_idstudent')
->where([['listedivence.id', '<>', 1 ],['listedivence.listedv_active', '=', 1 ],['listedivence.listedv_idstudent', '=', Session::get('idstudent')], ]) ->orderBy('listedivence.id', 'desc')->get();

return view('student.viewslistedv', ['admins' => $admins ]);
}	else if (Session::get('activestudent')==0){    return redirect('student/activition'); }
else if (empty(Session::has('signstudent'))){   return redirect('student/sign-in'); } }
}		



		
	public function editlistedvst($id){
	if (Session::has('signstudent')){ 
		if (Session::get('activestudent')==1){  
$admins = \DB::table('students')
->join('listedivence', 'students.id', '=', 'listedivence.listedv_idstudent')
->join('period', 'listedivence.listedv_period', '=', 'period.id')
->join('level', 'listedivence.listedv_level', '=', 'level.id')
->where([['listedivence.id', '=', $id ],['listedivence.listedv_active', '=', 1 ],['listedivence.listedv_idstudent', '=', Session::get('idstudent')], ]) ->orderBy('listedivence.id', 'desc')->get();

$linkk= \DB::table('listedivence')->where([['listedivence.id', '=', $id ],['listedivence.listedv_active', '=', 1 ],['listedivence.listedv_idstudent', '=', Session::get('idstudent')], ]) ->orderBy('listedivence.id', 'desc')->first();

return view('student.editlistedv', ['admins' => $admins , 'linkk' => $linkk ]);
}	else if (Session::get('activestudent')==0){    return redirect('student/activition'); }
else if (empty(Session::has('signstudent'))){   return redirect('student/sign-in'); } }
}		


	


	
	public function printedvst($id){
	if (Session::has('signstudent')){ 
		if (Session::get('activestudent')==1){ 
$admins = \DB::table('students')
->join('listedivence', 'students.id', '=', 'listedivence.listedv_idstudent')
->join('period', 'listedivence.listedv_period', '=', 'period.id')
->join('level', 'listedivence.listedv_level', '=', 'level.id')
->where([['listedivence.id', '=', $id ],['listedivence.listedv_active', '=', 1 ],['listedivence.listedv_idstudent', '=', Session::get('idstudent')], ]) ->orderBy('listedivence.id', 'desc')->get();
return view('student.printedv', ['admins' => $admins]);

}	else if (Session::get('activestudent')==0){    return redirect('student/activition'); }
else if (empty(Session::has('signstudent'))){   return redirect('student/sign-in'); } }
}


		
	public function addstudentfrstu(Request $request){	
DB::table('statics')->insert([
    ['static_ip' => $request->ip() ,  'static_url' => $request->url() ,    'static_name' => 'ثبت نام دانشجو' ,   'static_createdatdate' =>  date('Y-m-d H:i:s') ]
]);
 return view('student.addstudent'); 
				}






public function addstudentfrstupost(Request $request){  	    	
    	$this->validate($request,[
    			'username' => 'required|min:5|max:35|unique:students,student_username,$request->username',
    			'name' => 'required|min:3|max:35',
    			'email' => 'required|email',
    			'tell' => 'required|min:9|max:18',
    			'userpassword' => 'required|min:5|max:35|confirmed'
    		],[
    			'username.required' => 'لطفا نام کاربری را وارد نمایید',
    			'username.min' => 'نام کاربری شما باید بیشتر از 5 کاراکتر باشد',
    			'username.max' => 'یوزرنیم شما باید کمتر از 35 کارکتر باشد',
    			'username.unique' => 'این نام کاربری قبللا در سیستم ثبت شده است',
    			'name.required' => 'لطفا نام و نام خانوادگی را وارد نمایید',
    			'name.min' => 'نام و نام خانوادگی کوتاه است',
    			'name.max' => 'نام و نام خانوادگی طولانی است',
    			'tell.required' => 'لطفا شماره همراه را وارد نمایید',
    			'tell.min' => 'شماره همراه نامعتبر است',
    			'tell.max' => 'شماره همراه نامعتبر است',
    			'email.required' => 'پر کردن فیلد ایمیل اجباری است ',
    			'email.email' => 'فرمت ایمیل نامعتبر است',
    			'userpassword.required' => 'لطفا رمز ورود را وارد نمایید',
    			'userpassword.min' => ' رمز کوتاه است',
    			'userpassword.max' => ' رمزعبور طولانی است ',
    			'userpassword.confirmed' => 'رمزعبور با تکرار آن مطابقت ندارد ',
    		]);   		 
$encryptedPassword = \Crypt::encrypt($request->userpassword);
$decryptedPassword = \Crypt::decrypt($encryptedPassword);
$rnd=rand(1, 99999999); 
DB::table('students')->insert([
    ['student_username' => $request->username , 'student_name' => $request->name , 'student_email' => $request->email , 'student_tell' => $request->tell , 'student_password' => $encryptedPassword ,   'student_createdatdate' =>  date('Y-m-d H:i:s') , 'student_active' => 0 , 'student_numberstudent' => $rnd]
]); 
$users = DB::table('students')->where('student_username', $request->username)->first();
$userscou = DB::table('students')->where('student_username', $request->username)->count();
$id_db= $users->id; 
$password_db= $users->student_password; 



$admins = DB::table('students')->where([
    ['student_username',  $request->username],
])->first();
if($admins){

$password_db= $admins->student_password; 
$decryptedPassword =  Crypt::decrypt($password_db);
$userscou = DB::table('students')->where([
    ['student_username',  $request->username],
])->count();
$id_db= $admins->id;
$activeadmin= $admins->student_active; 
$username_db= $admins->student_username; 
$password_db= $admins->student_password; 
$username_log = $request->username; 
if(($username_log == $username_db)&&( $decryptedPassword == $request->userpassword)){
	
	Session::set('idstudent', $id_db);
	Session::set('signstudent', $username_db);
	Session::set('activestudent', $activeadmin);

$adminslp = \DB::table('students')->where('id', '=', $id_db)  ->orderBy('id', 'desc')->first();
$logindatepas=$adminslp->student_loginatdate;	

$admimg=$adminslp->student_img;
if(empty($admimg)){$admimg='user2x.png';}	
	Session::set('logindatepasstudent', $logindatepas);
	Session::set('studentimg', $admimg);
	$updatee = \DB::table('students')->where('id', '=', Session::get('idstudent'))  ->update(['student_loginatdate' => date('Y-m-d H:i:s') ,    'student_ip' => $request->ip()  ]); 


 $rnd=rand(1, 99999);    		
$updatee = \DB::table('students')->where('id', '=', Session::get('idstudent'))  ->update(['student_emailverfy' => $rnd   ]);
$admins = \DB::table('students')->where('id', '=',  Session::get('idstudent'))  ->orderBy('id', 'desc')->first();  	
$user = \DB::table('students')->where('id', '=', Session::get('idstudent'))  ->orderBy('id', 'desc')->first();
 	 $usernamee = $user->student_username; 
 $titmes='کدفعالسازی ایمیل شما ایجاد شد';
 $mestt='کدفعال سازی';
 $mesnot =  $user->student_emailverfy ; 
   Mail::send('superadmin.mail', ['user' => $user , 'usernamee' => $usernamee, 'mesnot' => $mesnot, 'titmes' => $titmes , 'mestt' => $mestt], function ($m) use ($user) {
         $m->from('info@site.com', 'فعالسازی حساب');
            $m->to($user->student_email, $user->student_email)->subject('کد فعالسازی ایمیل');
        }); 


 $rnd=rand(1, 99999);    		
$updatee = \DB::table('students')->where('id', '=', Session::get('idstudent'))  ->update(['student_tellverfy' => $rnd   ]); 
$admins = \DB::table('students')->where('id', '=',  Session::get('idstudent'))  ->orderBy('id', 'desc')->first();
$panelsms = \DB::table('panelsms')->where('id', '=',  1)  ->orderBy('id', 'desc')->first();
include(app_path().'/../sms/api_send_sms.php');
$message='با عرض سلام '.$admins->student_name.' عزیز. کدفعالسازی شماره همراه شما : '.$rnd.'';
if (($result = Send_SMS($panelsms->sms_username, $panelsms->sms_password, $panelsms->sms_fromnumber, $admins->student_tell, $message , 0, false)) === '0')
{ 
		
			return redirect('student/panel'); 
} else if ($result !== '') {   
		
			return redirect('student/panel'); 
 }





	
	
	
	
			return redirect('student/panel'); 
		} else 
			 $nametr = Session::flash('statust', 'اطلاعات را به درستی وارد نمایید.');
				return redirect('student/sign-in'); 	
			
}
		else if(empty($admins)) {
			 $nametr = Session::flash('statust', 'اطلاعات را به درستی وارد نمایید.');
				return redirect('student/sign-in'); 
		}
 	 
   	  
}
	
	
	

		
	public function viewsmyquizlevel(){
	if (Session::has('signstudent')){ 
		if (Session::get('activestudent')==1){  
 
$admins =  \DB::table('exam')
->where([['exam.exam_arou', '=', 3], ]) ->orderBy('exam.id', 'desc')->get();

return view('student.viewsquizlevel', ['admins' => $admins ]);

}	else if (Session::get('activestudent')==0){    return redirect('student/activition'); }
else if (empty(Session::has('signstudent'))){   return redirect('student/sign-in'); } }
}		







	public function ediquizslevel($id){
	if (Session::has('signstudent')){ 
		if (Session::get('activestudent')==1){   


$countt =  \DB::table('students')
->join('examtest', 'students.id', '=', 'examtest.examtest_idstudent')
->join('exam', 'examtest.examtest_idexam', '=', 'exam.id')
->where([['students.id', '=', Session::get('idstudent')],['exam.exam_arou', '=', 3],['exam.id', '=', $id], ]) ->orderBy('exam.id', 'desc')->count();

 

	
 $examcount= \DB::table('exam') 
->join('examtest', 'exam.id', '=', 'examtest.examtest_idexam') 
->where([
    ['exam.id', '=', $id],
    ['exam.exam_arou', '=', 3],
    ['examtest.examtest_idstudent', '=', Session::get('idstudent') ], ])
    ->orderBy('examtest.id', 'desc')->count();
    
if($examcount=='0'){
DB::table('examtest')->insert([
    ['examtest_idstudent' => Session::get('idstudent') ,     'examtest_date' =>  date('Y-m-d H:i:s') , 'examtest_idexam' => $id   , 'examtest_flg' => 0      ]
]);	
}
	
 $examstests= \DB::table('exam') 
->join('examtest', 'exam.id', '=', 'examtest.examtest_idexam') 
->where([
    ['exam.id', '=', $id],
    ['exam.exam_arou', '=', 3],
    ['examtest.examtest_idstudent', '=', Session::get('idstudent') ], ])
    ->orderBy('examtest.id', 'desc')->get();
 
 $exams= \DB::table('exam') 
->where([
    ['exam.id', '=', $id],
    ['exam.exam_arou', '=', 3], ])
    ->orderBy('exam.id', 'desc')->get();
 
 $tests= \DB::table('exam') 
->join('test', 'exam.id', '=', 'test.test_exam') 
->where([
    ['exam.id', '=', $id],
    ['exam.exam_arou', '=', 3], ])
    ->orderBy('test.id')->get();
 
 $count= \DB::table('exam') 
->join('test', 'exam.id', '=', 'test.test_exam') 
->where([
    ['exam.id', '=', $id],
    ['exam.exam_arou', '=', 3], ])
    ->orderBy('test.id', 'desc')->count();


 $examstestscount= \DB::table('examtest') 
->join('answertest', 'examtest.id', '=', 'answertest.answ_examtest') 
->where([
    ['examtest.examtest_idexam', '=', $id],
    ['answertest.answ_qst', '<>', 0],
    ['examtest.examtest_idstudent', '=', Session::get('idstudent') ], ])
    ->orderBy('examtest.id', 'desc')->count();
 
	
 $examstestscounttrue= \DB::table('examtest') 
->join('answertest', 'examtest.id', '=', 'answertest.answ_examtest') 
->where([
    ['examtest.examtest_idexam', '=', $id],
    ['answertest.answ_testtrue', '=', 1],
    ['examtest.examtest_idstudent', '=', Session::get('idstudent') ], ])
    ->orderBy('examtest.id', 'desc')->count();
 
   $examstestscountfalse=$examstestscount-$examstestscounttrue; 
   $countdontrep=$count-$examstestscount;
   $poin=(100/$count)*$examstestscounttrue;
   
   if($examcount!='0'){
   	
$updatee = \DB::table('examtest')
->where([['examtest_idstudent', '=', Session::get('idstudent')],['examtest_idexam', '=', $id], ])  ->
 update([ 'examtest_poin' => $poin   ]); 
    
   	 }
   	 
  
 $answtests= \DB::table('test') 
->join('answertest', 'test.id', '=', 'answertest.answ_idtest') 
->where([
    ['test.test_exam', '=', $id], ])
    ->orderBy('test.id', 'desc')->get();
 
   	  
   
    
return view('student.editquizlevel', ['exams' => $exams , 'tests' => $tests   , 'count' => $count    , 'examstests' => $examstests , 'examstestscount' => $examstestscount  , 'examstestscounttrue' => $examstestscounttrue  , 'examstestscountfalse' => $examstestscountfalse  , 'countdontrep' => $countdontrep   , 'poin' => $poin   , 'answtests' => $answtests   ]); 	


}	else if (Session::get('activestudent')==0){    return redirect('student/activition'); }
else if (empty(Session::has('signstudent'))){   return redirect('student/sign-in'); } }
}






	public function ediquizslevelpost($id ,  Request $request ){
	if (Session::has('signstudent')){ 
		if (Session::get('activestudent')==1){   

 $tests= \DB::table('exam') 
->join('test', 'exam.id', '=', 'test.test_exam') 
->where([
    ['exam.id', '=', $id],
    ['exam.exam_arou', '=', 3], ])
    ->orderBy('test.id')->get();
    
$users = DB::table('examtest')->where([['examtest_idstudent', '=', Session::get('idstudent')],['examtest_idexam', '=', $id], ])  ->orderBy('id', 'desc')->first(); 
$idexamtest= $users->id; 

		  	$admins = \DB::table('answertest')->where([ ['answ_examtest', '=', $idexamtest], ])  ->delete(); 
		  	
$updatee = \DB::table('examtest')
->where([['examtest_idstudent', '=', Session::get('idstudent')],['examtest_idexam', '=', $id], ])  ->
 update(['examtest_flg' => 1 , 'examtest_date' => date('Y-m-d H:i:s')   ]); 
    
    foreach($tests as $test){

DB::table('answertest')->insert([
    ['answ_examtest' => $idexamtest , 'answ_idtest' =>  $test->id  ,'answ_qst' =>  0 , 'answ_key' =>  $test->test_key     ]
]);
 	
$myCheckboxes = $request->input('my_checkbo'.$test->id.'x');

if($myCheckboxes != NULL)  {
foreach($myCheckboxes as $quan) { 

if($quan==$test->test_key){ $answtesttrue=1; } else if($quan!=$test->test_key){ $answtesttrue=0; }

$updatee = \DB::table('answertest')
->where([['answ_idtest', '=', $test->id],['answ_examtest', '=', $idexamtest], ])  ->
 update(['answ_qst' => $quan , 'answ_testtrue' => $answtesttrue   ]); 
}  } 
}	
$nametr = Session::flash('statust', 'شما آزمون را با موفقیت به اتمام رساندید.');
$nametrt = Session::flash('sessurl', 'viewsquizlevel/editquizlevel/'.$id.'');
		  return view('student.success');

}	else if (Session::get('activestudent')==0){    return redirect('student/activition'); }
else if (empty(Session::has('signstudent'))){   return redirect('student/sign-in'); } } 
}









   
   
   
    
}
