<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\user;

class RegisterController extends Controller
{
	public function register(){
		return view('paneltest/register');
		
	}
	
	
		public function login(){
			return view('paneltest/login');
			}
	
	
	
	


	
	
	
		public function check(Request $request ){
		
	
	
		$email_log = $request->email; 
		$password_log = md5($request->password);
		
		
			
		$users = \DB::table('users')->where('firstname', 'qqqqqq')->get();
		
		$email_db= $users->email; 
$password_db= $users->password; 
	
		if($email_log == $email_db){
			return 'vaaaaaaaaaaay';
		}
		
		
		
    	
    	
    	  	
    	//$users = \ DB::table('users')->where('name', 'John')->get();
       // $users = \DB::select('select * from users where active = ?', [1]);


        return view('paneltest.home', ['users' => $users]);
	
		
	}
	
	
	
	
	
	
	public function insert(Request $request ){
		
		$user=new user;
		$user->firstname = $request->firstname;
		$user->password = md5($request->password);
		$user->save();
		
	}
	
	
    //
}
