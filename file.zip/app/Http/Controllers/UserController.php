<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

class UserController extends Controller
{
    //
      /**
     * Show a list of all of the application's users.
     *
     * @return Response
     * 
     */
     
     
     
    public function insert()
    {
    	
        $inserts = \DB::insert('insert into users (active, name ) values (?, ?)', [1, 'Dayle' ]);

        
        $users = \DB::select('select * from users where active = ?', [1]);

        return view('cards.index', ['users' => $users]);
    }
     
     
     
    public function update()
    {
    	
        $affected = \DB::update('update users set name = 10000000 where name = ?', ['John']);

        
        $users = \DB::select('select * from users where active = ?', [1]);

        return view('cards.index', ['users' => $users]);
    }
     
     
    public function index()
    {
        $users = \DB::select('select * from users where active = ?', [1]);

        return view('cards.index', ['users' => $users]);
    }
     
     
     
     
     
     
      
     
    public function login()
    {
return view('users.login');
    }
     
    
    
    
    
    
}
