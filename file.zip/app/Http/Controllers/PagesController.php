<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

class PagesController extends Controller
{
	
	
    public function home(){
		
	$people=['amir' , 'ali' , 'saeid'];
			return view('welcome' ,compact('people'));
	}
	
	
	
	
    public function testlay(){
		
	 
			return view('testlay');
	}
	
	

	
	
	
	
	
    public function about(){
		
	 
			return view('about');
	}
	
	
}
