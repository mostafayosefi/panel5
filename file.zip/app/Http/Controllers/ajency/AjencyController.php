<?php

namespace App\Http\Controllers\ajency;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use Auth;
use Session;
use DB;
use Crypt;
use Rule;
use Mail;
 


use Validator;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class AjencyController extends Controller
{ 
   
    	
public function ajencylogin(Request $request){
if (Session::has('idlang')){ Session::set('idlang', '3'); } else {
$demolang=\DB::table('superadminselanats') ->where([['id', '=',  1],])->orderBy('id', 'desc')->first();		
Session::set('idlang', $demolang->supelan_demolang); }	
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();
	
DB::table('statics')->insert([
    ['static_ip' => $request->ip() , 'static_previous' => url()->previous() ,  'static_url' => $request->url() ,    'static_name' => $lngmenu->lng_wlogag ,   'static_createdatdate' =>  date('Y-m-d H:i:s') ]
]);

 return view('ajency.sign-in', ['lngmenus' => $lngmenus , 'lngmenu' => $lngmenu ]); 
 }



	
    public function ajencyloginpost(Request $request)
    {
  $lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();  	


    	$this->validate($request,[
    			'firstname' => 'required',
    			'lastname' => 'required'
    		],[
    			'firstname.required' => $lngmenu->lng_wusername.' ! '.$lngmenu->lng_wnotelq,
    			'lastname.required' => $lngmenu->lng_wpassword.' ! '.$lngmenu->lng_wnotelq,
    			
    		]);

$admins = DB::table('ajency')->where([
    ['ajency_username',  $request->firstname],
])->first();
if($admins){

$password_db= $admins->ajency_password; 
$decryptedPassword =  Crypt::decrypt($password_db);
$userscou = DB::table('ajency')->where([
    ['ajency_username',  $request->firstname],
])->count();
$id_db= $admins->id;
$activeadmin= $admins->ajency_active; 
$username_db= $admins->ajency_username; 
$password_db= $admins->ajency_password; 
$username_log = $request->firstname; 
if(($username_log == $username_db)&&( $decryptedPassword == $request->lastname)){
	
	Session::set('idajency', $id_db);
	Session::set('signajency', $username_db);
	Session::set('activeajency', $activeadmin);
	 Session::set('urlaro', 'agency'); 

$adminslp = \DB::table('ajency')->where('id', '=', $id_db)  ->orderBy('id', 'desc')->first();
$logindatepas=$adminslp->ajency_loginatdate;	

$admimg=$adminslp->ajency_img;
if(empty($admimg)){$admimg='user2x.png';}	
	Session::set('logindatepasaj', $logindatepas);
	Session::set('ajimg', $admimg);
	$updatee = \DB::table('ajency')->where('id', '=', Session::get('idajency'))  ->update(['ajency_loginatdate' => date('Y-m-d H:i:s') ,    'ajency_ip' => $request->ip()  ]); 
			return redirect('agency/panel'); 
		} else 
			 $nametr = Session::flash('statust',  $lngmenu->lng_werrornot);
				return redirect('agency/sign-in'); 
		
			
}
		else if(empty($admins)) {
			 $nametr = Session::flash('statust',  $lngmenu->lng_werrornot);
				return redirect('agency/sign-in'); 
		}
		
		
		
    }

		
  
  
  
  
  
  		
			
public function panelajency(){
	if (Session::has('signajency')){ 
		if (Session::get('activeajency')==1){ 

 

$updatee = \DB::table('ajency')->where('id', '=', Session::get('idajency'))  ->update(['ajency_tellactive' => 1   ]);

	$admins = DB::table('ajency')->where([
    ['id',  Session::get('idajency') ],
])->first();
$activeadmin= $admins->ajency_active; 
$ctr= $admins->ajency_ctr; 
Session::set('activeajency', $activeadmin);
 

return view('ajency.panel'  ); 

}
else if (Session::get('activeajency')==0){    return redirect('agency/activition'); }
else if (empty(Session::has('signajency'))){   return redirect('agency/sign-in'); }
}
	}



	
	public function panelajencyid($id){
if (Session::has('signajency')){ 
$lngmenu=\DB::table('language') ->where([['id', '=',  $id],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->first();
	Session::set('idlang', $id); 
if (Session::has('idlang')==3) {  Session::set('curnem', 'RIAL');  } else if   (Session::has('idlang')==7) {  Session::set('curnem', 'TL');  }else   {  Session::set('curnem', 'USD');  }
	
	
	
return redirect('agency/panel');}	
else{ return redirect('agency/sign-in'); } }




	public function ajencysignout(){	
	Session::forget('idajency');	
	Session::forget('signajency');
	Session::forget('logindatepasaj');
	Session::forget('ajimg');
	Session::forget('activeajency');
	Session::forget('idimg');
	Session::forget('tickreadajency');
	Session::forget('ctr');

		return redirect('agency/sign-in');
		}
			 
  

		
		 
	public function editprofileajency(){
if (Session::has('signajency')){ 
 
$admins = \DB::table('ajency')->where('id', '=', Session::get('idajency'))  ->orderBy('id', 'desc')->get();
$user = \DB::table('ajency')->where('id', '=', Session::get('idajency'))  ->orderBy('id', 'desc')->first();
$admimg=$user->ajency_img;
if(empty($admimg)){$admimg='user2x.png';}	
	Session::set('ajimg', $admimg);
	Session::set('activeajency', $user->ajency_active);


 

return view('ajency.myprofile', ['admins' => $admins       ]); }	
else{ return redirect('agency/sign-in'); }
				}







	public function chargeagencyaj(){
	if (Session::has('signajency')){ 
		if (Session::get('activeajency')==1){ 

	
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first(); 
$slngmenu=\DB::table('languages') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();	
	 


$admins = \DB::table('ajency')->where('id', '=', Session::get('idajency'))  ->orderBy('id', 'desc')->get();






//mycharge 
$charges = \DB::table('ajency') 
->join('charge', 'ajency.id', '=', 'charge.charge_iduser') 
->join('finicals', 'charge.charge_finical', '=', 'finicals.id') 
->where([
    ['charge.charge_arou', '=', 3],
    ['charge.charge_iduser', '=', Session::get('idajency')],
    ['finicals.finical_payment', '=', 1],
    ['finicals.finical_inc', '=', 5],])
    ->orderBy('charge.charge_id', 'desc')->get();
$chargepaymy=0;
foreach($charges as $charge){ $chargepaymy=$charge->charge_pay+$chargepaymy; }




 //supcharge  
$charges = \DB::table('ajency') 
->join('charge', 'ajency.id', '=', 'charge.charge_iduser') 
->join('finicals', 'charge.charge_finical', '=', 'finicals.id') 
->where([
    ['charge.charge_arou', '=', 3],
    ['charge.charge_iduser', '=', Session::get('idajency')],
    ['finicals.finical_payment', '=', 1],
    ['finicals.finical_inc', '=', 6],])
    ->orderBy('charge.charge_id', 'desc')->get();
$chargepaysup=0;
foreach($charges as $charge){ $chargepaysup=$charge->charge_pay+$chargepaysup; }


 //odat  
$charges = \DB::table('ajency') 
->join('charge', 'ajency.id', '=', 'charge.charge_iduser') 
->join('finicals', 'charge.charge_finical', '=', 'finicals.id') 
->where([
    ['charge.charge_arou', '=', 3],
    ['charge.charge_iduser', '=', Session::get('idajency')],
    ['finicals.finical_payment', '=', 1],
    ['finicals.finical_inc', '=', 7],])
    ->orderBy('charge.charge_id', 'desc')->get();
$chargepayodat=0;
foreach($charges as $charge){ $chargepayodat=$charge->charge_pay+$chargepayodat; }



//pardakht 
$charges = \DB::table('ajency') 
->join('charge', 'ajency.id', '=', 'charge.charge_iduser') 
->join('finicals', 'charge.charge_finical', '=', 'finicals.id') 
->where([
    ['charge.charge_arou', '=', 3],
    ['charge.charge_iduser', '=', Session::get('idajency')],
    ['finicals.finical_payment', '=', 1],
    ['finicals.finical_inc', '=', 3],])
    ->orderBy('charge.charge_id', 'desc')->get();
$chargepaypar=0;
foreach($charges as $charge){ $chargepaypar=$charge->charge_pay+$chargepaypar; }


//jamkol
$chargepay= ($chargepaysup +  $chargepaymy + $chargepayodat  ) -  $chargepaypar  ; 

 

$chargeac=$chargepay;

$chargesas = \DB::table('ajency') 
->join('charge', 'ajency.id', '=', 'charge.charge_iduser') 
->join('finicals', 'charge.charge_finical', '=', 'finicals.id') 
->where([
    ['charge.charge_arou', '=', 3],
    ['charge.charge_iduser', '=', Session::get('idajency')],
    ['finicals.finical_payment', '=', 1], 
    ['finicals.finical_inc', '<>', 0],])
    ->orderBy('charge.charge_id', 'desc')->get();





return view('ajency.innccharge', ['admins' => $admins ,'chargeac' => $chargeac , 'charges' => $charges , 'id' => Session::get('idajency') ,   'lngmenus' => $lngmenus , 'lngmenu' => $lngmenu , 'slngmenu' => $slngmenu , 'chargesas' => $chargesas ]);
}	else if (Session::get('activeajency')==0){    return redirect('agency/activition'); }
else if (empty(Session::has('signajency'))){   return redirect('agency/sign-in'); } }
}	
	
 








	
		
	public function editprofileajencypost(  Request $request ){
if (Session::has('signajency')){ 

 
$this->validate($request,[
    			'nameajency' => 'required|min:3|max:35',
    			'nameajencymng' => 'required|min:3|max:35', 
    			'tell' => 'required|numeric',
    			'email' => 'required|email',
    			'adres' => 'required|min:3|max:555'
    		],[
    			'nameajency.required' => 'لطفا نام آژانس را وارد نمایید',
    			'nameajency.min' => 'نام آژانس کوتاه است',
    			'nameajency.max' => 'نام آژانس طولانی است',
    			'nameajencymng.required' => 'لطفا نام مدیر آژانس را وارد نمایید',
    			'nameajencymng.min' => 'نام مدیر آژانس کوتاه است',
    			'nameajencymng.max' =>  'نام مدیر آژانس طولانی است', 
    			'tell.required' => 'لطفا تلفن را وارد نمایید',
    			'tell.numeric' => 'لطفا فرمت تلفن را به درستی وارد نمایید',
    			'email.required' =>  'لطفا ایمیل را وارد نمایید',
    			'email.email' => 'لطفا فرمت ایمیل را به درستی وارد نمایید',
    			'adres.required' => 'لطفا آدرس را به درستی وارد نمایید',
    			'adres.min' => 'آدرس کوتاه است',
    			'adres.max' => 'آدرس طولانی است',
    			
    		]);
 

 


$user = \DB::table('ajency')->where('id', '=', Session::get('idajency'))  ->orderBy('id', 'desc')->first();

 		if ( $request->email ==  $user->ajency_email   ){  $activeemail =  $user->ajency_emailactive ; }
 else   if ( $request->email !=  $user->ajency_email   ){  $activeemail ='0';}

 
 
$updatee = \DB::table('ajency')->where('id', '=', Session::get('idajency'))  ->update(['ajency_name' => $request->nameajency ,'ajency_namemng' => $request->nameajencymng   ,  'ajency_tell' => $request->tell ,  'ajency_email' => $request->email ,  'ajency_adres' => $request->adres,  'ajency_emailactive' => $activeemail ,  'ajency_tellactive' => 1 ]); 

$user = \DB::table('ajency')->where('id', '=', Session::get('idajency'))  ->orderBy('id', 'desc')->first();
if ( ($user->ajency_emailactive == 1) &&  ($user->ajency_tellactive == 1)     ){  $active=1;}
if ( ($user->ajency_emailactive == 0) ||  ($user->ajency_tellactive == 0)     ){  $active=0;}
$updatee = \DB::table('ajency')->where('id', '=', Session::get('idajency'))  ->update(['ajency_active' => $active   ]);

Session::set('activeajency', $active);	

$admins = \DB::table('ajency')->where('id', '=', Session::get('idajency'))  ->orderBy('id', 'desc')->get();
$nametr = Session::flash('statust',  'پروفایل من باموفقیت ویرایش شد'); 
$nametrt = Session::flash('sessurl', 'myprofile/edit');
return view('ajency.success' );
}	else{ return redirect('agency/sign-in'); }
}
		
	  


public function dropzoneStoreajencyfile(Request $request)
    {
   $image = $request->file('file');
        $imageName = time().$image->getClientOriginalName();
        $image->move(public_path('images'),$imageName);        
$updatee = \DB::table('ajency')->where('id', '=', Session::get('idajency'))  ->update(['ajency_img' => $imageName   ]); 
        return response()->json(['success'=>$imageName]);
    }
		   
 

public function storeajencydoca(Request $request)
    {
   $image = $request->file('file');
        $imageName = time().$image->getClientOriginalName();
        $image->move(public_path('images'),$imageName);        
$updatee = \DB::table('ajency')->where('id', '=', Session::get('idajency'))  ->update(['ajency_doc' => $imageName , 'ajency_docactive' => '2'   ]); 
        return response()->json(['success'=>$imageName]);
    }
		   
 
 
		
		
	public function securityajencyprofile( Request $request ){
if (Session::has('signajency')){ 


     	$this->validate($request,[
    			'userpassword' => 'required|min:5|max:35|confirmed',
    			'tell' => 'required',
    			'email' => 'required',
    		],[
    			'userpassword.required' => 'لطفا رمز ورود را وارد نمایید',
    			'userpassword.min' => ' رمز کوتاه است',
    			'userpassword.max' => ' رمزعبور طولانی است ',
    			'userpassword.confirmed' => 'رمزعبور با تکرار آن مطابقت ندارد ',
    			'tell.required' => 'دقت نمایید تا زمانی که شماره تلفن شما ثبت نشده باشد شما نمی توانید رمز خود را تغییر دهید',
    			'email.required' => 'دقت نمایید تا زمانی که ایمیل شما ثبت نشده باشد شما نمی توانید رمز خود را تغییر دهید',
    		]);
    		

    
	
$encryptedPassword =  Crypt::encrypt($request->userpassword);
$decryptedPassword =  Crypt::decrypt($encryptedPassword);

$updatee = \DB::table('ajency')->where('id', '=', Session::get('idajency'))  ->update(['ajency_password' => $encryptedPassword   ]); 
$admins = \DB::table('ajency')->where('id', '=',  Session::get('idajency'))  ->orderBy('id', 'desc')->first();
$nametr = Session::flash('statust', 'رمزعبور باموفقیت ویرایش شد');
$nametrt = Session::flash('sessurl', 'myprofile/edit');	


	  	
$user = \DB::table('ajency')->where('id', '=', Session::get('idajency'))  ->orderBy('id', 'desc')->first();
 
 
  

return view('ajency.success' );
}	
else{ return redirect('agency/sign-in'); }
				}
		

	public function webservicmyeagency(){
	if (Session::has('signajency')){ 
		if (Session::get('activeajency')==1){ 
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();
$slngmenu=\DB::table('languages') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();	


$adminss = \DB::table('mngindex') ->where('id', '=', '1')->orderBy('id', 'desc')->get();	
$admins = \DB::table('ajency')->where('id', '=', Session::get('idajency'))  ->orderBy('id', 'desc')->get();

return view('ajency.webserviceagency', [ 'admins' => $admins ,  'adminss' => $adminss ,  'lngmenus' => $lngmenus , 'lngmenu' => $lngmenu , 'slngmenu' => $slngmenu  ]);
  

} else if (Session::get('activeprofessor')==0){    return redirect('professor/activition'); }
else if (empty(Session::has('signprofessor'))){   return redirect('professor/sign-in'); } }
}
	





	public function webservicmyeagencypost(){
	if (Session::has('signajency')){ 
		if (Session::get('activeajency')==1){ 
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();
$slngmenu=\DB::table('languages') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();	

 	
$characters_on_image = 24;  
$possible_letters = '1234567890abcdefghigklmnopqrstuvwxyz';
$code = '';
$i = 0;
while ($i < $characters_on_image) { 
$code .= substr($possible_letters, mt_rand(0, strlen($possible_letters)-1), 1);
$i++;
}
		
$updatee = \DB::table('ajency')->where('id', '=', Session::get('idajency') )  ->update(['ajency_api' => $code   ]);   
$nametr = Session::flash('statust',  $lngmenu->lng_wsuccess);
$nametrt = Session::flash('sessurl', 'myprofile/webservice');		  	
 return view('ajency.success', [ 'lngmenus' => $lngmenus , 'lngmenu' => $lngmenu , 'slngmenu' => $slngmenu  ]); 

} else if (Session::get('activeprofessor')==0){    return redirect('professor/activition'); }
else if (empty(Session::has('signprofessor'))){   return redirect('professor/sign-in'); } }
}
	




 	
	
			
public function activitionajency(){
if (Session::has('signajency')){ 
 
 
$updatee = \DB::table('ajency')->where('id', '=', Session::get('idajency'))  ->update(['ajency_tellactive' => 1   ]);
 $user = \DB::table('ajency')->where('id', '=', Session::get('idajency'))  ->orderBy('id', 'desc')->first();
if ( ($user->ajency_emailactive == 1) &&  ($user->ajency_tellactive == 1)     ){  $active=1;}
if ( ($user->ajency_emailactive == 0) ||  ($user->ajency_tellactive == 0)     ){  $active=0;}
$updatee = \DB::table('ajency')->where('id', '=', Session::get('idajency'))  ->update(['ajency_active' => $active   ]);

Session::set('activeajency', $active);	
 
$admins = \DB::table('ajency') ->where('id', '=', Session::get('idajency'))   ->orderBy('id', 'desc')->get();




return view('ajency.activition', [ 'admins' => $admins   ]);
}	
else{ return redirect('agency/sign-in'); }
}

  
 
		
	public function emailajencyactivitionverfy( Request $request ){
if (Session::has('signajency')){ 
 
    	$this->validate($request,[
    			'email' => 'required',
    		],[
    			'email.required' =>  'لطفا ایمیل را وارد نمایید',
    		]);  		
 $rnd=rand(1, 99999);    		
$updatee = \DB::table('ajency')->where('id', '=', Session::get('idajency'))  ->update(['ajency_emailverfy' => $rnd   ]); 
$admins = \DB::table('ajency')->where('id', '=',  Session::get('idajency'))  ->orderBy('id', 'desc')->first();
			$nametr = Session::flash('statust', 'کد وریفای ایمیل باموفقیت به ایمیل من ارسال شد');
		  	$nametrt = Session::flash('sessurl', 'activition');		  	
$user = \DB::table('ajency')->where('id', '=', Session::get('idajency'))  ->orderBy('id', 'desc')->first();
 	 $usernamee = $user->ajency_username; 
 $titmes = 'ارسال کد فعالسازی به ایمیل من';
 $mestt = 'کد فعالسازی';
 $mesnot =  $user->ajency_emailverfy ; 
   Mail::send('superadmin.mail', ['user' => $user , 'usernamee' => $usernamee, 'mesnot' => $mesnot, 'titmes' => $titmes , 'mestt' => $mestt], function ($m) use ($user) {
         $m->from('info@info.com', 'کد فعالسازی ایمیل');
            $m->to($user->ajency_email, $user->ajency_email)->subject('کد فعالسازی ایمیل');
        }); 	
return view('ajency.success' );
}	
else{ return redirect('agency/sign-in'); }
}
		  
   
   
   

		
		
		
	public function emailajencyactivition( Request $request ){
if (Session::has('signajency')){ 
 
    	$this->validate($request,[
    			'codemail' => 'required',
    		],[
    			'codemail.required' => 'لطفا کدفعالسازی را وارد نمایید',
    		]);
$user = \DB::table('ajency')->where('id', '=', Session::get('idajency'))  ->orderBy('id', 'desc')->first();      
if ( $request->codemail ==  $user->ajency_emailverfy   ){  
$updatee = \DB::table('ajency')->where('id', '=', Session::get('idajency'))  ->update(['ajency_emailactive' => 1   ]);

$user = \DB::table('ajency')->where('id', '=', Session::get('idajency'))  ->orderBy('id', 'desc')->first();
if ( ($user->ajency_emailactive == 1) &&  ($user->ajency_tellactive == 1)  &&  ($user->ajency_docactive == 1)   ){  $active=1;

 

}
if ( ($user->ajency_emailactive == 0) ||  ($user->ajency_tellactive == 0) ||  ($user->ajency_docactive != '1')   ){  $active=0;}
$updatee = \DB::table('ajency')->where('id', '=', Session::get('idajency'))  ->update(['ajency_active' => $active   ]);
Session::set('activeajency', $active);	


$admins = \DB::table('ajency')->where('id', '=',  Session::get('idajency'))  ->orderBy('id', 'desc')->first();
$nametr = Session::flash('statust', 'ایمیل با موفقیت فعال شد  ' );
$nametrt = Session::flash('sessurl', 'activition');		  	
 
return view('ajency.success' );
}			 
 else   if ( $request->codemail !=  $user->ajency_emailverfy   ){  
$nametr = Session::flash('statust',   'متاسفانه کد وریفای منطبق نیست' );
$nametrt = Session::flash('sessurl', 'activition');	
return view('ajency.error' );
 }
else if (empty(Session::has('signajency'))){ return redirect('agency/sign-in'); }
}
}











		
	public function tellajencyactivitionverfy( Request $request ){
if (Session::has('signajency')){ 
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();
$slngmenu=\DB::table('languages') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();	
    	$this->validate($request,[
    			'tell' => 'required',
    		],[
    			'tell.required' => $lngmenu->lng_wtell.' ! '.$lngmenu->lng_wnotelq,
    		]);  		
 $rnd=rand(1, 99999);    		
$updatee = \DB::table('ajency')->where('id', '=', Session::get('idajency'))  ->update(['ajency_tellverfy' => $rnd   ]); 
$admins = \DB::table('ajency')->where('id', '=',  Session::get('idajency'))  ->orderBy('id', 'desc')->first();


$panelsms = \DB::table('panelsms')->where('id', '=',  1)  ->orderBy('id', 'desc')->first();

include(app_path().'/../sms/api_send_sms.php');
$message=$lngmenu->lng_whi.' '.$admins->ajency_name.' '.$lngmenu->lng_wcodeactive  .':'.$rnd.'';
if (($result = Send_SMS($panelsms->sms_username, $panelsms->sms_password, $panelsms->sms_fromnumber, $admins->ajency_tell, $message , 0, false)) === '0')
{ 
			 $nametr = Session::flash('statust', $slngmenu->lng_wsendverfytellsuc);
		  	$nametrt = Session::flash('sessurl', 'activition');	 
		  	return view('ajency.success', [   'lngmenus' => $lngmenus , 'lngmenu' => $lngmenu , 'slngmenu' => $slngmenu   ]);		  	
 
} else if ($result !== '') {   
			 $nametr = Session::flash('statust',$lngmenu->lng_werror);
		  	$nametrt = Session::flash('sessurl', 'activition');
		  	  
		  	 return view('ajency.error', [  'lngmenus' => $lngmenus , 'lngmenu' => $lngmenu  ]);
 }



        
		  	return view('ajency.success', [  'lngmenus' => $lngmenus , 'lngmenu' => $lngmenu  ]);	
}	
else{ return redirect('agency/sign-in'); }
}
		
		



	
		
	public function tellajencyactivition( Request $request ){
if (Session::has('signajency')){ 
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();
$slngmenu=\DB::table('languages') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();	

    	$this->validate($request,[
    			'codtell' => 'required',
    		],[
    			'codtell.required' => $lngmenu->lng_wtell.' ! '.$lngmenu->lng_wnotelq,
    		]);
$user = \DB::table('ajency')->where('id', '=', Session::get('idajency'))  ->orderBy('id', 'desc')->first();      
if ( $request->codtell ==  $user->ajency_tellverfy   ){  
$updatee = \DB::table('ajency')->where('id', '=', Session::get('idajency'))  ->update(['ajency_tellactive' => 1   ]);
$user = \DB::table('ajency')->where('id', '=', Session::get('idajency'))  ->orderBy('id', 'desc')->first();
if ( ($user->ajency_emailactive == 1) &&  ($user->ajency_tellactive == 1)   &&  ($user->ajency_docactive == 1)  ){  $active=1;



$superadminselanats =  DB::table('superadminselanats')  ->orderBy('id', 'desc')->first();
 if($superadminselanats->supelan_emailaccajency == '1'){
 $usernamee = $user->ajency_username; 
 $titmes=$lngmenu->lng_wactivedon;
 $mestt=$lngmenu->lng_wpassword;
 $mesnot = Crypt::decrypt($user->ajency_password); 
   Mail::send('superadmin.mail', ['user' => $user , 'usernamee' => $usernamee, 'mesnot' => $mesnot, 'titmes' => $titmes , 'mestt' => $mestt], function ($m) use ($user) {
        
$decryptedPassword =  Crypt::decrypt($user->ajency_password);

            $m->from('info@gds724.com', 'Account activation');

            $m->to($user->ajency_email, $user->ajency_email)->subject('Account activation');
        }); 	
 }	 	
 
 	
 if($superadminselanats->supelan_smsaccajency == '1'){	
   
$admins = \DB::table('ajency')->where('id', '=',  Session::get('idajency'))  ->orderBy('id', 'desc')->first();
$panelsms = \DB::table('panelsms')->where('id', '=',  1)  ->orderBy('id', 'desc')->first();
include(app_path().'/../sms/api_send_sms.php');
$message=$lngmenu->lng_whi.' '.$admins->ajency_name.' '.$lngmenu->lng_wactivedon  .' ';
$result = Send_SMS($panelsms->sms_username, $panelsms->sms_password, $panelsms->sms_fromnumber, $admins->ajency_tell, $message , 0, false) ; }


}
if ( ($user->ajency_emailactive == 0) ||  ($user->ajency_tellactive == 0) ||  ($user->ajency_docactive != '1')   ){  $active=0;}
$updatee = \DB::table('ajency')->where('id', '=', Session::get('idajency'))  ->update(['ajency_active' => $active   ]);
Session::set('activeajency', $active);	
$admins = \DB::table('ajency')->where('id', '=',  Session::get('idajency'))  ->orderBy('id', 'desc')->first();
$nametr = Session::flash('statust', $slngmenu->lng_wactivetellsuc );
$nametrt = Session::flash('sessurl', 'activition');		  	
$user = \DB::table('ajency')->where('id', '=', Session::get('idajency'))  ->orderBy('id', 'desc')->first();
$usernamee = $user->ajency_username; 
 $titmes=$slngmenu->lng_wactivetellsuc;
 $mestt=' ';
 $mesnot = ' ';
 
 
 
 /*
   Mail::send('superadmin.mail', ['user' => $user , 'usernamee' => $usernamee, 'mesnot' => $mesnot, 'titmes' => $titmes , 'mestt' => $mestt], function ($m) use ($user) {
$m->from('info@gds724.com', 'فعالسازی ایمیل');
$m->to($user->admin_email, $user->admin_email)->subject('ایمیل فعال شد');
}); 
*/



	
	return view('ajency.success', [  'lngmenus' => $lngmenus , 'lngmenu' => $lngmenu , 'slngmenu' => $slngmenu   ]);
}			 
 else   if ( $request->codtell !=  $user->ajency_tellverfy   ){  
$nametr = Session::flash('statust',   $lngmenu->lng_wcodeactiveerror );
$nametrt = Session::flash('sessurl', 'activition');	
	return view('ajency.error', [  'lngmenus' => $lngmenus , 'lngmenu' => $lngmenu  ]);
 }
else if (empty(Session::has('signajency'))){ return redirect('agency/sign-in'); }
}
}

		
		
	public function viewsclasesprf(){
	if (Session::has('signprofessor')){ 
		if (Session::get('activeprofessor')==1){ 
 $clases= \DB::table('lesson')
->join('clas', 'lesson.id', '=', 'clas.clas_lesson')
->join('term', 'clas.clas_term', '=', 'term.id')
->join('period', 'term.term_period', '=', 'period.id')
->where('clas.clas_term', '<>', 0)  ->

orderBy('clas.id', 'desc')->get();

 $admins= \DB::table('lesson')
->join('clas', 'lesson.id', '=', 'clas.clas_lesson')

->where([
    ['clas.clas_professor', '=', Session::get('idprofessor')],
    ['clas.clas_term', '<>', 0],
])
->orderBy('clas.id', 'desc')->get();

return view('professor.viewsclases', ['admins' => $admins , 'clases' => $clases ]);

}	else if (Session::get('activeprofessor')==0){    return redirect('professor/activition'); }
else if (empty(Session::has('signprofessor'))){   return redirect('professor/sign-in'); } }
}		






	public function editclasprofessorr($id){
	if (Session::has('signprofessor')){ 
		if (Session::get('activeprofessor')==1){  
	Session::put('idimg', $id);
	
 $professors= \DB::table('professors')->where('professor_active', '=', 1)  ->orderBy('id', 'desc')->get();
 $admins= \DB::table('lesson')
->join('clas', 'lesson.id', '=', 'clas.clas_lesson')
->where([
    ['clas.id', '=', $id],
    ['clas.clas_professor', '=', Session::get('idprofessor')],
    ['clas.clas_term', '<>', 0],])  ->orderBy('clas.id', 'desc')->get();
    
    
 $count= \DB::table('lesson')
->join('clas', 'lesson.id', '=', 'clas.clas_lesson')
->where([
    ['clas.id', '=', $id],
    ['clas.clas_professor', '=', Session::get('idprofessor')],
    ['clas.clas_term', '<>', 0],])  ->orderBy('clas.id', 'desc')->count();
    
if($count=='0'){
$nametr = Session::flash('statust', 'این کلاس متعلق به شما نیست شما دسترسی به اطلاعات آن را ندارید.');
		  	$nametrt = Session::flash('sessurl', 'viewsclases');
	 	return view('professor.error');

	
}	 	
else if ($count!='0'){ 



 $adminsp= \DB::table('clas')->where('id', '=', $id)  ->orderBy('id', 'desc')->first();

 $terms= \DB::table('term')->where('id', '=', $adminsp->clas_term)  ->orderBy('id', 'desc')->get();

 $sisions= \DB::table('clas')
->join('sision', 'clas.id', '=', 'sision.sision_clas')
->where([
    ['sision_clas', '=', $id],
    ['clas.clas_professor', '=', Session::get('idprofessor')],
    ['sision.sision_active', '=', 1],])
  ->orderBy('sision.id', 'desc')->get();

 $professorsselecs= \DB::table('professors')->where('id', '=', $adminsp->clas_professor)  ->orderBy('id', 'desc')->get();

$ways = \DB::table('period')
->join('term', 'period.id', '=', 'term.term_period')
->join('clas', 'term.id', '=', 'clas.clas_term')
->where('clas.id', '=', $id)  ->orderBy('term.id', 'desc')->get(); 


$liststudents = \DB::table('students')
->join('liststudentterm', 'students.id', '=', 'liststudentterm.liststud_idstudent')
->join('term', 'liststudentterm.liststud_term', '=', 'term.id')
->join('finicals', 'liststudentterm.liststud_finical', '=', 'finicals.id')
->where([['term.id', '=', $adminsp->clas_term],['finicals.finical_payment', '=', 1], ]) ->orderBy('finicals.id', 'desc')->get(); 



 $listexams= \DB::table('exam')
->join('listexam', 'exam.id', '=', 'listexam.listex_exam')
->where([
    ['exam.exam_arou', '=', 1],
    ['exam.exam_professor', '=', Session::get('idprofessor')],
    ['listexam.listex_clas', '=', $id],])
  ->orderBy('listexam.id', 'desc')->get();





 $exams= \DB::table('professors')
->join('exam', 'professors.id', '=', 'exam.exam_professor')
->where([
    ['exam.exam_arou', '=', 1],
    ['exam.exam_professor', '=', Session::get('idprofessor')],])
  ->orderBy('exam.id', 'desc')->get();




 $listquiz= \DB::table('exam')
->join('listexam', 'exam.id', '=', 'listexam.listex_exam')
->where([
    ['exam.exam_arou', '=', 2],
    ['exam.exam_professor', '=', Session::get('idprofessor')],
    ['listexam.listex_clas', '=', $id],])
  ->orderBy('listexam.id', 'desc')->get();





 $quiz= \DB::table('professors')
->join('exam', 'professors.id', '=', 'exam.exam_professor')
->where([
    ['exam.exam_arou', '=', 2],
    ['exam.exam_professor', '=', Session::get('idprofessor')],])
  ->orderBy('exam.id', 'desc')->get();


}



return view('professor.editclas', ['admins' => $admins , 'ways' => $ways   , 'professors' => $professors  , 'professorsselecs' => $professorsselecs  , 'terms' => $terms   , 'sisions' => $sisions   , 'liststudents' => $liststudents , 'listexams' => $listexams  , 'exams' => $exams  , 'listquiz' => $listquiz  , 'quiz' => $quiz   ]); 	
}	else if (Session::get('activeprofessor')==0){    return redirect('professor/activition'); }
else if (empty(Session::has('signprofessor'))){   return redirect('professor/sign-in'); } }
}




	public function addlistexam($id , Request $request ){
	if (Session::has('signprofessor')){ 
		if (Session::get('activeprofessor')==1){
    	$this->validate($request,[
    			'exam' => 'required',
    		],[
    			'exam.required' => 'انتخاب تمرین اجباری است',
    		]);


$count = \ DB::table('listexam')->where([['listex_exam', '=',  $request->exam ],['listex_clas', '=', $id], ])  ->orderBy('id', 'desc')->count();

if($count!='0'){ 
$nrepeatl = Session::flash('repeat', '1');
return redirect('professor/viewsclases/editclas/'.$id.''); }else if($count=='0'){
    		
DB::table('listexam')->insert([
    ['listex_exam' => $request->exam , 'listex_clas' => $id ,  'listex_createdatdate' =>  date('Y-m-d H:i:s')  ]
]);
			 $nametr = Session::flash('statust', 'تمرین شما با موفقیت برای دانشجویان ارائه شد.');
		  	$nametrt = Session::flash('sessurl', 'viewsclases/editclas/'.$id.''); 
		  	 return view('professor.success');  	}	
 
}	else if (Session::get('activeprofessor')==0){    return redirect('professor/activition'); }
else if (empty(Session::has('signprofessor'))){   return redirect('professor/sign-in'); } }    		
    		}

public function deletlistexam($id){
	if (Session::has('signprofessor')){ 
		if (Session::get('activeprofessor')==1){ 
		
		  	$admins = \DB::table('listexam')->where('id', '=', $id)->delete();
		  	
		  	$nametr = Session::flash('statust', 'تمرین ارائه شده با موفقیت حذف شد.');
		  	$nametrt = Session::flash('sessurl', 'viewsclases/editclas/'.Session::get('idimg').''); 
		  	
	return view('professor.success', ['admins' => $admins]);



}	else if (Session::get('activeprofessor')==0){    return redirect('professor/activition'); }
else if (empty(Session::has('signprofessor'))){   return redirect('professor/sign-in'); } }
				}
		




	public function addlistquiz($id , Request $request ){
	if (Session::has('signprofessor')){ 
		if (Session::get('activeprofessor')==1){
    	$this->validate($request,[
    			'exam' => 'required',
    		],[
    			'exam.required' => 'انتخاب آزمون اجباری است',
    		]);


$count = \ DB::table('listexam')->where([['listex_exam', '=',  $request->exam ],['listex_clas', '=', $id], ])  ->orderBy('id', 'desc')->count();

if($count!='0'){ 
$nrepeatl = Session::flash('repeata', '1');
return redirect('professor/viewsclases/editclas/'.$id.''); }else if($count=='0'){
    		
DB::table('listexam')->insert([
    ['listex_exam' => $request->exam , 'listex_clas' => $id ,  'listex_createdatdate' =>  date('Y-m-d H:i:s')  ]
]);
			 $nametr = Session::flash('statust', 'آزمون شما با موفقیت برای دانشجویان این کلاس ارائه شد.');
		  	$nametrt = Session::flash('sessurl', 'viewsclases/editclas/'.$id.''); 
		  	 return view('professor.success');  	}	
 
}	else if (Session::get('activeprofessor')==0){    return redirect('professor/activition'); }
else if (empty(Session::has('signprofessor'))){   return redirect('professor/sign-in'); } }    		
    		}





public function deletlistquiz($id){
	if (Session::has('signprofessor')){ 
		if (Session::get('activeprofessor')==1){ 
		
		  	$admins = \DB::table('listexam')->where('id', '=', $id)->delete();
		  	
		  	$nametr = Session::flash('statust', 'آزمون ارائه شده با موفقیت حذف شد.');
		  	$nametrt = Session::flash('sessurl', 'viewsclases/editclas/'.Session::get('idimg').''); 
		  	
	return view('professor.success', ['admins' => $admins]);



}	else if (Session::get('activeprofessor')==0){    return redirect('professor/activition'); }
else if (empty(Session::has('signprofessor'))){   return redirect('professor/sign-in'); } }
				}
		




	public function editsisionprofessor($id){
if (Session::has('signprofessor')){ 
		if (Session::get('activeprofessor')==1){ 
		
	Session::put('idimg', $id);
	

 $professors= \DB::table('professors')->where('professor_active', '=', 1)  ->orderBy('id', 'desc')->get();
 $admins= \DB::table('lesson')
->join('clas', 'lesson.id', '=', 'clas.clas_lesson')
->join('sision', 'clas.id', '=', 'sision.sision_clas')
->where('sision.id', '=', $id)  ->orderBy('sision.id', 'desc')->get();

 $adminsp= \DB::table('sision')->where('id', '=', $id)  ->orderBy('id', 'desc')->first(); 
 $terms= \DB::table('clas')->where('id', '=', $adminsp->sision_clas)  ->orderBy('id', 'desc')->get();
 $sisions= \DB::table('sision')->where('sision_clas', '=', $id)  ->orderBy('id', 'desc')->get();

$ways = \DB::table('period')
->join('term', 'period.id', '=', 'term.term_period')
->join('clas', 'term.id', '=', 'clas.clas_term')
->join('sision', 'clas.id', '=', 'sision.sision_clas')
->where('sision.id', '=', $id)  ->orderBy('term.id', 'desc')->get(); 

 $wsisions= \DB::table('sision')->where('id', '=', $id)  ->orderBy('id', 'desc')->first(); 
 $wasisions= \DB::table('sision')->where('id', '=', $id)  ->orderBy('id', 'desc')->get(); 
 
 $wclases= \DB::table('clas')->where('id', '=', $wsisions->sision_clas)   ->first();
 $waclases= \DB::table('clas')->where('id', '=', $wsisions->sision_clas)  ->orderBy('id', 'desc')->get();
 
 $wterms= \DB::table('term')->where('id', '=', $wclases->clas_term)  ->orderBy('id', 'desc')->first();
 $waterms= \DB::table('term')->where('id', '=', $wclases->clas_term)  ->orderBy('id', 'desc')->get();
 
 $wperiods= \DB::table('period')->where('id', '=', $wterms->term_period)  ->orderBy('id', 'desc')->first();
 $waperiods= \DB::table('period')->where('id', '=', $wterms->term_period)  ->orderBy('id', 'desc')->get();
 
 $professorsselecs= \DB::table('professors')->where('id', '=', $wclases->clas_professor)  ->orderBy('id', 'desc')->get();
 
  

$liststudents = \DB::table('liststudentterm')
->join('term', 'liststudentterm.liststud_term', '=', 'term.id')
->join('finicals', 'liststudentterm.liststud_finical', '=', 'finicals.id')
->where([['term.id', '=', $wclases->clas_term],['finicals.finical_payment', '=', 1], ]) ->orderBy('finicals.id', 'desc')->get(); 

 
foreach($liststudents as $liststudent) {
	

$countlist = \DB::table('liststudentsision')->where([['liststudentsision.listsis_idstudent', '=', $liststudent->finical_iduser ],['liststudentsision.listsis_sision', '=', $id], ]) ->orderBy('id', 'desc')->count(); 	
if($countlist!='0')	{ } else if($countlist=='0')	{
	
 DB::table('liststudentsision')->insert([
    ['listsis_idstudent' => $liststudent->finical_iduser ,     'listsis_period' => $wterms->term_period ,   'listsis_term' => $wclases->clas_term   ,   'listsis_clas' => $wsisions->sision_clas ,  'listsis_sision' => $id  ,   'listsis_createdatdate' =>  date('Y-m-d H:i:s') ,   'listsis_peresent' => 0  ,   'listsis_active' => 0     ]
]); 	
}

}
 
 

$liststudentts = \DB::table('liststudentsision')
->join('students', 'liststudentsision.listsis_idstudent', '=', 'students.id')
->where([['liststudentsision.listsis_sision', '=', $id],['students.id', '<>', 0], ])->orderBy('students.id', 'desc')->get();  
 
 

return view('professor.editsision', ['admins' => $admins , 'ways' => $ways   , 'professors' => $professors  , 'professorsselecs' => $professorsselecs  , 'terms' => $terms   , 'sisions' => $sisions   , 'wasisions' => $wasisions   , 'waclases' => $waclases   , 'waterms' => $waterms   , 'waperiods' => $waperiods  , 'liststudentts' => $liststudentts   ]); 
}	else if (Session::get('activeprofessor')==0){    return redirect('professor/activition'); }
else if (empty(Session::has('signprofessor'))){   return redirect('professor/sign-in'); } }
}


 	

public function editsisionprofessorPost($id , Request $request){
		if (Session::has('signprofessor')){
					if (Session::get('activeprofessor')==1){    	
  
  
  

$liststudentts = \DB::table('liststudentsision')
->join('students', 'liststudentsision.listsis_idstudent', '=', 'students.id')
->where([['liststudentsision.listsis_sision', '=', $id ],['students.id', '<>', 0], ]) ->orderBy('students.id', 'desc')->get();  

$myCheckboxes = $request->input('my_checkbox');

$updatee = \DB::table('liststudentsision')->where([['listsis_sision', '=', $id ],['listsis_idstudent', '<>', 0  ], ]) ->update(['listsis_peresent' =>0 , 'listsis_active' => 1   ]);	
if($myCheckboxes != NULL)  {
foreach($myCheckboxes as $quan) {         	  
$updatee = \DB::table('liststudentsision')->where([['listsis_sision', '=', $id ],['listsis_idstudent', '=', $quan  ], ]) ->update(['listsis_peresent' =>1 , 'listsis_active' => 1  ]);	

 }
 	  } 
 $nametr = Session::flash('statust', 'حضور غیاب دانشجویان با موفقیت ثبت شد.' );
 $nametrt = Session::flash('sessurl', 'viewssision/editsision/'.$id.'');
 return view('professor.success');
		  
} else if (Session::get('activeprofessor')==0){    return redirect('professor/activition'); }
else if (empty(Session::has('signprofessor'))){   return redirect('professor/sign-in'); } }
 }
 






				
	public function searchbelitaj(){
	if (Session::has('signajency')){ 
		if (Session::get('activeajency')==1){ 


$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first(); 
$slngmenu=\DB::table('languages') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();	
$citys= \DB::table('city') ->where([['id', '<>',  '0'],['cit_active', '=',  '1'],])->orderBy('cit_name')->get();
$currencys=\DB::table('currency') ->where([['id', '<>',  '0'],['cur_active', '=',  '1'],])->orderBy('cur_nem')->get();
$airports= \DB::table('airports') ->where([['code', '<>',  '0'],])->orderBy('obs' , 'desc')->get(); 
  return view('ajency.searchbelit' , [ 'lngmenus' => $lngmenus , 'lngmenu' => $lngmenu , 'slngmenu' => $slngmenu ,  'citys' => $citys , 'currencys' => $currencys , 'airports' => $airports     ]);
  }		else if (Session::get('activeajency')==0){    return redirect('agency/activition'); }
else if (empty(Session::has('signajency'))){   return redirect('agency/sign-in'); } }
}		





public function searchbelitpostaj(Request $request){
		if (Session::has('signajency')){
			
$slngmenu=\DB::table('languages') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();	  	    

$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();
 

 			 $this->validate($request,[
    			'departure' => 'required',
    			'arrival' => 'required',
    			'datepicker' => 'required',
    			'adult' => 'required',
    		],[
    			'departure.required' => $lngmenu->lng_worigin.' ! '.$lngmenu->lng_wnotelq,
    			'arrival.required' => $lngmenu->lng_wdesti.' ! '.$lngmenu->lng_wnotelq,
    			'datepicker.required' => $lngmenu->lng_wdatefly.' ! '.$lngmenu->lng_wnotelq,
    			'adult.required' => $lngmenu->lng_wdatefly.' ! '.$lngmenu->lng_wnotelq,
    		 ]);  

$stop=$request->stop;
$nonstop=$request->nonstop;


if($stop=='1' && $nonstop=='1'){$flgstop='1';} else 
if($stop=='0' && $nonstop=='0'){$flgstop='1';} else 
if($stop=='1' && $nonstop=='0'){$flgstop='2';} else 
if($stop=='0' && $nonstop=='1'){$flgstop='3';}  



$departures       = filter_var($request->departure, FILTER_SANITIZE_STRING);
$arrivals       = filter_var($request->arrival, FILTER_SANITIZE_STRING);


$departure       = filter_var($request->departure, FILTER_SANITIZE_STRING);
$arrival       = filter_var($request->arrival, FILTER_SANITIZE_STRING);
 
 
$allairprtdep=substr_count($departures, 'ALL AIRPRT IN');
$allairprtarr=substr_count($arrivals, 'ALL AIRPRT IN');  
 
 
$depm = explode("( ", $departure); $depm = explode(" )", $depm['1']); $departure=$depm['0'];  $departuref=$departure;
if($allairprtdep=='0'){
$departure=\DB::table('airports') ->where([['code', '=',  $departure],])->orderBy('code', 'desc')->first();
$departureo=\DB::table('airports') ->where([['code', '=',  $departuref],])->orderBy('code', 'desc')->first();
$departureob=$departureo->code; $departureobs=$departureo->obs;  $departureobs=$departureobs+1;
$depcountry=$departure->countryCode; $departure=$departure->code.$departure->countryCode;   
} 
if($allairprtdep!='0'){
$departure=\DB::table('airports') ->where([['code', '=',  $departure],])->orderBy('code', 'desc')->first();
$departureo=\DB::table('airports') ->where([['code', '=',  $departuref],])->orderBy('code', 'desc')->first();
$departureob=$departureo->code; $departureobs=$departureo->obs; $departureobs=$departureobs+1;
$depcountry=$departure->countryCode; $departure=$departure->code.'C'.$departure->countryCode;  
}

    
$updatee = \DB::table('airports')->where([['code', '=',  $departureob],])->update(['obs' => $departureobs   ]); 
  


$arrm = explode("( ", $arrival);  $arrm = explode(" )", $arrm['1']); $arrival=$arrm['0'];   $arrivalf=$arrival; 
if($allairprtarr=='0'){
$arrival=\DB::table('airports') ->where([['code', '=',  $arrival],])->orderBy('code', 'desc')->first();
$arrivalo=\DB::table('airports') ->where([['code', '=',  $arrivalf],])->orderBy('code', 'desc')->first();
$arrivalob=$arrivalo->code; $arrivalobs=$arrivalo->obs;  $arrivalobs=$arrivalobs+1;
$arrcountry=$arrival->countryCode;	 $arrival=$arrival->code.$arrival->countryCode; 
}
if($allairprtarr!='0'){
$arrival=\DB::table('airports') ->where([['code', '=',  $arrival],])->orderBy('code', 'desc')->first();
$arrivalo=\DB::table('airports') ->where([['code', '=',  $arrivalf],])->orderBy('code', 'desc')->first();
$arrivalob=$arrivalo->code; $arrivalobs=$arrivalo->obs;  $arrivalobs=$arrivalobs+1;
$arrcountry=$arrival->countryCode;	 $arrival=$arrival->code.'C'.$arrival->countryCode; 
}



$updatee = \DB::table('airports')->where([['code', '=',  $arrivalob],])->update(['obs' => $arrivalobs   ]); 



 	if($arrcountry==$depcountry){
		return redirect('/');
	}
 
 
    $departuredate       = filter_var($request->datepicker, FILTER_SANITIZE_STRING);
    $departuredater       = filter_var($request->datepickerr, FILTER_SANITIZE_STRING);
    $passengers       = filter_var($request->passengers, FILTER_SANITIZE_STRING);
    $adult = $request->input('adult'); 
    $child       = $request->input('child'); 
    $flightType       = $request->input('flightType'); 
    $infant       = filter_var($request->infant, FILTER_SANITIZE_STRING);

if($departuredater==''){
	$flightType='0';
} else {
	$flightType='1';
}




$sumpasg=$adult+$child+$infant;
if($sumpasg>7){
	return redirect('/');
} else if($sumpasg<=7){
	if($adult<$infant){
		return redirect('/');
	}
}


if($arrival==$departure){ return redirect('indexgds'); }

 
 
 
 if($flightType=='0'){ 
$datenew = explode(" ", $departuredate);   $monthh=$datenew['1']; $dayn=$datenew['2'];  $yearn=$datenew['3'];   
if($monthh=='Jan'){ $monthn='01';} else if($monthh=='Feb'){ $monthn='02';}  else if($monthh=='Mar'){ $monthn='03';}   else if($monthh=='Apr'){ $monthn='04';} else if($monthh=='May'){ $monthn='05';}  else if($monthh=='Jun'){ $monthn='06';}   else if($monthh=='Jul'){ $monthn='07';} else if($monthh=='Aug'){ $monthn='08';}  else if($monthh=='Sep'){ $monthn='09';}   else if($monthh=='Oct'){ $monthn='10';} else if($monthh=='Nov'){ $monthn='11';}  else if($monthh=='Dec'){ $monthn='12';} 
$year = $dayn.'.'.$monthn.'.'.$yearn.''; 
 
        $request = '{
            departure: "'.$departure.'",
            arrival: "'.$arrival.'",
            departuredate: "'.$year.'",
            adult: "'.$adult.'" ,
            child: "'.$child.'",
            infant: "'.$infant.'",
            onlydirect: false
        }';   
  }
 
 if($flightType=='1'){ 
    $departuredater       = filter_var($request->datepickerr, FILTER_SANITIZE_STRING);
     $departuredate = (string)$departuredate;
    $departuredater = (string)$departuredater;


    			 $this->validate($request,[
    			'departure' => 'required',
    			'arrival' => 'required',
    			'datepickerr' => 'required',
    			'adult' => 'required',
    		],[
    			'departure.required' => $lngmenu->lng_worigin.' ! '.$lngmenu->lng_wnotelq,
    			'arrival.required' => $lngmenu->lng_wdesti.' ! '.$lngmenu->lng_wnotelq,
    			'datepickerr.required' => $lngmenu->lng_wdatefly.' ! '.$lngmenu->lng_wnotelq,
    			'adult.required' => $lngmenu->lng_wdatefly.' ! '.$lngmenu->lng_wnotelq,
    		 ]);  

 
    
$datenew = explode(" ", $departuredate);   $monthh=$datenew['1']; $dayn=$datenew['2'];  $yearn=$datenew['3'];   
if($monthh=='Jan'){ $monthn='01';} else if($monthh=='Feb'){ $monthn='02';}  else if($monthh=='Mar'){ $monthn='03';}   else if($monthh=='Apr'){ $monthn='04';} else if($monthh=='May'){ $monthn='05';}  else if($monthh=='Jun'){ $monthn='06';}   else if($monthh=='Jul'){ $monthn='07';} else if($monthh=='Aug'){ $monthn='08';}  else if($monthh=='Sep'){ $monthn='09';}   else if($monthh=='Oct'){ $monthn='10';} else if($monthh=='Nov'){ $monthn='11';}  else if($monthh=='Dec'){ $monthn='12';} 
$year = $dayn.'.'.$monthn.'.'.$yearn.''; 


$datenewr = explode(" ", $departuredater);   $monthr=$datenewr['1']; $dayr=$datenewr['2'];  $yearrn=$datenewr['3'];   
if($monthr=='Jan'){ $montrn='01';} else if($monthr=='Feb'){ $montrn='02';}  else if($monthr=='Mar'){ $montrn='03';}   else if($monthr=='Apr'){ $montrn='04';} else if($monthr=='May'){ $montrn='05';}  else if($monthr=='Jun'){ $montrn='06';}   else if($monthr=='Jul'){ $montrn='07';} else if($monthr=='Aug'){ $montrn='08';}  else if($monthr=='Sep'){ $montrn='09';}   else if($monthr=='Oct'){ $montrn='10';} else if($monthr=='Nov'){ $montrn='11';}  else if($monthr=='Dec'){ $montrn='12';} 
$yearr = $dayr.'.'.$montrn.'.'.$yearrn.''; 
 
        $request = '{
            departure: "'.$departure.'",
            arrival: "'.$arrival.'",
            departuredate: "'.$year.'",
            returndate: "'.$yearr.'",
            adult: "'.$adult.'" ,
            child: "'.$child.'",
            infant: "'.$infant.'",
            onlydirect: false
        }';
        
    
  }
  
 
      
 if (empty($_SESSION['ProviderSessionId'])) {
     // echo 'empty';
      }
        
    $headers = array(
        'username:atin_user',
        'password:X4fVgT3a',
        'Content-Type:application/json',
        'request:'.$request
    );
        if (! empty($_SESSION['ProviderSessionId'])) {
        $headers['SetSession'] = $_SESSION['ProviderSessionId'];
    }

    		
     //http://88.250.178.229:4545/
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://ucuzauc.com/api/availability/4e53defd-7620-4ac1-b7e1-61c43f34bb76");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $request);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 5);
    curl_setopt($ch, CURLOPT_TIMEOUT, 59);
    curl_setopt($ch, CURLOPT_HEADER, 1);
$result = curl_exec($ch);

 

$wordChunks = explode("}]}]},", $result);
for($i = 0; $i < count($wordChunks); $i++){ }
if ( ! empty($_SESSION['ProviderSessionId'])) {
      $_SESSION['ProviderSessionId'] =  $wordChunks.uu_SessionId;
      }
 


 $airports=  \DB::table('countries') ->where([['countries_id', '<>',  '0'],])->orderBy('countries_id')->get(); 

  	 

$ori = explode("OriginDestinationOptionList,", $result );
$wordChunks = explode('{"Currency":"', $result);
$AirlineCode = explode('"ValidatingAirlineCode":"', $result);
$FlightNumber = explode('"FlightNumber":"', $result);
$ResBookDesigCode = explode('"ResBookDesigCode":"', $result);
$time = explode('"DepartureDateTime":"', $result);
$rezerve = explode('"ResBookDesigQuantity":"', $result);
$Havayolu = explode('"MarketingAirlineName":"', $result);
$TOTALEFARE = explode('"TotalFare":', $result);
$DepartureAirport = explode('"DepartureAirport":"', $result); 
$ArrivalAirport = explode('"ArrivalAirport":"', $result); 
$FlightSegment = explode('FlightSegment', $result); 
$SequenceNumber = explode('SequenceNumber":"', $result); 
$sessionid = explode('","sessionid":"', $result);
$sessionidD = explode('","', $sessionid['1']);
$uu_sessionid = explode('"uu_SessionId":"' , $result);
$uu_sessionidD = explode('","sessionid":"' , $uu_sessionid['1']);


	Session::set('wbs_uuses', $uu_sessionidD['0']); 
	
    DB::table('wbs')->insert([
    ['result' => $result  , 'wbs_uuses' => $uu_sessionidD['0']  ,'wbs_sesid' => $sessionidD['0']  , 'wbs_arrival' => $arrival , 'wbs_departure' => $departure , 'wbs_adult' => $adult , 'wbs_child' => $child , 'wbs_infant' => $infant  , 'wbs_departuredate' => $departuredate  , 'wbs_departuredater' => $departuredater   , 'wbs_way' => $flightType          ]
]);   
 
$wbs=\DB::table('wbs') ->where([['wbs_uuses', '=', Session::get('wbs_uuses')] , ])->orderBy('id', 'desc')->first(); 
 $result=$wbs->result; $wbssearch=$wbs->id;
 
 
$wbs=\DB::table('wbs') ->where([['wbs_uuses', '=', Session::get('wbs_uuses')] , ])->orderBy('id', 'desc')->first(); 
$wbsid=$wbs->id;

   $sortcounts=\DB::table('sort') ->where([['sort_wbsid', '=', $wbsid] , ])->orderBy('id', 'desc')->count(); 



for($i = 1; $i < count($wordChunks); $i++){ 
$FlightNumberD = explode('","ResBookDesigCode"', $FlightNumber[$i]);
$ResBookDesigCodeD = explode('","ResBookDesigQuantity"', $ResBookDesigCode[$i]);
$timeD = explode('","ArrivalDateTime"', $time[$i]);
$AirlineCodeD = explode('","ForceETicket":"', $AirlineCode[$i]);
$rezerveD = explode('","DepartureAirport":"', $rezerve[$i]);
$HavayoluD = explode('","Equipment":"', $Havayolu[$i]);
$HavayoluDD = explode('","', $HavayoluD['0']);
$TOTALEFARED = explode(',"ServiceFare":', $TOTALEFARE[$i]);
$DepartureAirportD = explode('","ArrivalAirport":', $DepartureAirport[$i]);
$ArrivalAirportD = explode('","DepartureCityCountry":', $ArrivalAirport[$i]);
$FlightSegmentD = explode('},{"DepartureDateTime":"', $wordChunks[$i]);
$SequenceNumberD = explode('","OriginDestinationOptionList"', $SequenceNumber[$i]);
$flseg=substr_count($SequenceNumber[$i], 'FlightSegment'); 
$flRefNumber=substr_count($SequenceNumber[$i], 'RefNumber');  
$listseg  = explode('","OriginDestinationOptionList"', $wordChunks[$i]); 
$listsegD = explode('","OriginDestinationOptionList"', $listseg['1']);
$refnmD = explode('"RefNumber":"', $listseg['1']); 
$TotalFare = explode(',"TotalFare":', $wordChunks[$i]);
$TotalFareD = explode(',"ServiceFare":', $TotalFare['1']);
$listseg  = explode('","OriginDestinationOptionList"', $wordChunks[$i]); 
$listsegD = explode('","OriginDestinationOptionList"', $listseg['1']);

 if($flightType=='1'){ 
$CombinationIDNumbe=substr_count($SequenceNumber[$i], 'CombinationID'); 
$CombinationIDNumber=$CombinationIDNumbe-1; 
$CombinationList  = explode('OriginDestinationCombinationList', $wordChunks[$i]); 
$CombinationIDNumbeji=substr_count($CombinationList['1'], 'CombinationID'); 
$CombinationListD  = explode('"IndexList":"', $CombinationList['1']); 
for($c = 1; $c <  $CombinationIDNumber+2   ; $c++){   
$IndexList  = explode('","CombinationID":"', $CombinationListD[$c]); 
$comiid  = explode('","', $IndexList['1']); 
$IndexListwentD  = explode(';', $IndexList['0']);  
$IndexListwentD['0']; 
 DB::table('comid')->insert([['seq' => $i-1 , 'went' => $IndexListwentD['0'] , 'back' => $IndexListwentD['1'] ,    'wbssearch' => $wbssearch ,  'com' => $comiid['0']  ]]);  
}  
}


 for($j = 1; $j < $flseg+1; $j++){ 
$feldsq  = explode('FlightSegment":[{', $listsegD['0']); 
$refnmsD = explode('FlightSegment', $refnmD[$j]); 
$refnmsND = explode('","DirectionId":"', $refnmsD['0']); 
$ElapsedTime = explode('","ElapsedTime":"', $refnmsD['0']); 
$ElapsedTimeD = explode('","', $ElapsedTime['1']);   
$directsD = explode('","', $ElapsedTime['0']);   
$directsidD = explode('DirectionId":"', $directsD['1']);    
$rfse=substr_count($refnmsD['1'], 'DepartureAirport');   

$airlinemark  = explode('"OperatingAirlineName":"', $listsegD['0']);
$airlinemarkD  = explode('","', $airlinemark['1']);
$marketlog  = explode('"MarketingAirline":"', $listsegD['0']);
$marketlogD  = explode('","', $marketlog['1']);

$feldsqDk = explode(',"DepartureAirport":"', $feldsq[$j]);
$feldsqDkD = explode('(', $feldsqDk['1']);
$feldsqDkDD = explode(')', $feldsqDkD['1']);
$deptime = explode('"DepartureDateTime":"', $feldsq[$j]);
$deptimeD = explode('","ArrivalDateTime":"', $deptime['1']);
$originalDate = $deptimeD['0'];
$newDatedep = date("d F", strtotime($originalDate)); $newDatedept = date("H:i", strtotime($originalDate));  

 $string=$ElapsedTimeD['0']; $min = '';$h = '';
for ($index=0;$index<strlen($string);$index++) { if($index<2){ $h .= $string[$index]; } else { $min .= $string[$index]; }} 


$feldsqDkar = explode('","ArrivalAirport":"', $feldsq[$j]);
$feldsqDkarD = explode('(', $feldsqDkar[$rfse]);	
$feldsqDkarDD = explode(')', $feldsqDkarD['1']);	
$artime = explode('","ArrivalDateTime":"', $feldsq[$j]);
$artimeD = explode('","FlightNumber":"', $artime[$rfse]);	
$originalDatea = $artimeD['0'];
$newDatearr = date("d F", strtotime($originalDatea)); $newDatearrt = date("H:i", strtotime($originalDatea));

$luggage = explode('"Luggage":"', $feldsq[$j]);
$luggageD = explode('","', $luggage['1']);

   

$clasnk = explode('","ResBookDesigCode":"', $feldsq[$j]);
$clasnkD = explode('","ResBookDesigQuantity":"', $clasnk['1']);






   
 if($sortcounts=='0'){ 
 
$dirf=$rfse+1;
 if($flgstop=='1'){ $show='1'; } else 
      if($flgstop=='2'){ if($dirf=='2') {$show='0';} else if($dirf!='2') {$show='1';}  }
else  if($flgstop=='3'){ if($dirf=='2') {$show='1';} else if($dirf!='2') {$show='0';}   }   



 	
$sairlinest  = explode(" ", $airlinemarkD['0']); 	
$sairlinestD  = $sairlinest['0']; 
  DB::table('sort')->insert([['sort_seq' => $i-1 , 'sort_comb' => $j-1 ,'sort_price' => $TotalFareD['0'] , 'sort_wbsid' => $wbsid  , 'sort_duritfly' => $h.$min   , 'sort_deptime' => $originalDate , 'sort_artime' => $originalDatea ,  'sort_airline' => $airlinemarkD['0'] ,  'sort_indirect' => $rfse+1  ,  'sort_class' => $clasnkD['0'] ,  'sort_show' => $show ]]);  	
  
  
   $sortvcounts=\DB::table('sortv') ->where([['sortv_wbsid', '=', $wbsid] ,['sortv_price', '=', $TotalFareD['0']] , ])->orderBy('id')->count(); 
  
  
 if($sortvcounts=='0'){
 
   $sairlinest  = explode(" ", $airlinemarkD['0']); 	
  $sairlinestD  = $sairlinest['0']; 		
 	

$sortvaircounts=\DB::table('sortv') ->where([['sortv_wbsid', '=', $wbsid] ,['sortv_airline', '=', $airlinemarkD['0']],  ])->orderBy('id')->count(); 	
 if($sortvaircounts=='0'){ $flgairline=1; } else  if($sortvaircounts!='0'){ $flgairline=0; }
 	

$sortvclascounts=\DB::table('sortv') ->where([['sortv_wbsid', '=', $wbsid] ,['sortv_class', '=',$clasnkD['0'] ],  ])->orderBy('id')->count(); 	
 if($sortvclascounts=='0'){ $flgaclas=1; } else  if($sortvclascounts!='0') { $flgaclas=0; }

$sortvindirectcounts=\DB::table('sortv') ->where([['sortv_wbsid', '=', $wbsid] ,['sortv_indirect', '=',$rfse+1 ],  ])->orderBy('id')->count(); 	
 if($sortvindirectcounts=='0'){ $indirect=1; } else  if($sortvindirectcounts!='0') { $indirect=0; }
 	
 	
  DB::table('sortv')->insert([[  'sortv_price' => $TotalFareD['0'] , 'sortv_wbsid' => $wbsid  ,   'sortv_airline' => $airlinemarkD['0'] ,  'sortv_class' => $clasnkD['0']  ,  'sortv_indirect' => $rfse+1 ,  'sortv_airlineflg' => $flgairline ,  'sortv_clasflg' => $flgaclas ,  'sortv_indirectflg' => $indirect ,  'sortv_priceflg' => '1' ]]);  
  }	
  
  
  
  
 }  





    




//k
 for($k = 1; $k <  $rfse+1   ; $k++){ 
$airlinemark  = explode('"OperatingAirlineName":"', $feldsq[$j]);
$airlinemarkD  = explode('","', $airlinemark[$k]);
$marketlog  = explode('"MarketingAirline":"', $feldsq[$j]);
$marketlogD  = explode('","', $marketlog[$k]); 
$flnk = explode('","FlightNumber":"', $feldsq[$j]);
$flnkD = explode('","ResBookDesigCode":"', $flnk[$k]);
$gole = explode('","OperatingAirline":"', $feldsq[$j]);
$goleD = explode('","MarketingAirline":"', $gole[$k]); 
$clasnk = explode('","ResBookDesigCode":"', $feldsq[$j]);
$clasnkD = explode('","ResBookDesigQuantity":"', $clasnk[$k]);

$citydep = explode(',"DepartureCityCountry":"', $feldsq[$j]);
$citydepD = explode(',', $citydep[$k]);	
$cityarriv = explode(',"ArrivaliCityCountry":"', $feldsq[$j]);
$cityarrivD = explode(',', $cityarriv[$k]);	
$feldsqDk = explode(',"DepartureAirport":"', $feldsq[$j]);
$feldsqDkD = explode('(', $feldsqDk[$k]); 
$feldsqDkar = explode('","ArrivalAirport":"', $feldsq[$j]);
$feldsqDkarD = explode('(', $feldsqDkar[$k]);	
$deptime = explode('"DepartureDateTime":"', $feldsq[$j]);
$deptimeD = explode('","ArrivalDateTime":"', $deptime[$k]);
$artime = explode('","ArrivalDateTime":"', $feldsq[$j]);
$artimeD = explode('","FlightNumber":"', $artime[$k]);	
$originalDate = $deptimeD['0'];
$newDatedep = date("d F", strtotime($originalDate)); $newDatedept = date("H:i", strtotime($originalDate));
$originalDatea = $artimeD['0'];
$newDatearr = date("d F", strtotime($originalDatea)); $newDatearrt = date("H:i", strtotime($originalDatea)); 

$luggage = explode('"Luggage":"', $feldsq[$j]);
$luggageD = explode('","', $luggage[$k]); 

//DB::table('wbss')->insert([['wbssearch' => $wbssearch]]);   

 } } }

 $comids=  \DB::table('comid') ->where([['wbssearch', '=',  $wbssearch],])->orderBy('id')->get(); 

 
 
 
$currency=\DB::table('currency') ->where([['cur_nem', '=',  Session::get('curnem')],])->orderBy('id', 'desc')->first();   	

 
 
 

 
  if($flightType=='0'){
  	
  
  return redirect('sortvt');
}
  
 
  if($flightType=='1'){ 
  
  return redirect('sortvt');
  
  
  
  
  /*
  return view('superadmin.ucackreturn', ['result' => $result , 'lngmenus' => $lngmenus , 'lngmenu' => $lngmenu , 'arrival' => $arrival , 'departure' => $departure , 'departuredate' => $departuredate,'departuredater' => $departuredater , 'year' => $year ,'yearr' => $yearr, 'airports' => $airports , 'adult' => $adult , 'child' => $child, 'infant' => $infant , 'wbs' => $wbs  , 'comids' => $comids   , 'currency' => $currency  ]);
 */
    }
 
 
 
 
     	 }	
else{ return redirect('agency/sign-in'); } 	  
}
	








	public function prevnextaj(Request $request){
		if (Session::has('signajency')){
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first(); 


$flag = $request->input('flag');



$wbs=\DB::table('wbs') ->where([['wbs_uuses', '=', Session::get('wbs_uuses')],])->orderBy('id', 'desc')->first(); 
  
$arrival=$wbs->wbs_arrival;
$departure=$wbs->wbs_departure;
$adult=$wbs->wbs_adult;
$child=$wbs->wbs_child;
$infant=$wbs->wbs_infant;
$departuredate=$wbs->wbs_departuredate;

$airports= \DB::table('countries') ->where([['countries_id', '<>',  '0'],])->orderBy('countries_id')->get();
  
 
 
 if($flag=='prev'){ 
$perv_day_date = date('Y-m-d', strtotime('-1 day', strtotime($departuredate))) ;
$datee = explode("-", $perv_day_date); $year = $datee[2].'.'.$datee[1].'.'.$datee[0].''; 
$dateprevnext= $datee[1].'/'.$datee[2].'/'.$datee[0].''; 

  }
  
 
 if($flag=='next'){ 
$perv_day_date = date('Y-m-d', strtotime('+1 day', strtotime($departuredate))) ;
$datee = explode("-", $perv_day_date); $year = $datee[2].'.'.$datee[1].'.'.$datee[0].''; 
$dateprevnext= $datee[1].'/'.$datee[2].'/'.$datee[0].''; 

  }
  

  
 
 
 
     $request = '{
            departure: "'.$departure.'",
            arrival: "'.$arrival.'",
            departuredate: "'.$year.'",
            adult: "'.$adult.'" ,
            child: "'.$child.'",
            infant: "'.$infant.'",
            onlydirect: false
        }';  


 if (empty($_SESSION['ProviderSessionId'])) {
     // echo 'empty';
      }
        
    $headers = array(
        'username:atin_user',
        'password:X4fVgT3a',
        'Content-Type:application/json',
        'request:'.$request
    );
        if (! empty($_SESSION['ProviderSessionId'])) {
        $headers['SetSession'] = $_SESSION['ProviderSessionId'];
    }


		
  
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://ucuzauc.com/api/availability/4e53defd-7620-4ac1-b7e1-61c43f34bb76");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $request);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 5);
    curl_setopt($ch, CURLOPT_TIMEOUT, 59);
    curl_setopt($ch, CURLOPT_HEADER, 1);
$result = curl_exec($ch);



$wordChunks = explode("}]}]},", $result);
for($i = 0; $i < count($wordChunks); $i++){ }
if ( ! empty($_SESSION['ProviderSessionId'])) {
      $_SESSION['ProviderSessionId'] =  $wordChunks.uu_SessionId;
      }
 


$ori = explode("OriginDestinationOptionList,", $result );
$wordChunks = explode('{"Currency":"', $result);
$AirlineCode = explode('"ValidatingAirlineCode":"', $result);
$FlightNumber = explode('"FlightNumber":"', $result);
$ResBookDesigCode = explode('"ResBookDesigCode":"', $result);
$time = explode('"DepartureDateTime":"', $result);
$rezerve = explode('"ResBookDesigQuantity":"', $result);
$Havayolu = explode('"MarketingAirlineName":"', $result);
$TOTALEFARE = explode('"TotalFare":', $result);
$DepartureAirport = explode('"DepartureAirport":"', $result); 
$ArrivalAirport = explode('"ArrivalAirport":"', $result); 
$FlightSegment = explode('FlightSegment', $result); 
$SequenceNumber = explode('SequenceNumber":"', $result); 
$sessionid = explode('","sessionid":"', $result);
$sessionidD = explode('","', $sessionid['1']);
$uu_sessionid = explode('"uu_SessionId":"' , $result);
$uu_sessionidD = explode('","sessionid":"' , $uu_sessionid['1']);

		$admins = \DB::table('wbs')->where([['wbs_uuses', '=', Session::get('wbs_uuses')],])->delete(); 
		
	Session::set('wbs_uuses', $uu_sessionidD['0']); 

    DB::table('wbs')->insert([
    ['result' => $result  , 'wbs_uuses' => $uu_sessionidD['0']  ,'wbs_sesid' => $sessionidD['0']  , 'wbs_arrival' => $arrival , 'wbs_departure' => $departure , 'wbs_adult' => $adult , 'wbs_child' => $child , 'wbs_infant' => $infant  , 'wbs_departuredate' => $dateprevnext           ]
]); 
 
 

 
 
 
 
$wbs=\DB::table('wbs') ->where([['wbs_uuses', '=', Session::get('wbs_uuses')],])->orderBy('id', 'desc')->first(); 

$currency=\DB::table('currency') ->where([['cur_nem', '=',  'USD'],])->orderBy('id', 'desc')->first(); 

  return view('superadmin.ucack', ['result' => $result , 'lngmenus' => $lngmenus , 'lngmenu' => $lngmenu , 'arrival' => $wbs->wbs_arrival , 'departure' => $wbs->wbs_departure , 'departuredate' => $wbs->wbs_departuredate , 'year' => $year ,  'airports' => $airports , 'adult' => $wbs->wbs_adult , 'child' => $wbs->wbs_child, 'infant' => $wbs->wbs_infant , 'wbs' => $wbs , 'currency' => $currency    ]);
  

}
else{ return redirect('agency/sign-in'); }
}




	public function viewsearchwentaj(){
		if (Session::has('signajency')){
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first(); 
 
$wbs=\DB::table('wbs') ->where([['wbs_uuses', '=', Session::get('wbs_uuses')],])->orderBy('id', 'desc')->first(); 
$result=$wbs->result;  

$airports= \DB::table('countries') ->where([['countries_id', '<>',  '0'],])->orderBy('countries_id')->get();
 
 
$year = $wbs->wbs_departuredate; 


$currency=\DB::table('currency') ->where([['cur_nem', '=',  'USD'],])->orderBy('id', 'desc')->first();  
  
 
  return view('superadmin.ucack', ['result' => $result , 'lngmenus' => $lngmenus , 'lngmenu' => $lngmenu , 'arrival' => $wbs->wbs_arrival , 'departure' => $wbs->wbs_departure , 'departuredate' => $wbs->wbs_departuredate , 'year' => $year ,  'airports' => $airports , 'adult' => $wbs->wbs_adult , 'child' => $wbs->wbs_child, 'infant' => $wbs->wbs_infant , 'wbs' => $wbs , 'currency' => $currency    ]);
  

}
else{ return redirect('agency/sign-in'); }
}




public function buyticketyekaj(Request $request){
if (Session::has('signajency')){ 
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();   	    

$adult = $request->input('adult'); 
$child = $request->input('child'); 
$infant = $request->input('infant'); 
$departure = $request->input('departure'); 
$arrival = $request->input('arrival'); 
$sessionidD = $request->input('sessionidD'); 
$uu_sessionidD = $request->input('uu_sessionidD');
$hisd = $request->input('hisd');   
 
if($hisd !=NULL){
$total = explode('/', $hisd );
 $seqd=$total['0'];
 $price=$total['1']; 
 $CombinationIDD=$total['2'];
}  

 
    $sess      = filter_var($request->uu_sessionidD, FILTER_SANITIZE_STRING);
    $sessionid      = filter_var($request->sessionidD, FILTER_SANITIZE_STRING);
    $RecommendationID       = $seqd; 
    $genel_toplam       = $price; 
  

$adultbp = $request->input('adultbp'); 
$childbp = $request->input('childbp'); 
$infantbp = $request->input('infantbp'); 

$adultsp = $request->input('adultsp'); 
$childsp = $request->input('childsp'); 
$infantsp = $request->input('infantsp'); 

$adulttp = $request->input('adulttp'); 
$childtp = $request->input('childtp'); 
$infanttp = $request->input('infanttp'); 
    
$updatee = \DB::table('wbs')->where('wbs_uuses', '=', Session::get('wbs_uuses'))  ->update(['wbs_seq' => $seqd , 'wbs_comb' => $CombinationIDD , 'wbs_price' => $price  , 'wbs_hisd' => $hisd  , 'wbs_adtbprice' => $adultbp  , 'wbs_adtsprice' => $adultsp  , 'wbs_adttprice' => $adulttp  , 'wbs_chdbprice' => $childbp  , 'wbs_chdsprice' => $childsp  , 'wbs_chdtprice' => $childtp , 'wbs_infbprice' => $infantbp  , 'wbs_infsprice' => $infantsp  , 'wbs_inftprice' => $infanttp  ]); 		  

 
 
return redirect('agency/buytickets');

}else{ return redirect('agency/sign-in'); }
}



	public function buyticketsaj(){
if (Session::has('signajency')){
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first(); 
  
$wbs=\DB::table('wbs') ->where([['wbs_uuses', '=', Session::get('wbs_uuses')],])->orderBy('id', 'desc')->first(); 
$result=$wbs->result;

$airports= \DB::table('countries') ->where([['countries_id', '<>',  '0'],])->orderBy('countries_id')->get(); 

        $requestt = '{
            combination_id: "'.$wbs->wbs_comb.'",
            recommandationid: "'.$wbs->wbs_seq.'",
            passengertype: "ADT",
            sessionid: "'.$wbs->wbs_sesid.'",
            providercode: "AMA" 
        }';
        
    
        
    $headers = array(
        'username:atin_user',
        'password:X4fVgT3a',
        'Content-Type:application/json',
        'request:'.$requestt
    );
        //http://88.250.178.229:4545/
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://ucuzauc.com/api/getrules/4e53defd-7620-4ac1-b7e1-61c43f34bb76");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $requestt);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 5);
    curl_setopt($ch, CURLOPT_TIMEOUT, 59);
    curl_setopt($ch, CURLOPT_HEADER, 1);
$resultt = curl_exec($ch); 


$currency=\DB::table('currency') ->where([['cur_nem', '=',  'USD'],])->orderBy('id', 'desc')->first();

 
 return view('superadmin.buyticket',['lngmenus' => $lngmenus , 'lngmenu' => $lngmenu, 'hisd' => $wbs->wbs_hisd , 'result' => $result , 'airports' => $airports , 'adult' => $wbs->wbs_adult , 'child' => $wbs->wbs_child , 'infant' => $wbs->wbs_infant , 'departure' => $wbs->wbs_departure , 'arrival' => $wbs->wbs_arrival , 'sessionidDt' => $wbs->wbs_sesid , 'uu_sessionidDt' => $wbs->wbs_uuses  , 'CombinationID' => $wbs->wbs_comb  , 'RecommendationID' => $wbs->wbs_seq  , 'priced' => $wbs->wbs_price , 'ruuls' => $resultt   , 'wbs' => $wbs , 'currency' => $currency   ]); 

}else{ return redirect('agency/sign-in'); }
}




public function buyticketyektaj(Request $request){
if (Session::has('signajency')){ 
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first(); 

	 Session::set('urlaro', 'agency'); 
	   	    
$this->validate($request,[
    			'email' => 'required|email',
    			'tell' => 'required|min:3|max:33',
    		],[
    			'email.required' => $lngmenu->lng_wemail.' ! '.$lngmenu->lng_wnotelq,
    			'email.email' => $lngmenu->lng_wemail.' ! '.$lngmenu->lng_wnotelq,
    			'tell.required' => $lngmenu->lng_wtell.' ! '.$lngmenu->lng_wnotelq,
    			'tell.min' => $lngmenu->lng_wtell.' ! '.$lngmenu->lng_wnotelq,
    			'tell.max' => $lngmenu->lng_wemail.' ! '.$lngmenu->lng_wnotelq,
    			
    		]);
   

$email = $request->input('email'); 
$tell = $request->input('tell'); 
$adult = $request->input('adult'); 
$child = $request->input('child'); 
$infant = $request->input('infant'); 
$departure = $request->input('departure'); 
$arrival = $request->input('arrival'); 
$sessionidD = $request->input('sessionidD'); 
$uu_sessionidD = $request->input('uu_sessionidD');

$priced = $request->input('priced');
$CombinationID = $request->input('CombinationID');
$RecommendationID = $request->input('RecommendationID');




 $seqd=$RecommendationID;
 $price=$priced; 
 $CombinationIDD=$CombinationID; 



$genders = $request->input('gender'); 
$names = $request->input('name'); 
$familys = $request->input('family'); 
$days = $request->input('day'); 
$months = $request->input('month'); 
$years = $request->input('year'); 
$ages = $request->input('age');  
$nationals = $request->input('national'); 
$passportnumbers = $request->input('passportnumber');

 

$mngindex=\DB::table('mngindex') ->where([['id', '=', '1'],])->orderBy('id', 'desc')->first(); 
$currency=\DB::table('currency') ->where([['cur_nem', '=',  'USD'],])->orderBy('id', 'desc')->first(); 
$paybelc = $currency->cur_rateajency * $price;
$paybel= number_format($mngindex->ind_taxp + $paybelc , 2);

 DB::table('belits')->insert([
    ['bel_email'  =>  $email    , 'bel_tell'  => $tell   , 'bel_ses'  => Session::get('wbs_uuses')   ,'bel_basefare'  => $price ,'bel_pay'  => $paybel , 'bel_createdatdate'  => date('Y-m-d H:i:s')       ]
]); 

$belits=\DB::table('belits')->where([['bel_ses', '=', Session::get('wbs_uuses')],])->orderBy('bel_id', 'desc')->first();   
$belitid=$belits->bel_id;


$wbs=\DB::table('wbs') ->where([['wbs_uuses', '=', Session::get('wbs_uuses')],])->orderBy('id', 'desc')->first(); 


    for ($i = 0; $i< count($ages); $i++){
 
 $this->validate($request,[
    			'name.*' => 'required',
    			'family.*' => 'required',
    			'national.*' => 'required',
    			'year.*' => 'required',
    			'month.*' => 'required',
    			'day.*' => 'required',
    			'gender.*' => 'required',
    			'passportnumber.*' => 'required',
    		],[
    			'name.*.required' => $lngmenu->lng_wname.' ! '.$lngmenu->lng_wnotelq,
    			'family.*.required' => 'family'.' ! '.$lngmenu->lng_wnotelq,
    			'national.*.required' => 'national'.' ! '.$lngmenu->lng_wnotelq,
    			'year.*.required' => 'year'.' ! '.$lngmenu->lng_wnotelq,
    			'month.*.required' => 'month'.' ! '.$lngmenu->lng_wnotelq,
    			'day.*.required' => 'day'.' ! '.$lngmenu->lng_wnotelq,
    			'gender.*.required' => 'gender'.' ! '.$lngmenu->lng_wnotelq,
    			'passportnumber.*.required' => 'passportnumber'.' ! '.$lngmenu->lng_wnotelq,
    		 ]);    
    		 
$departuredate = $wbs->wbs_departuredate ;  


if($ages[$i]=='CHD'){
$birthchd=$months[$i].'/'.$days[$i].'/'.$years[$i];
$maxchild = date('Y-m-d', strtotime('-12 year', strtotime($departuredate))) ;
$childage = date('Y-m-d', strtotime('0 day', strtotime($birthchd))) ;
if($childage<$maxchild){ return redirect('superadmin/buytickets'); }}

if($ages[$i]=='INF'){
$birth=$months[$i].'/'.$days[$i].'/'.$years[$i];
$maxinfant = date('Y-m-d', strtotime('-2 year', strtotime($departuredate))) ;
$infantage = date('Y-m-d', strtotime('0 day', strtotime($birth))) ;
if($infantage<$maxinfant){ return redirect('superadmin/buytickets'); }}

 		 
    		 	
$birthdate=$days[$i].'.'.$months[$i].'.'.$years[$i] ;
 
DB::table('passanger')->insert([
    ['pas_name'  =>  $names[$i] ,'pas_family'  => $familys[$i] ,'pas_national'  =>  $nationals[$i] ,'pas_birthdate'  => $birthdate , 'pas_passportnumber'  =>  $passportnumbers[$i] ,  'pas_gender'  =>  $genders[$i] ,'pas_type'  => $ages[$i] , 'pas_idbelit'  => $belitid     ]
]); 
 

    
     }




 

$airports= \DB::table('countries') ->where([['countries_id', '<>',  '0'],])->orderBy('countries_id')->get(); 
 
    $sess      = filter_var($request->uu_sessionidD, FILTER_SANITIZE_STRING);
    $sessionid      = filter_var($request->sessionidD, FILTER_SANITIZE_STRING);
    $RecommendationID       = $seqd; 
    $genel_toplam       = $price; 
 
 
$wbs=\DB::table('wbs') ->where([['wbs_uuses', '=', Session::get('wbs_uuses')],])->orderBy('id', 'desc')->first(); 
 $result=$wbs->result; $wbssearch=$wbs->id;




$ori = explode("OriginDestinationOptionList,", $result );
$wordChunks = explode('{"Currency":"', $result);
$AirlineCode = explode('"ValidatingAirlineCode":"', $result);
$FlightNumber = explode('"FlightNumber":"', $result);
$ResBookDesigCode = explode('"ResBookDesigCode":"', $result);
$time = explode('"DepartureDateTime":"', $result);
$rezerve = explode('"ResBookDesigQuantity":"', $result);
$Havayolu = explode('"MarketingAirlineName":"', $result);
$TOTALEFARE = explode('"TotalFare":', $result);
$DepartureAirport = explode('"DepartureAirport":"', $result); 
$ArrivalAirport = explode('"ArrivalAirport":"', $result); 
$FlightSegment = explode('FlightSegment', $result); 
$SequenceNumber = explode('SequenceNumber":"', $result); 
 


$i=$seqd+1;
$FlightNumberD = explode('","ResBookDesigCode"', $FlightNumber[$i]);
$ResBookDesigCodeD = explode('","ResBookDesigQuantity"', $ResBookDesigCode[$i]);
$timeD = explode('","ArrivalDateTime"', $time[$i]);
$AirlineCodeD = explode('","ForceETicket":"', $AirlineCode[$i]);
$rezerveD = explode('","DepartureAirport":"', $rezerve[$i]);
$HavayoluD = explode('","Equipment":"', $Havayolu[$i]);
$HavayoluDD = explode('","', $HavayoluD['0']);
$TOTALEFARED = explode(',"ServiceFare":', $TOTALEFARE[$i]);
$DepartureAirportD = explode('","ArrivalAirport":', $DepartureAirport[$i]);
$ArrivalAirportD = explode('","DepartureCityCountry":', $ArrivalAirport[$i]);
$FlightSegmentD = explode('},{"DepartureDateTime":"', $wordChunks[$i]);
$SequenceNumberD = explode('","OriginDestinationOptionList"', $SequenceNumber[$i]);
$flseg=substr_count($SequenceNumber[$i], 'FlightSegment'); 
$flRefNumber=substr_count($SequenceNumber[$i], 'RefNumber');  
$listseg  = explode('","OriginDestinationOptionList"', $wordChunks[$i]); 
$listsegD = explode('","OriginDestinationOptionList"', $listseg['1']);
$refnmD = explode('"RefNumber":"', $listseg['1']); 

$TotalFare = explode(',"TotalFare":', $wordChunks[$i]);
$TotalFareD = explode(',"ServiceFare":', $TotalFare['1']);

                      

$j=$CombinationIDD+1; 

$feldsq  = explode('FlightSegment":[{', $listsegD['0']); 

$refnmsD = explode('FlightSegment', $refnmD[$j]); 
$refnmsND = explode('","DirectionId":"', $refnmsD['0']); 
$ElapsedTime = explode('","ElapsedTime":"', $refnmsD['0']); 
$ElapsedTimeD = explode('","', $ElapsedTime['1']);   
$directsD = explode('","', $ElapsedTime['0']);   
$directsidD = explode('DirectionId":"', $directsD['1']);   


$rfse=substr_count($refnmsD['1'], 'DepartureAirport');   



for($k = 1; $k <  $rfse+1   ; $k++){ 

$airlinemark  = explode('"OperatingAirlineName":"', $refnmsD['1']);
$airlinemarkD  = explode('","', $airlinemark[$k]);

$marketlog  = explode('"MarketingAirline":"', $refnmsD['1']);
$marketlogD  = explode('","', $marketlog[$k]);
       
$airlinemark  = explode('"OperatingAirlineName":"', $refnmsD['1']);
$airlinemarkD  = explode('","', $airlinemark[$k]);

$marketlog  = explode('"MarketingAirline":"', $refnmsD['1']);
$marketlogD  = explode('","', $marketlog[$k]);
 

$flnk = explode('","FlightNumber":"', $refnmsD['1']);
$flnkD = explode('","ResBookDesigCode":"', $flnk[$k]);

    $gole = explode('","OperatingAirline":"', $refnmsD['1']);
$goleD = explode('","MarketingAirline":"', $gole[$k]);  

 
$clasnk = explode('","ResBookDesigCode":"', $refnmsD['1']);
$clasnkD = explode('","ResBookDesigQuantity":"', $clasnk[$k]);


$airlinemark  = explode('"OperatingAirlineName":"', $refnmsD['1']);
$airlinemarkD  = explode('","', $airlinemark[$k]);

$marketlog  = explode('"MarketingAirline":"', $refnmsD['1']);
$marketlogD  = explode('","', $marketlog[$k]);
 

$flnk = explode('","FlightNumber":"', $refnmsD['1']);
$flnkD = explode('","ResBookDesigCode":"', $flnk[$k]);

$gole = explode('","OperatingAirline":"', $refnmsD['1']);
$goleD = explode('","MarketingAirline":"', $gole[$k]); 

$clasnk = explode('","ResBookDesigCode":"', $refnmsD['1']);
$clasnkD = explode('","ResBookDesigQuantity":"', $clasnk[$k]);


$citydep = explode(',"DepartureCityCountry":"', $refnmsD['1']);
$citydepD = explode(',', $citydep[$k]);
if($citydepD['0']=='Tahran'){$citydepD['0']='Tehran';} 
	
$feldsqDk = explode(',"DepartureAirport":"', $refnmsD['1']);
$feldsqDkD = explode('(', $feldsqDk[$k]); 
$feldsqDkDD = explode(')', $feldsqDkD['1']);

$feldsqDkar = explode('","ArrivalAirport":"', $refnmsD['1']);
$feldsqDkarD = explode('(', $feldsqDkar[$k]);	

$deptime = explode('"DepartureDateTime":"', $refnmsD['1']);
$deptimeD = explode('","ArrivalDateTime":"', $deptime[$k]);

$artime = explode('","ArrivalDateTime":"', $refnmsD['1']);
$artimeD = explode('","FlightNumber":"', $artime[$k]);	

 $originalDate = $deptimeD['0'];
$newDatedep = date("d F", strtotime($originalDate)); $newDatedept = date("H:i", strtotime($originalDate)); 

 $originalDatea = $artimeD['0'];
$newDatearr = date("d F", strtotime($originalDatea)); $newDatearrt = date("H:i", strtotime($originalDatea));  


$dir_origindate = explode('T', $deptimeD['0']);
$dir_destdate = explode('T', $artimeD['0']);


$cityarriv = explode(',"ArrivaliCityCountry":"', $refnmsD['1']);
$cityarrivD = explode(',', $cityarriv[$k]); 
if($cityarrivD['0']=='Tahran'){$cityarrivD['0']='Tehran';}

$feldsqDk = explode(',"DepartureAirport":"', $refnmsD['1']);
$feldsqDkD = explode('(', $feldsqDk[$k]);

$feldsqDkar = explode('","ArrivalAirport":"', $refnmsD['1']);
$feldsqDkarD = explode('(', $feldsqDkar[$k]);
$feldsqDkDDa = explode(')', $feldsqDkarD['1']);	

$deptime = explode('"DepartureDateTime":"', $refnmsD['1']);
$deptimeD = explode('","ArrivalDateTime":"', $deptime[$k]);

$artime = explode('","ArrivalDateTime":"', $refnmsD['1']);
$artimeD = explode('","FlightNumber":"', $artime[$k]);	
 $originalDate = $deptimeD['0'];
$newDatedep = date("d F", strtotime($originalDate)); $newDatedept = date("H:i", strtotime($originalDate));   $originalDatea = $artimeD['0'];
$newDatearr = date("d F", strtotime($originalDatea)); $newDatearrt = date("H:i", strtotime($originalDatea));  

$luggage = explode('"Luggage":"', $refnmsD['1']);
$luggageD = explode('","', $luggage[$k]);
/*
$bagg=substr_count($luggageD['0'], 'k');    
if($bagg!='0'){  }
if($bagg=='0'){  $bag = explode('parça', $luggageD['0']);   }
if($bag['0']<9){  $dbbag = $bag['0'].' BAG';}
if($bag['0']>9){  $dbbag = $bag['0'].' KG';}
*/
$dbbag = $luggageD['0'];



 $string=$ElapsedTimeD['0']; $min = '';$h = '';
for ($index=0;$index<strlen($string);$index++) { if($index<2){ $h .= $string[$index]; } else { $min .= $string[$index]; }}

 DB::table('direction')->insert([
    ['dir_idbelit'  =>  $belitid ,'dir_airline'  =>  $airlinemarkD['0']    ,'dir_logo'  => $marketlogD['0']  ,'dir_class'  => $clasnkD['0']  ,'dir_numberflight'  =>  $flnkD['0']  ,  'dir_origin' => $citydepD['0']  , 'dir_origindate'  =>  $dir_origindate['0']  ,  'dir_origintime' => $newDatedept  ,  'dir_dest' => $cityarrivD['0']  , 'dir_destdate'  =>  $dir_destdate['0']  ,  'dir_desttime' => $newDatearrt  , 'dir_originairport'  =>  $feldsqDkD['0']  ,  'dir_originmairport' => $feldsqDkDD['0'] , 'dir_destairport'  =>  $feldsqDkarD['0']  ,  'dir_destmairport' => $feldsqDkDDa['0']  , 'dir_bag'  =>  $dbbag  ,    'dir_durit'  =>  $h.'Hours '.$min.'Minute' ,    'dir_dir'  =>  '0'  ,    ]
]); 

 

}

 

$wbs_departure=$wbs->wbs_departure;
$wbs_arrival=$wbs->wbs_arrival;

$countdep=strlen($wbs_departure);
$countarr=strlen($wbs_arrival);

if($countdep=='6'){ 
$codedep = explode('C', $wbs_departure);
$departurer=\DB::table('direction') ->where([['dir_idbelit', '=',  $belitid],['dir_dir', '=',  '0'],])->orderBy('id')->first();
$departure=$departurer->dir_originmairport.$codedep['1']; 
$updatee = \DB::table('wbs')->where('wbs_uuses', '=', Session::get('wbs_uuses'))  ->update([  'wbs_departure' => $departure    ]);  }

if($countarr=='6'){ 
$codearr = explode('C', $wbs_arrival);
$departurer=\DB::table('direction') ->where([['dir_idbelit', '=',  $belitid],['dir_dir', '=',  '0'],])->orderBy('id', 'desc')->first();
$arrival=$departurer->dir_destmairport.$codearr['1']; 
$updatee = \DB::table('wbs')->where('wbs_uuses', '=', Session::get('wbs_uuses'))  ->update(['wbs_arrival' => $arrival     ]); }
 
 


$wents=\DB::table('direction') ->where([['dir_idbelit', '=',  $belitid],['dir_dir', '=',  '0'],])->orderBy('id')->get(); 
$wentc=\DB::table('direction') ->where([['dir_idbelit', '=',  $belitid],['dir_dir', '=',  '0'],])->orderBy('id')->count();    
$belits=\DB::table('belits') ->where([['bel_id', '=',  $belitid],['bel_id', '<>',  '0'],])->orderBy('bel_id')->first();
$passangers=\DB::table('passanger') ->where([['pas_idbelit', '=',  $belitid],['id', '<>',  '0'],])->orderBy('id')->get();  


$wbs=\DB::table('wbs') ->where([['wbs_uuses', '=', Session::get('wbs_uuses')],])->orderBy('id', 'desc')->first();

$currency=\DB::table('currency') ->where([['cur_nem', '=',  'USD'],])->orderBy('id', 'desc')->first();





return view('superadmin.buyticketok',['lngmenus' => $lngmenus , 'lngmenu' => $lngmenu,  'result' => $result   ,   'departure' => $departure , 'arrival' => $arrival , 'sessionidDt' => $sessionidD , 'uu_sessionidDt' => $uu_sessionidD  , 'CombinationID' => $CombinationIDD  , 'RecommendationID' => $seqd  , 'priced' => $price , 'wents' => $wents , 'wentc' => $wentc  ,  'belits' => $belits ,  'passangers' => $passangers ,  'wbs' => $wbs ,  'mngindex' => $mngindex , 'currency' => $currency    ]);
 


 

}else{ return redirect('agency/sign-in'); }
}



public function viewsearchwentbackaj(){
if (Session::has('signajency')){
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first(); 
 
$wbs=\DB::table('wbs') ->where([['wbs_uuses', '=', Session::get('wbs_uuses')],])->orderBy('id', 'desc')->first(); 
$result=$wbs->result; $wbssearch=$wbs->id; 
$comids=  \DB::table('comid') ->where([['wbssearch', '=',  $wbssearch],])->orderBy('id')->get(); 

$airports= \DB::table('countries') ->where([['countries_id', '<>',  '0'],])->orderBy('countries_id')->get();
 
    
$datenew = explode(" ", $wbs->wbs_departuredate);   $monthh=$datenew['1']; $dayn=$datenew['2'];  $yearn=$datenew['3'];   
if($monthh=='Jan'){ $monthn='01';} else if($monthh=='Feb'){ $monthn='02';}  else if($monthh=='Mar'){ $monthn='03';}   else if($monthh=='Apr'){ $monthn='04';} else if($monthh=='May'){ $monthn='05';}  else if($monthh=='Jun'){ $monthn='06';}   else if($monthh=='Jul'){ $monthn='07';} else if($monthh=='Aug'){ $monthn='08';}  else if($monthh=='Sep'){ $monthn='09';}   else if($monthh=='Oct'){ $monthn='10';} else if($monthh=='Nov'){ $monthn='11';}  else if($monthh=='Dec'){ $monthn='12';} 
$year = $dayn.'.'.$monthn.'.'.$yearn.''; 


$datenewr = explode(" ", $wbs->wbs_departuredater);   $monthr=$datenewr['1']; $dayr=$datenewr['2'];  $yearrn=$datenewr['3'];   
if($monthr=='Jan'){ $montrn='01';} else if($monthr=='Feb'){ $montrn='02';}  else if($monthr=='Mar'){ $montrn='03';}   else if($monthr=='Apr'){ $montrn='04';} else if($monthr=='May'){ $montrn='05';}  else if($monthr=='Jun'){ $montrn='06';}   else if($monthr=='Jul'){ $montrn='07';} else if($monthr=='Aug'){ $montrn='08';}  else if($monthr=='Sep'){ $montrn='09';}   else if($monthr=='Oct'){ $montrn='10';} else if($monthr=='Nov'){ $montrn='11';}  else if($monthr=='Dec'){ $montrn='12';} 
$yearr = $dayr.'.'.$montrn.'.'.$yearrn.''; 

  

$currency=\DB::table('currency') ->where([['cur_nem', '=',  'USD'],])->orderBy('id', 'desc')->first(); 
 
  return view('superadmin.ucackreturn', ['result' => $result , 'lngmenus' => $lngmenus , 'lngmenu' => $lngmenu , 'arrival' => $wbs->wbs_arrival , 'departure' => $wbs->wbs_departure , 'departuredate' => $wbs->wbs_departuredate,'departuredater' => $wbs->wbs_departuredater , 'year' => $year ,'yearr' => $yearr, 'airports' => $airports , 'adult' => $wbs->wbs_adult , 'child' => $wbs->wbs_child, 'infant' => $wbs->wbs_infant , 'wbs' => $wbs  , 'comids' => $comids   , 'currency' => $currency  ]);

}else{ return redirect('agency/sign-in'); }
}




public function buyticketyekreturnaj(Request $request){
if (Session::has('signajency')){ 
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();   	    


$adult = $request->input('adult'); 
$child = $request->input('child'); 
$infant = $request->input('infant'); 
$departure = $request->input('departure'); 
$arrival = $request->input('arrival'); 
$sessionidD = $request->input('sessionidD'); 
$uu_sessionidD = $request->input('uu_sessionidD');
$hisd = $request->input('hisd');   
 
if($hisd !=NULL){
$total = explode('/', $hisd );
 $seqd=$total['0'];
 $price=$total['1']; 
 $CombinationIDD=$total['2'];
 $went=$total['3'];
 $back=$total['4'];
}  


 

    $sess      = filter_var($request->uu_sessionidD, FILTER_SANITIZE_STRING);
    $sessionid      = filter_var($request->sessionidD, FILTER_SANITIZE_STRING);
    $RecommendationID       = $seqd; 
    $genel_toplam       = $price; 


$adultbp = $request->input('adultbp'); 
$childbp = $request->input('childbp'); 
$infantbp = $request->input('infantbp'); 

$adultsp = $request->input('adultsp'); 
$childsp = $request->input('childsp'); 
$infantsp = $request->input('infantsp'); 

$adulttp = $request->input('adulttp'); 
$childtp = $request->input('childtp'); 
$infanttp = $request->input('infanttp'); 
    
$updatee = \DB::table('wbs')->where('wbs_uuses', '=', Session::get('wbs_uuses'))  ->update(['wbs_seq' => $seqd , 'wbs_comb' => $CombinationIDD , 'wbs_price' => $price  , 'wbs_hisd' => $hisd  , 'wbs_adtbprice' => $adultbp  , 'wbs_adtsprice' => $adultsp  , 'wbs_adttprice' => $adulttp  , 'wbs_chdbprice' => $childbp  , 'wbs_chdsprice' => $childsp  , 'wbs_chdtprice' => $childtp , 'wbs_infbprice' => $infantbp  , 'wbs_infsprice' => $infantsp  , 'wbs_inftprice' => $infanttp  ]); 		  


    
    

$airports= \DB::table('countries') ->where([['countries_id', '<>',  '0'],])->orderBy('countries_id')->get(); 
 	  

return redirect('agency/buyticketsreturn');    


}else{ return redirect('agency/sign-in'); }
}

 
 

	public function buyticketsyekreturnaj(){
if (Session::has('signajency')){
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first(); 
    
$wbs=\DB::table('wbs') ->where([['wbs_uuses', '=', Session::get('wbs_uuses')],])->orderBy('id', 'desc')->first(); 
$result=$wbs->result;

$airports= \DB::table('countries') ->where([['countries_id', '<>',  '0'],])->orderBy('countries_id')->get(); 
 
 
        $requestt = '{
            combination_id: "'.$wbs->wbs_comb.'",
            recommandationid: "'.$wbs->wbs_seq.'",
            passengertype: "ADT",
            sessionid: "'.$wbs->wbs_sesid.'",
            providercode: "AMA" 
        }';
        
    
        
    $headers = array(
        'username:atin_user',
        'password:X4fVgT3a',
        'Content-Type:application/json',
        'request:'.$requestt
    );
        
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://ucuzauc.com/api/getrules/4e53defd-7620-4ac1-b7e1-61c43f34bb76");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $requestt);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 5);
    curl_setopt($ch, CURLOPT_TIMEOUT, 59);
    curl_setopt($ch, CURLOPT_HEADER, 1);
$resultt = curl_exec($ch); 


$currency=\DB::table('currency') ->where([['cur_nem', '=',  'USD'],])->orderBy('id', 'desc')->first();




 
 return view('superadmin.buyticketreturn',['lngmenus' => $lngmenus , 'lngmenu' => $lngmenu, 'hisd' => $wbs->wbs_hisd , 'result' => $result , 'airports' => $airports , 'adult' => $wbs->wbs_adult , 'child' => $wbs->wbs_child , 'infant' => $wbs->wbs_infant , 'departure' => $wbs->wbs_departure , 'arrival' => $wbs->wbs_arrival , 'sessionidDt' => $wbs->wbs_sesid , 'uu_sessionidDt' => $wbs->wbs_uuses  , 'CombinationID' => $wbs->wbs_comb  , 'RecommendationID' => $wbs->wbs_seq  , 'priced' => $wbs->wbs_price  , 'ruuls' => $resultt  , 'wbs' => $wbs , 'currency' => $currency   ]); 



}else{ return redirect('agency/sign-in'); }
}


public function buyticketyekpasngrtaj(Request $request){
if (Session::has('signajency')){ 
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();   	    
 
	 Session::set('urlaro', 'agency'); 
$this->validate($request,[
    			'email' => 'required|email',
    			'tell' => 'required|min:3|max:33',
    		],[
    			'email.required' => $lngmenu->lng_wemail.' ! '.$lngmenu->lng_wnotelq,
    			'email.email' => $lngmenu->lng_wemail.' ! '.$lngmenu->lng_wnotelq,
    			'tell.required' => $lngmenu->lng_wtell.' ! '.$lngmenu->lng_wnotelq,
    			'tell.min' => $lngmenu->lng_wtell.' ! '.$lngmenu->lng_wnotelq,
    			'tell.max' => $lngmenu->lng_wemail.' ! '.$lngmenu->lng_wnotelq,
    			
    		]);
    


$email = $request->input('email'); 
$tell = $request->input('tell'); 
$adult = $request->input('adult'); 
$child = $request->input('child'); 
$infant = $request->input('infant'); 
$departure = $request->input('departure'); 
$arrival = $request->input('arrival'); 
$sessionidD = $request->input('sessionidD'); 
$uu_sessionidD = $request->input('uu_sessionidD');


$hisd = $request->input('hisd');   
 
if($hisd !=NULL){
$total = explode('/', $hisd );
 $seqd=$total['0'];
 $price=$total['1']; 
 $CombinationIDD=$total['2'];
 $went=$total['3'];
 $back=$total['4'];
}  




$genders = $request->input('gender'); 
$names = $request->input('name'); 
$familys = $request->input('family'); 
$days = $request->input('day'); 
$months = $request->input('month'); 
$years = $request->input('year'); 
$ages = $request->input('age');  
$nationals = $request->input('national'); 
$passportnumbers = $request->input('passportnumber');





$mngindex=\DB::table('mngindex') ->where([['id', '=', '1'],])->orderBy('id', 'desc')->first(); 
$currency=\DB::table('currency') ->where([['cur_nem', '=',  'USD'],])->orderBy('id', 'desc')->first(); 
$paybelc = $currency->cur_rateajency * $price;
$paybel= number_format($mngindex->ind_taxp + $paybelc , 2);

 DB::table('belits')->insert([
    ['bel_email'  =>  $email    , 'bel_tell'  => $tell   , 'bel_ses'  => Session::get('wbs_uuses')   ,'bel_basefare'  => $price ,'bel_pay'  => $paybel , 'bel_createdatdate'  => date('Y-m-d H:i:s')       ]
]); 


$belits=\DB::table('belits')->where([['bel_ses', '=', Session::get('wbs_uuses')],])->orderBy('bel_id', 'desc')->first();   
$belitid=$belits->bel_id;


$wbs=\DB::table('wbs') ->where([['wbs_uuses', '=', Session::get('wbs_uuses')],])->orderBy('id', 'desc')->first(); 







    for ($i = 0; $i< count($ages); $i++){
 

 $this->validate($request,[
    			'name.*' => 'required',
    			'family.*' => 'required',
    			'national.*' => 'required',
    			'year.*' => 'required',
    			'month.*' => 'required',
    			'day.*' => 'required',
    			'gender.*' => 'required',
    			'passportnumber.*' => 'required',
    		],[
    			'name.*.required' => $lngmenu->lng_wname.' ! '.$lngmenu->lng_wnotelq,
    			'family.*.required' => 'family'.' ! '.$lngmenu->lng_wnotelq,
    			'national.*.required' => 'national'.' ! '.$lngmenu->lng_wnotelq,
    			'year.*.required' => 'year'.' ! '.$lngmenu->lng_wnotelq,
    			'month.*.required' => 'month'.' ! '.$lngmenu->lng_wnotelq,
    			'day.*.required' => 'day'.' ! '.$lngmenu->lng_wnotelq,
    			'gender.*.required' => 'gender'.' ! '.$lngmenu->lng_wnotelq,
    			'passportnumber.*.required' => 'passportnumber'.' ! '.$lngmenu->lng_wnotelq,
    		 ]);    
    		 
$departuredate = $wbs->wbs_departuredater ;  


if($ages[$i]=='CHD'){
$birthchd=$months[$i].'/'.$days[$i].'/'.$years[$i];
$maxchild = date('Y-m-d', strtotime('-12 year', strtotime($departuredate))) ;
$childage = date('Y-m-d', strtotime('0 day', strtotime($birthchd))) ;
if($childage<$maxchild){ return redirect('superadmin/buyticketsreturn'); }}

if($ages[$i]=='INF'){
$birth=$months[$i].'/'.$days[$i].'/'.$years[$i];
$maxinfant = date('Y-m-d', strtotime('-2 year', strtotime($departuredate))) ;
$infantage = date('Y-m-d', strtotime('0 day', strtotime($birth))) ;
if($infantage<$maxinfant){ return redirect('superadmin/buyticketsreturn'); }}

 		 
    	
$birthdate=$days[$i].'.'.$months[$i].'.'.$years[$i] ;

DB::table('passanger')->insert([
    ['pas_name'  =>  $names[$i] ,'pas_family'  => $familys[$i] ,'pas_national'  =>  $nationals[$i] ,'pas_birthdate'  => $birthdate , 'pas_passportnumber'  =>  $passportnumbers[$i] ,  'pas_gender'  =>  $genders[$i] ,'pas_type'  => $ages[$i] , 'pas_idbelit'  => $belitid     ]
]); 
 
  }

 

$airports= \DB::table('countries') ->where([['countries_id', '<>',  '0'],])->orderBy('countries_id')->get(); 
 
    $sess      = filter_var($request->uu_sessionidD, FILTER_SANITIZE_STRING);
    $sessionid      = filter_var($request->sessionidD, FILTER_SANITIZE_STRING);
    $RecommendationID       = $seqd; 
    $genel_toplam       = $price; 
 
 
$wbs=\DB::table('wbs') ->where([['wbs_uuses', '=', Session::get('wbs_uuses')],])->orderBy('id', 'desc')->first();  
 $result=$wbs->result; $wbssearch=$wbs->id;


$ori = explode("OriginDestinationOptionList,", $result );
$wordChunks = explode('{"Currency":"', $result);
$SequenceNumber = explode('SequenceNumber":"', $result);
$sessionid = explode('","sessionid":"', $result);
$sessionidD = explode('","', $sessionid['1']);
$sessionidD = $sessionidD['0'];
$uu_sessionid = explode('"uu_SessionId":"' , $result);
$uu_sessionidD = explode('","sessionid":"' , $uu_sessionid['1']);
$uu_sessionidD = $uu_sessionidD['0'];


 
$SequenceNumberD = explode('","OriginDestinationOptionList"', $SequenceNumber[$seqd+1]);
$listseg  = explode('","OriginDestinationOptionList"', $wordChunks[$seqd+1]); 
$listsegD = explode('","OriginDestinationOptionList"', $listseg['1']); 
$TotalFare = explode(',"TotalFare":', $wordChunks[$seqd+1]);
$TotalFareD = explode(',"ServiceFare":', $TotalFare['1']);


$refnmD = explode('"RefNumber":"'.$went.'","DirectionId":"0",', $listseg['1']); 

$feldsq  = explode('FlightSegment":[{', $listsegD['0']); 
$refnmsD = explode('FlightSegment', $refnmD['1']); 
$ElapsedTime = explode('ElapsedTime":"', $refnmsD['0']); 
$ElapsedTimeD = explode('","', $ElapsedTime['1']);   
$rfse=substr_count($refnmsD['1'], 'DepartureAirport');

$SequenceNumberD = explode('","OriginDestinationOptionList"', $SequenceNumber[$seqd+1]);
$listseg  = explode('","OriginDestinationOptionList"', $wordChunks[$seqd+1]); 
$listsegD = explode('","OriginDestinationOptionList"', $listseg['1']); 
$TotalFare = explode(',"TotalFare":', $wordChunks[$seqd+1]);
$TotalFareD = explode(',"ServiceFare":', $TotalFare['1']);

$refnmD = explode('"RefNumber":"'.$went.'","DirectionId":"0",', $listseg['1']); 


$feldsq  = explode('FlightSegment":[{', $listsegD['0']); 
$refnmsD = explode('FlightSegment', $refnmD['1']); 
$ElapsedTime = explode('ElapsedTime":"', $refnmsD['0']); 
$ElapsedTimeD = explode('","', $ElapsedTime['1']);   
$rfse=substr_count($refnmsD['1'], 'DepartureAirport');

for($k = 1; $k <  $rfse+1   ; $k++){ 

$airlinemark  = explode('"OperatingAirlineName":"', $refnmsD['1']);
$airlinemarkD  = explode('","', $airlinemark[$k]);

$marketlog  = explode('"MarketingAirline":"', $refnmsD['1']);
$marketlogD  = explode('","', $marketlog[$k]);
       
$airlinemark  = explode('"OperatingAirlineName":"', $refnmsD['1']);
$airlinemarkD  = explode('","', $airlinemark[$k]);

$marketlog  = explode('"MarketingAirline":"', $refnmsD['1']);
$marketlogD  = explode('","', $marketlog[$k]);
 

$flnk = explode('","FlightNumber":"', $refnmsD['1']);
$flnkD = explode('","ResBookDesigCode":"', $flnk[$k]);

    $gole = explode('","OperatingAirline":"', $refnmsD['1']);
$goleD = explode('","MarketingAirline":"', $gole[$k]);  

 
$clasnk = explode('","ResBookDesigCode":"', $refnmsD['1']);
$clasnkD = explode('","ResBookDesigQuantity":"', $clasnk[$k]);


$airlinemark  = explode('"OperatingAirlineName":"', $refnmsD['1']);
$airlinemarkD  = explode('","', $airlinemark[$k]);

$marketlog  = explode('"MarketingAirline":"', $refnmsD['1']);
$marketlogD  = explode('","', $marketlog[$k]);
 

$flnk = explode('","FlightNumber":"', $refnmsD['1']);
$flnkD = explode('","ResBookDesigCode":"', $flnk[$k]);

$gole = explode('","OperatingAirline":"', $refnmsD['1']);
$goleD = explode('","MarketingAirline":"', $gole[$k]); 

$clasnk = explode('","ResBookDesigCode":"', $refnmsD['1']);
$clasnkD = explode('","ResBookDesigQuantity":"', $clasnk[$k]);


$citydep = explode(',"DepartureCityCountry":"', $refnmsD['1']);
$citydepD = explode(',', $citydep[$k]);
if($citydepD['0']=='Tahran'){$citydepD['0']='Tehran';} 
	
$feldsqDk = explode(',"DepartureAirport":"', $refnmsD['1']);
$feldsqDkD = explode('(', $feldsqDk[$k]); 
$feldsqDkDD = explode(')', $feldsqDkD['1']);

$feldsqDkar = explode('","ArrivalAirport":"', $refnmsD['1']);
$feldsqDkarD = explode('(', $feldsqDkar[$k]);	

$deptime = explode('"DepartureDateTime":"', $refnmsD['1']);
$deptimeD = explode('","ArrivalDateTime":"', $deptime[$k]);

$artime = explode('","ArrivalDateTime":"', $refnmsD['1']);
$artimeD = explode('","FlightNumber":"', $artime[$k]);	

 $originalDate = $deptimeD['0'];
$newDatedep = date("d F", strtotime($originalDate)); $newDatedept = date("H:i", strtotime($originalDate)); 

 $originalDatea = $artimeD['0'];
$newDatearr = date("d F", strtotime($originalDatea)); $newDatearrt = date("H:i", strtotime($originalDatea));  


$dir_origindate = explode('T', $deptimeD['0']);
$dir_destdate = explode('T', $artimeD['0']);


$cityarriv = explode(',"ArrivaliCityCountry":"', $refnmsD['1']);
$cityarrivD = explode(',', $cityarriv[$k]); 
if($cityarrivD['0']=='Tahran'){$cityarrivD['0']='Tehran';}

$feldsqDk = explode(',"DepartureAirport":"', $refnmsD['1']);
$feldsqDkD = explode('(', $feldsqDk[$k]);

$feldsqDkar = explode('","ArrivalAirport":"', $refnmsD['1']);
$feldsqDkarD = explode('(', $feldsqDkar[$k]);
$feldsqDkDDa = explode(')', $feldsqDkarD['1']);	

$deptime = explode('"DepartureDateTime":"', $refnmsD['1']);
$deptimeD = explode('","ArrivalDateTime":"', $deptime[$k]);

$artime = explode('","ArrivalDateTime":"', $refnmsD['1']);
$artimeD = explode('","FlightNumber":"', $artime[$k]);	
 $originalDate = $deptimeD['0'];
$newDatedep = date("d F", strtotime($originalDate)); $newDatedept = date("H:i", strtotime($originalDate));   $originalDatea = $artimeD['0'];
$newDatearr = date("d F", strtotime($originalDatea)); $newDatearrt = date("H:i", strtotime($originalDatea));  

$luggage = explode('"Luggage":"', $refnmsD['1']);
$luggageD = explode('","', $luggage[$k]);
/*
$bagg=substr_count($luggageD['0'], 'k');    
if($bagg!='0'){  }
if($bagg=='0'){  $bag = explode('parça', $luggageD['0']);   }
if($bag['0']<9){  $dbbag = $bag['0'].' BAG';}
if($bag['0']>9){  $dbbag = $bag['0'].' KG';}
*/
$dbbag = $luggageD['0'];




 $string=$ElapsedTimeD['0']; $min = '';$h = '';
for ($index=0;$index<strlen($string);$index++) { if($index<2){ $h .= $string[$index]; } else { $min .= $string[$index]; }}

 DB::table('direction')->insert([
    ['dir_idbelit'  =>  $belitid ,'dir_airline'  =>  $airlinemarkD['0']    ,'dir_logo'  => $marketlogD['0']  ,'dir_class'  => $clasnkD['0']  ,'dir_numberflight'  =>  $flnkD['0']  ,  'dir_origin' => $citydepD['0']  , 'dir_origindate'  =>  $dir_origindate['0']  ,  'dir_origintime' => $newDatedept  ,  'dir_dest' => $cityarrivD['0']  , 'dir_destdate'  =>  $dir_destdate['0']  ,  'dir_desttime' => $newDatearrt  , 'dir_originairport'  =>  $feldsqDkD['0']  ,  'dir_originmairport' => $feldsqDkDD['0'] , 'dir_destairport'  =>  $feldsqDkarD['0']  ,  'dir_destmairport' => $feldsqDkDDa['0']  , 'dir_bag'  =>  $dbbag  ,    'dir_durit'  =>  $h.'Hours '.$min.'Minute' ,    'dir_dir'  =>  '0'  ,    ]
]); 

}




$wbs_departure=$wbs->wbs_departure;
$wbs_arrival=$wbs->wbs_arrival;

$countdep=strlen($wbs_departure);
$countarr=strlen($wbs_arrival);

if($countdep=='6'){ 
$codedep = explode('C', $wbs_departure);
$departurer=\DB::table('direction') ->where([['dir_idbelit', '=',  $belitid],['dir_dir', '=',  '0'],])->orderBy('id')->first();
$departure=$departurer->dir_originmairport.$codedep['1']; 
$updatee = \DB::table('wbs')->where('wbs_uuses', '=', Session::get('wbs_uuses'))  ->update([  'wbs_departure' => $departure    ]);  }

if($countarr=='6'){ 
$codearr = explode('C', $wbs_arrival);
$departurer=\DB::table('direction') ->where([['dir_idbelit', '=',  $belitid],['dir_dir', '=',  '0'],])->orderBy('id', 'desc')->first();
$arrival=$departurer->dir_destmairport.$codearr['1']; 
$updatee = \DB::table('wbs')->where('wbs_uuses', '=', Session::get('wbs_uuses'))  ->update(['wbs_arrival' => $arrival     ]); }
 
 

$refnmD = explode('"RefNumber":"'.$back.'","DirectionId":"1",', $listseg['1']); 

$feldsq  = explode('FlightSegment":[{', $listsegD['0']); 
$refnmsD = explode('FlightSegment', $refnmD['1']); 
$ElapsedTime = explode('ElapsedTime":"', $refnmsD['0']); 
$ElapsedTimeD = explode('","', $ElapsedTime['1']);   
$rfse=substr_count($refnmsD['1'], 'DepartureAirport');

$SequenceNumberD = explode('","OriginDestinationOptionList"', $SequenceNumber[$seqd+1]);
$listseg  = explode('","OriginDestinationOptionList"', $wordChunks[$seqd+1]); 
$listsegD = explode('","OriginDestinationOptionList"', $listseg['1']); 
$TotalFare = explode(',"TotalFare":', $wordChunks[$seqd+1]);
$TotalFareD = explode(',"ServiceFare":', $TotalFare['1']);

$refnmD = explode('"RefNumber":"'.$back.'","DirectionId":"1",', $listseg['1']); 


$feldsq  = explode('FlightSegment":[{', $listsegD['0']); 
$refnmsD = explode('FlightSegment', $refnmD['1']); 
$ElapsedTime = explode('ElapsedTime":"', $refnmsD['0']); 
$ElapsedTimeD = explode('","', $ElapsedTime['1']);   
$rfse=substr_count($refnmsD['1'], 'DepartureAirport');

for($k = 1; $k <  $rfse+1   ; $k++){ 

$airlinemark  = explode('"OperatingAirlineName":"', $refnmsD['1']);
$airlinemarkD  = explode('","', $airlinemark[$k]);

$marketlog  = explode('"MarketingAirline":"', $refnmsD['1']);
$marketlogD  = explode('","', $marketlog[$k]);
       
$airlinemark  = explode('"OperatingAirlineName":"', $refnmsD['1']);
$airlinemarkD  = explode('","', $airlinemark[$k]);

$marketlog  = explode('"MarketingAirline":"', $refnmsD['1']);
$marketlogD  = explode('","', $marketlog[$k]);
 

$flnk = explode('","FlightNumber":"', $refnmsD['1']);
$flnkD = explode('","ResBookDesigCode":"', $flnk[$k]);

    $gole = explode('","OperatingAirline":"', $refnmsD['1']);
$goleD = explode('","MarketingAirline":"', $gole[$k]);  

 
$clasnk = explode('","ResBookDesigCode":"', $refnmsD['1']);
$clasnkD = explode('","ResBookDesigQuantity":"', $clasnk[$k]);


$airlinemark  = explode('"OperatingAirlineName":"', $refnmsD['1']);
$airlinemarkD  = explode('","', $airlinemark[$k]);

$marketlog  = explode('"MarketingAirline":"', $refnmsD['1']);
$marketlogD  = explode('","', $marketlog[$k]);
 

$flnk = explode('","FlightNumber":"', $refnmsD['1']);
$flnkD = explode('","ResBookDesigCode":"', $flnk[$k]);

$gole = explode('","OperatingAirline":"', $refnmsD['1']);
$goleD = explode('","MarketingAirline":"', $gole[$k]); 

$clasnk = explode('","ResBookDesigCode":"', $refnmsD['1']);
$clasnkD = explode('","ResBookDesigQuantity":"', $clasnk[$k]);


$citydep = explode(',"DepartureCityCountry":"', $refnmsD['1']);
$citydepD = explode(',', $citydep[$k]);
if($citydepD['0']=='Tahran'){$citydepD['0']='Tehran';} 
	
$feldsqDk = explode(',"DepartureAirport":"', $refnmsD['1']);
$feldsqDkD = explode('(', $feldsqDk[$k]); 
$feldsqDkDD = explode(')', $feldsqDkD['1']);

$feldsqDkar = explode('","ArrivalAirport":"', $refnmsD['1']);
$feldsqDkarD = explode('(', $feldsqDkar[$k]);	

$deptime = explode('"DepartureDateTime":"', $refnmsD['1']);
$deptimeD = explode('","ArrivalDateTime":"', $deptime[$k]);

$artime = explode('","ArrivalDateTime":"', $refnmsD['1']);
$artimeD = explode('","FlightNumber":"', $artime[$k]);	

 $originalDate = $deptimeD['0'];
$newDatedep = date("d F", strtotime($originalDate)); $newDatedept = date("H:i", strtotime($originalDate)); 

 $originalDatea = $artimeD['0'];
$newDatearr = date("d F", strtotime($originalDatea)); $newDatearrt = date("H:i", strtotime($originalDatea));  


$dir_origindate = explode('T', $deptimeD['0']);
$dir_destdate = explode('T', $artimeD['0']);


$cityarriv = explode(',"ArrivaliCityCountry":"', $refnmsD['1']);
$cityarrivD = explode(',', $cityarriv[$k]); 
if($cityarrivD['0']=='Tahran'){$cityarrivD['0']='Tehran';}

$feldsqDk = explode(',"DepartureAirport":"', $refnmsD['1']);
$feldsqDkD = explode('(', $feldsqDk[$k]);

$feldsqDkar = explode('","ArrivalAirport":"', $refnmsD['1']);
$feldsqDkarD = explode('(', $feldsqDkar[$k]);
$feldsqDkDDa = explode(')', $feldsqDkarD['1']);	

$deptime = explode('"DepartureDateTime":"', $refnmsD['1']);
$deptimeD = explode('","ArrivalDateTime":"', $deptime[$k]);

$artime = explode('","ArrivalDateTime":"', $refnmsD['1']);
$artimeD = explode('","FlightNumber":"', $artime[$k]);	
 $originalDate = $deptimeD['0'];
$newDatedep = date("d F", strtotime($originalDate)); $newDatedept = date("H:i", strtotime($originalDate));   $originalDatea = $artimeD['0'];
$newDatearr = date("d F", strtotime($originalDatea)); $newDatearrt = date("H:i", strtotime($originalDatea));  

$luggage = explode('"Luggage":"', $refnmsD['1']);
$luggageD = explode('","', $luggage[$k]);
/*
$bagg=substr_count($luggageD['0'], 'k');    
if($bagg!='0'){  }
if($bagg=='0'){  $bag = explode('parça', $luggageD['0']);   }
if($bag['0']<9){  $dbbag = $bag['0'].' BAG';}
if($bag['0']>9){  $dbbag = $bag['0'].' KG';}
*/
$dbbag = $luggageD['0'];



 $string=$ElapsedTimeD['0']; $min = '';$h = '';
for ($index=0;$index<strlen($string);$index++) { if($index<2){ $h .= $string[$index]; } else { $min .= $string[$index]; }}

 DB::table('direction')->insert([
    ['dir_idbelit'  =>  $belitid ,'dir_airline'  =>  $airlinemarkD['0']    ,'dir_logo'  => $marketlogD['0']  ,'dir_class'  => $clasnkD['0']  ,'dir_numberflight'  =>  $flnkD['0']  ,  'dir_origin' => $citydepD['0']  , 'dir_origindate'  =>  $dir_origindate['0']  ,  'dir_origintime' => $newDatedept  ,  'dir_dest' => $cityarrivD['0']  , 'dir_destdate'  =>  $dir_destdate['0']  ,  'dir_desttime' => $newDatearrt  , 'dir_originairport'  =>  $feldsqDkD['0']  ,  'dir_originmairport' => $feldsqDkDD['0'] , 'dir_destairport'  =>  $feldsqDkarD['0']  ,  'dir_destmairport' => $feldsqDkDDa['0']  , 'dir_bag'  =>  $dbbag  ,    'dir_durit'  =>  $h.'Hours '.$min.'Minute' ,    'dir_dir'  =>  '1'  ,    ]
]); 

}



$wbs_departure=$wbs->wbs_departure;
$wbs_arrival=$wbs->wbs_arrival;

$countdep=strlen($wbs_departure);
$countarr=strlen($wbs_arrival);

if($countdep=='6'){ 
$codedep = explode('C', $wbs_departure);
$departurer=\DB::table('direction') ->where([['dir_idbelit', '=',  $belitid],['dir_dir', '=',  '1'],])->orderBy('id')->first();
$departure=$departurer->dir_originmairport.$codedep['1']; 
$updatee = \DB::table('wbs')->where('wbs_uuses', '=', Session::get('wbs_uuses'))  ->update([  'wbs_departure' => $departure    ]);  }

if($countarr=='6'){ 
$codearr = explode('C', $wbs_arrival);
$departurer=\DB::table('direction') ->where([['dir_idbelit', '=',  $belitid],['dir_dir', '=',  '1'],])->orderBy('id', 'desc')->first();
$arrival=$departurer->dir_destmairport.$codearr['1']; 
$updatee = \DB::table('wbs')->where('wbs_uuses', '=', Session::get('wbs_uuses'))  ->update(['wbs_arrival' => $arrival     ]); }
 

  
$wents=\DB::table('direction') ->where([['dir_idbelit', '=',  $belitid],['dir_dir', '=',  '0'],])->orderBy('id')->get(); 
$wentc=\DB::table('direction') ->where([['dir_idbelit', '=',  $belitid],['dir_dir', '=',  '0'],])->orderBy('id')->count();   
$backs=\DB::table('direction') ->where([['dir_idbelit', '=',  $belitid],['dir_dir', '=',  '1'],])->orderBy('id')->get(); 
$backc=\DB::table('direction') ->where([['dir_idbelit', '=',  $belitid],['dir_dir', '=',  '1'],])->orderBy('id')->count(); 

$belits=\DB::table('belits') ->where([['bel_id', '=',  $belitid],['bel_id', '<>',  '0'],])->orderBy('bel_id')->first();
$passangers=\DB::table('passanger') ->where([['pas_idbelit', '=',  $belitid],['id', '<>',  '0'],])->orderBy('id')->get();  

 
$currency=\DB::table('currency') ->where([['cur_nem', '=',  'USD'],])->orderBy('id', 'desc')->first();

 

 
    
return view('superadmin.buyticketreturnok',['lngmenus' => $lngmenus , 'lngmenu' => $lngmenu, 'hisd' => $hisd , 'result' => $result   ,   'departure' => $departure , 'arrival' => $arrival , 'sessionidDt' => $sessionidD , 'uu_sessionidDt' => $uu_sessionidD  , 'CombinationID' => $CombinationIDD  , 'RecommendationID' => $seqd  , 'priced' => $price , 'wents' => $wents , 'wentc' => $wentc , 'backs' => $backs ,  'backc' => $backc ,  'belits' => $belits ,  'passangers' => $passangers  , 'wbs' => $wbs    , 'mngindex' => $mngindex  , 'currency' => $currency   ]);
 
 

}else{ return redirect('agency/sign-in'); }
}



public function buyticketyekpasngraj(Request $request){
if (Session::has('signajency')){ 
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();   	    
 
 
 
   
$CombinationID = $request->input('CombinationID');
$RecommendationID = $request->input('RecommendationID');
$priced = $request->input('priced');
$adult = $request->input('adult'); 
$child = $request->input('child'); 
$infant = $request->input('infant'); 
$sessionidD = $request->input('sessionidD'); 
$uu_sessionidD = $request->input('uu_sessionidD');
$hisd = $request->input('hisd');  
$bel_id = $request->input('bel_id');  


$genders = $request->input('gender'); 
$names = $request->input('name'); 
$familys = $request->input('family'); 
$days = $request->input('day'); 
$months = $request->input('month'); 
$years = $request->input('year'); 
$ages = $request->input('age');  
$nationals = $request->input('national'); 
$passportnumbers = $request->input('passportnumber');
 

$wbs=\DB::table('wbs') ->where([['wbs_uuses', '=', Session::get('wbs_uuses')],])->orderBy('id', 'desc')->first();  



$departure=$wbs->wbs_departure;
$arrival=$wbs->wbs_arrival;

    $cardname   = "kol aj hiol";
    $cardnumber = "4508034508034509";
    $cardmonth  = "12";
    $cardyear   = "2019";
    $cardcvv    = "000";



    $genel_toplam           = $priced; //** TotalFare
    $data = array(
        "clientid"       => "",
        "weborpanel"     => 0,
        "reselleruserid" => 0,
        "domainname"     => "", //** it can be empty 
        "flighttype"     => "abroad", 
        "destination"    => "{$departure}",
        "arrival"        => "{$arrival}",
        "sessionid"      => "{$sessionidD}",   //** "sessionid":"ASP.NET_SessionId=hk4vaza5c24t0jdxh14qyqiz; path=/; HttpOnly"
        "passengerlist"  => array(),
        "CombinationID"     =>"{$CombinationID}", 
        "RecommendationID"   =>"{$RecommendationID}",
        "creditcard"         => array(
            "cardname"     => "{$cardname}",
            "cardnumber"   => "{$cardnumber}",
            "cardmonth"    => "{$cardmonth}",
            "cardyear"     => "{$cardyear}",
            "cardcvv"      => "{$cardcvv}",
            "baseprice"    => "{$genel_toplam}",
            "totalprice"   => "{$genel_toplam}", 
            "bankid"       => "64", 
            "installment"  => "0"
        ),
        


        "billing"                =>  null,
        "email"                  => "mustafa1390@gmail.com",
        "phone"                  => "00989384762155"

    );
 

$belits=\DB::table('belits') ->where([['bel_id', '=',  $bel_id],['bel_id', '<>',  '0'],])->orderBy('bel_id', 'desc')->first();
$belpay=$belits->bel_pay;

$passangers=\DB::table('passanger') ->where([['pas_idbelit', '=',  $bel_id],['id', '<>',  '0'],])->orderBy('id')->get();  


foreach($passangers as $passanger){

 
        $data['passengerlist'][] = array(
                                "gender"   => $passanger->pas_gender,
                                "type"     => $passanger->pas_type,
                                "name"     => $passanger->pas_name,
                                "surname"  => $passanger->pas_family,
                                "tckimlik" => "0",
                                "national"=> $passanger->pas_national,                
                                "passportnumber"=> $passanger->pas_passportnumber,      
                                "birthdate"=> $passanger->pas_birthdate 

                                );	
 

 
    
     }
  




$charges = \DB::table('charge')->where([['charge_id', '<>',  '0'],['charge_arou', '=',  '3'],['charge_iduser', '=', Session::get('idajency')],])->orderBy('charge_id', 'desc')->get();
$chargepay=0;
foreach($charges as $charge){ $chargepay=$charge->charge_pay+$chargepay; }

$belits=  \DB::table('belits')->where([['bel_id', '<>',  '0'],['bel_mergey', '<>',  ''],['bel_aro', '=',  '3'],['bel_iduser', '=',  Session::get('idajency')],])->orderBy('bel_id', 'desc')->get(); 
$belitget=0;
foreach($belits as $belit){ $belitget=$belit->bel_pay+$belitget; }

$chargeac=$chargepay-$belitget;



if($chargeac < $belpay){
	
$nametr = Session::flash('statust', $lngmenu->lng_werror);
$nametrt = Session::flash('sessurl', 'searchbelit');		  
return view('ajency.error', ['lngmenus' => $lngmenus , 'lngmenu' => $lngmenu ]); 
}  

else 

{



    $data2 = json_encode($data);
    $url   = "https://ucuzauc.com/api/createticket/4e53defd-7620-4ac1-b7e1-61c43f34bb76";    
   $kullanici='atin_user'; 
       $sifre='X4fVgT3a';  
       $sess=$uu_sessionidD; //** "uu_SessionId":"u0zmsxney5uoist2yswcr1qo",
$data1 = array("request: {$data2}" , "username: $kullanici", "password: $sifre", "SetSession: $sess");
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $data1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, array());
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    $result = curl_exec($ch);
   

$statu = explode('tatus":', $result );
$status = explode(',', $statu['1'] );

if($status['0']=='false'){ echo $status['0']; }
else if($status['0']=='true'){ 
$mergey = explode(',"mergekey":"', $result );
$eticketnumber = explode('eticketnumber":"', $result );
$pnrt = explode('"pnr":"', $result );
$mergeykey = explode('","', $mergey['1'] );
$teticketnumber = explode('","', $eticketnumber['1'] );
$pnr = explode('","', $pnrt['1'] );

$updatee = \DB::table('belits')->where('bel_id', '=', $bel_id)  ->update(['bel_mergey' => $mergeykey['0']   ,  'bel_ticketnumber' => $teticketnumber['0']   ,  'bel_pnr' => $pnr['0']  , 'bel_aro' => '1'  , 'bel_iduser' => Session::get('idajency')   ,  'bel_ses' => Session::get('wbs_uuses')  ,  'bel_result' => $result  ]); 

 $wents=  \DB::table('belits')
->join('direction', 'belits.bel_id', '=', 'direction.dir_idbelit') ->where([['bel_mergey', '=',  $mergeykey['0']],['dir_dir', '=',  '0'],])->orderBy('bel_id')->get(); 

 $backc=  \DB::table('belits')
->join('direction', 'belits.bel_id', '=', 'direction.dir_idbelit') ->where([['bel_mergey', '=',  $mergeykey['0']],['dir_dir', '=',  '1'],])->orderBy('bel_id')->count(); 

 $backs=  \DB::table('belits')
->join('direction', 'belits.bel_id', '=', 'direction.dir_idbelit') ->where([['bel_mergey', '=',  $mergeykey['0']],['dir_dir', '=',  '1'],])->orderBy('bel_id')->get(); 

 $passangers=  \DB::table('belits')
->join('passanger', 'belits.bel_id', '=', 'passanger.pas_idbelit') ->where([['bel_mergey', '=',  $mergeykey['0']],])->orderBy('bel_id')->get(); 
 
$belits=\DB::table('belits') ->where([['bel_mergey', '=',  $mergeykey['0']],])->orderBy('bel_id', 'desc')->first(); 

  return view('superadmin.printticket', [  'lngmenus' => $lngmenus , 'lngmenu' => $lngmenu , 'wents' => $wents  , 'passangers' => $passangers , 'belits' => $belits  , 'backs' => $backs  , 'backc' => $backc ]);

 


}

}


 

}else{ return redirect('agency/sign-in'); }
}



 
 
				
				
	public function inccharge(){
	if (Session::has('signajency')){ 
		if (Session::get('activeajency')==1){ 
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();
 return view('ajency.inccharge', [  'lngmenus' => $lngmenus , 'lngmenu' => $lngmenu  ]); 
 }	else if (Session::get('activeajency')==0){    return redirect('agency/activition'); }
else if (empty(Session::has('signajency'))){   return redirect('agency/sign-in'); } }
}		

		
				
				
	public function incchargepost(Request $request){
	if (Session::has('signajency')){ 
		if (Session::get('activeajency')==1){ 
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();

	
    	$this->validate($request,[
    			'tit' => 'required|numeric' 
    		],[
    			'tit.required' => $lngmenu->lng_wcharge.' ! '.$lngmenu->lng_wnotelq,
    			'tit.numeric' => $lngmenu->lng_wcharge.' ! '.$lngmenu->lng_wnotelq, 
    		]);
    	
DB::table('charge')->insert([
    ['charge_pay' => $request->tit ,     'charge_createdatdate' =>  date('Y-m-d H:i:s') , 'charge_arou' => 3 ,  'charge_iduser' => Session::get('idajency')  ]
]);
 
			 $nametr = Session::flash('statust', $lngmenu->lng_wsuccess);
		  	$nametrt = Session::flash('sessurl', 'viewscharges');
		  return view('ajency.success', ['lngmenus' => $lngmenus , 'lngmenu' => $lngmenu ]); 


 }	else if (Session::get('activeajency')==0){    return redirect('agency/activition'); }
else if (empty(Session::has('signajency'))){   return redirect('agency/sign-in'); } }
}		

			
			
			
	
				
	public function viewscharges(){
	if (Session::has('signajency')){ 
		if (Session::get('activeajency')==1){ 
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();


$admins = \DB::table('ajency') 
->join('charge', 'ajency.id', '=', 'charge.charge_iduser') 
->where([
    ['charge.charge_arou', '=', 3],
    ['charge.charge_iduser', '=', Session::get('idajency')],])
    ->orderBy('charge.charge_id', 'desc')->get();
    
   return view('ajency.viewscharges', ['lngmenus' => $lngmenus , 'lngmenu' => $lngmenu , 'admins' => $admins ]);   


 }	else if (Session::get('activeajency')==0){    return redirect('agency/activition'); }
else if (empty(Session::has('signajency'))){   return redirect('agency/sign-in'); } }
}		
		
			
		
	
	public function viewsgdsbelitagency(){
	if (Session::has('signajency')){ 
		if (Session::get('activeajency')==1){ 
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();
$slngmenu=\DB::table('languages') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();	

/*
$charges = \DB::table('ajency') 
->join('charge', 'ajency.id', '=', 'charge.charge_iduser') 
->join('finicals', 'charge.charge_finical', '=', 'finicals.id') 
->where([
    ['charge.charge_arou', '=', $aro],
    ['charge.charge_iduser', '=', $iduser],
    ['finicals.finical_payment', '=', 1],
    ['finicals.finical_inc', '=', 3],])
    ->orderBy('charge.charge_id', 'desc')->get();
*/


 $belits= \DB::table('belits') 
->join('currency', 'belits.bel_cur', '=', 'currency.cur_nem')
->join('finicals', 'belits.bel_id', '=', 'finicals.finical_idbelit') ->where([['bel_id', '<>',  '0'],['bel_mergey', '<>',  ''],['bel_aro', '=',  '3'],['bel_iduser', '=',  Session::get('idajency')],])->orderBy('bel_id', 'desc')->get(); 


$currencyrial=\DB::table('currency') ->where([['cur_nem', '=',  'RIAL'],['cur_active', '=',  '1'],])->orderBy('cur_nem')->first();
$currencyusd=\DB::table('currency') ->where([['cur_nem', '=',  'USD'],['cur_active', '=',  '1'],])->orderBy('cur_nem')->first();



return view('ajency.viewsgdsbelit', ['belits' => $belits ,  'lngmenus' => $lngmenus , 'lngmenu' => $lngmenu , 'slngmenu' => $slngmenu   , 'currencyrial' => $currencyrial   , 'currencyusd' => $currencyusd   ]);
 
 }	else if (Session::get('activeajency')==0){    return redirect('agency/activition'); }
else if (empty(Session::has('signajency'))){   return redirect('agency/sign-in'); } }
}		

		
		
		
		
			
	
	public function belitgdsidagency($id){
	if (Session::has('signajency')){ 
		if (Session::get('activeajency')==1){ 
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();
$slngmenu=\DB::table('languages') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();	


 $wents=  \DB::table('belits')
->join('direction', 'belits.bel_id', '=', 'direction.dir_idbelit') ->where([['bel_mergey', '=',  $id],['dir_dir', '=',  '0'],])->orderBy('id')->get(); 



 $backc=  \DB::table('belits')
->join('direction', 'belits.bel_id', '=', 'direction.dir_idbelit') ->where([['bel_mergey', '=',  $id],['dir_dir', '=',  '1'],])->orderBy('id')->count(); 

 $backs=  \DB::table('belits')
->join('direction', 'belits.bel_id', '=', 'direction.dir_idbelit') ->where([['bel_mergey', '=',  $id],['dir_dir', '=',  '1'],])->orderBy('id')->get(); 


 $passangers=  \DB::table('belits')
->join('passanger', 'belits.bel_id', '=', 'passanger.pas_idbelit') ->where([['bel_mergey', '=',  $id],])->orderBy('bel_id')->get(); 
 
 
$belits= \DB::table('belits') 
->join('currency', 'belits.bel_cur', '=', 'currency.cur_nem')
->join('finicals', 'belits.bel_id', '=', 'finicals.finical_idbelit') ->where([['bel_id', '<>',  '0'],['bel_mergey', '<>',  ''],['bel_aro', '=',  '3'],['bel_iduser', '=',  Session::get('idajency')],])->orderBy('bel_id', 'desc')->first();  

$rulmngindexs=\DB::table('mngindexgds') ->where([['id', '=',  '5'],])->orderBy('id', 'desc')->first(); 

$currencyrial=\DB::table('currency') ->where([['cur_nem', '=',  'RIAL'],['cur_active', '=',  '1'],])->orderBy('cur_nem')->first();
$currencyusd=\DB::table('currency') ->where([['cur_nem', '=',  'USD'],['cur_active', '=',  '1'],])->orderBy('cur_nem')->first();

  return view('ajency.printticket', [  'lngmenus' => $lngmenus , 'lngmenu' => $lngmenu ,  'slngmenu' => $slngmenu  , 'wents' => $wents  , 'passangers' => $passangers , 'belits' => $belits  , 'backs' => $backs  , 'backc' => $backc , 'rulmngindexs' => $rulmngindexs  , 'currencyrial' => $currencyrial   , 'currencyusd' => $currencyusd  ]);
 
 }	else if (Session::get('activeajency')==0){    return redirect('agency/activition'); }
else if (empty(Session::has('signajency'))){   return redirect('agency/sign-in'); } }
}		

	
	
	





	
	public function belitgdsidagencyprint($id){
	if (Session::has('signajency')){ 
		if (Session::get('activeajency')==1){ 
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first(); 

$wents=  \DB::table('belits')
->join('direction', 'belits.bel_id', '=', 'direction.dir_idbelit') ->where([['bel_mergey', '=',  $id],['dir_dir', '=',  '0'],])->orderBy('id')->get(); 


$backc=  \DB::table('belits')
->join('direction', 'belits.bel_id', '=', 'direction.dir_idbelit') ->where([['bel_mergey', '=',  $id],['dir_dir', '=',  '1'],])->orderBy('id')->count(); 

 $backs=  \DB::table('belits')
->join('direction', 'belits.bel_id', '=', 'direction.dir_idbelit') ->where([['bel_mergey', '=',  $id],['dir_dir', '=',  '1'],])->orderBy('id')->get(); 


 $passangers=  \DB::table('belits')
->join('passanger', 'belits.bel_id', '=', 'passanger.pas_idbelit') ->where([['bel_mergey', '=',  $id],])->orderBy('bel_id')->get(); 
 
 
$belits=\DB::table('belits') ->where([['bel_mergey', '=',  $id],])->orderBy('bel_id', 'desc')->first(); 

$rulmngindexs=\DB::table('mngindexgds') ->where([['id', '=',  '5'],])->orderBy('id', 'desc')->first(); 

$currencyrial=\DB::table('currency') ->where([['cur_nem', '=',  'RIAL'],['cur_active', '=',  '1'],])->orderBy('cur_nem')->first();
$currencyusd=\DB::table('currency') ->where([['cur_nem', '=',  'USD'],['cur_active', '=',  '1'],])->orderBy('cur_nem')->first();
 
  return view('ajency.printtickett', [  'lngmenus' => $lngmenus , 'lngmenu' => $lngmenu , 'wents' => $wents  , 'passangers' => $passangers , 'belits' => $belits  , 'backs' => $backs  , 'backc' => $backc , 'rulmngindexs' => $rulmngindexs  , 'currencyrial' => $currencyrial   , 'currencyusd' => $currencyusd   ]);
  
 }	else if (Session::get('activeajency')==0){    return redirect('agency/activition'); }
else if (empty(Session::has('signajency'))){   return redirect('agency/sign-in'); } }
}		

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
		
	
			
			
				
				
	public function addcancellticket(){
		if (Session::has('signajency')){
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();
$slngmenu=\DB::table('languages') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();	
 return view('ajency.addcancellticket', [  'lngmenus' => $lngmenus , 'lngmenu' => $lngmenu , 'slngmenu' => $slngmenu    ]); }	
else{ return redirect('agency/sign-in'); }
		}

	

public function addcancellticketPost(Request $request){
		if (Session::has('signajency')){
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first(); 
$slngmenu=\DB::table('languages') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();		
    	
    	$this->validate($request,[
    			'email' => 'required|email',
    			'pnr' => 'required|min:3|max:99',
    			'des' => 'required|min:5|max:444'
    		],[
    			'email.required' => $lngmenu->lng_wemail.' ! '.$lngmenu->lng_wnotelq, 
    			'email.required' => $lngmenu->lng_wemail.' ! '.$lngmenu->lng_wnotelq, 
    			'pnr.required' => 'PNR'.' ! '.$lngmenu->lng_wnotelq,
    			'pnr.min' => 'PNR'.' ! '.$lngmenu->lng_wshort,
    			'pnr.max' => 'PNR'.' ! '.$lngmenu->lng_wlong, 
    			'des.required' => $lngmenu->lng_wtext.' ! '.$lngmenu->lng_wnotelq,
    			'des.min' => $lngmenu->lng_wtext.' ! '.$lngmenu->lng_wshort,
    			'des.max' => $lngmenu->lng_wtext.' ! '.$lngmenu->lng_wlong,
    		]);
    	
DB::table('ebtal')->insert([
    ['ebt_email' => $request->email , 'ebt_pnr' => $request->pnr ,  'ebt_desuser' => $request->des ,     'ebt_createdatdate' =>  date('Y-m-d H:i:s') , 'ebt_fromarou' => 3 ,   'ebt_fromid' => Session::get('idajency') ,  'ebt_fromsh' => 1   , 'ebt_flg' => 1 , 'ebt_fromread' => 1 , 'ebt_toread' => 0]
]);



			 $nametr = Session::flash('statust', $lngmenu->lng_wsuccess);
		  	$nametrt = Session::flash('sessurl', 'viewscancellticket');
		  return view('ajency.success', [ 'lngmenus' => $lngmenus , 'lngmenu' => $lngmenu , 'slngmenu' => $slngmenu   ]); }	
else{ return redirect('agency/sign-in'); }    
 }
			
			
			
			
			
			
			
			
				
				
	public function addticket(){
		if (Session::has('signajency')){
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();
$slngmenu=\DB::table('languages') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();	
 return view('ajency.addticket', [  'lngmenus' => $lngmenus , 'lngmenu' => $lngmenu , 'slngmenu' => $slngmenu    ]); }	
else{ return redirect('agency/sign-in'); }
		}



public function addticketPost(Request $request){
		if (Session::has('signajency')){
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first(); 
$slngmenu=\DB::table('languages') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();		
    	
    	$this->validate($request,[
    			'tit' => 'required|min:3|max:99',
    			'des' => 'required|min:5|max:999'
    		],[
    			'tit.required' => $lngmenu->lng_wtit.' ! '.$lngmenu->lng_wnotelq,
    			'tit.min' => $lngmenu->lng_wtit.' ! '.$lngmenu->lng_wshort,
    			'tit.max' => $lngmenu->lng_wtit.' ! '.$lngmenu->lng_wlong,
    			'des.required' => $lngmenu->lng_wtext.' ! '.$lngmenu->lng_wnotelq,
    			'des.min' => $lngmenu->lng_wtext.' ! '.$lngmenu->lng_wshort,
    			'des.max' => $lngmenu->lng_wtext.' ! '.$lngmenu->lng_wlong,
    		]);
    	
DB::table('ticket')->insert([
    ['tik_tit' => $request->tit ,     'tik_createdatdate' =>  date('Y-m-d H:i:s') , 'tik_fromarou' => 3 , 'tik_toarou' => 2 , 'tik_fromid' => Session::get('idajency') ,  'tik_fromsh' => 1 , 'tik_tosh' => 1 , 'tik_active' => 1 , 'tik_fromread' => 1 , 'tik_toread' => 0]
]);

$users = DB::table('ticket')->where('tik_tit', $request->tit)->orderBy('id', 'desc')->first(); 

$idtik= $users->id;   

DB::table('message')->insert([
    ['mes_ticket' => $idtik ,  'mes_des' => $request->des   , 'mes_createdatdate' =>  date('Y-m-d H:i:s') , 'mes_flg' =>  1    ]
]);
			 $nametr = Session::flash('statust', $lngmenu->lng_wsuccess);
		  	$nametrt = Session::flash('sessurl', 'viewstickets');
		  return view('ajency.success', [ 'lngmenus' => $lngmenus , 'lngmenu' => $lngmenu , 'slngmenu' => $slngmenu   ]); }	
else{ return redirect('agency/sign-in'); }    
 }


	public function viewstickets(){
		if (Session::has('signajency')){
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first(); 
$slngmenu=\DB::table('languages') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();		
    	
$admins = \DB::table('ajency') 
->join('ticket', 'ajency.id', '=', 'ticket.tik_fromid') 
->where([
    ['ticket.tik_fromarou', '=', 3],
    ['ticket.tik_toarou', '=', 2],
    ['ticket.tik_fromid', '=', Session::get('idajency')],
    ['ticket.tik_fromsh', '=', 1],])
    ->orderBy('ticket.id', 'desc')->get();


$tickread = DB::table('ajency') 
->join('ticket', 'ajency.id', '=', 'ticket.tik_fromid')->where([
    ['ticket.tik_fromarou', '=', 3],
    ['ticket.tik_toarou', '=', 2],
    ['ticket.tik_fromid', '=', Session::get('idajency')],
    ['ticket.tik_fromsh', '=', 1],
    ['ticket.tik_fromread', '=', 0],])
    ->orderBy('ticket.id', 'desc')->count();
 
	Session::set('tickreadajency', $tickread);   
    
    
return view('ajency.viewstickets', ['admins' => $admins , 'lngmenus' => $lngmenus , 'lngmenu' => $lngmenu , 'slngmenu' => $slngmenu  ]);
}	else{ return redirect('agency/sign-in'); }
}	




		

	public function ticketajency($id){
if (Session::has('signajency')){ 
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first(); 
$slngmenu=\DB::table('languages') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();	
	Session::put('idimg', $id);
$tickets = \DB::table('ajency') 
->join('ticket', 'ajency.id', '=', 'ticket.tik_fromid')->where([
    ['ticket.id', '=', $id],
    ['tik_fromarou', '=', 3],
    ['tik_toarou', '=', 2],
    ['tik_fromid', '=', Session::get('idajency')],
    ['tik_fromsh', '=', 1],])  ->orderBy('ticket.id', 'desc')->get();
$messages = \DB::table('message')->where('mes_ticket', '=', $id)  ->orderBy('id')->get();

$updatee = \DB::table('ajency') 
->join('ticket', 'ajency.id', '=', 'ticket.tik_fromid')->where([
    ['ticket.id', '=', $id],
    ['tik_fromarou', '=', 3],
    ['tik_toarou', '=', 2],
    ['tik_fromid', '=', Session::get('idajency')],
    ['tik_fromsh', '=', 1],])  ->update(['tik_fromread' => 1   ]); 
    
    $tickread = DB::table('ajency') 
->join('ticket', 'ajency.id', '=', 'ticket.tik_fromid')->where([
    ['tik_fromarou', '=', 3],
    ['tik_toarou', '=', 2],
    ['tik_fromid', '=', Session::get('idajency')],
    ['tik_fromsh', '=', 1],
    ['tik_fromread', '=', 0],])
    ->orderBy('ticket.id', 'desc')->count(); 
    Session::set('tickreadajency', $tickread);
 
return view('ajency.ticket', ['tickets' => $tickets , 'messages' => $messages  ,  'lngmenus' => $lngmenus , 'lngmenu' => $lngmenu , 'slngmenu' => $slngmenu  ]); }	
else{ return redirect('agency/sign-in'); }
				}
	
	
		
	public function ticketPost($id  , Request $request ){
if (Session::has('signajency')){ 
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();
 $slngmenu=\DB::table('languages') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();	
$this->validate($request,[
    			'des' => 'required|min:2|max:666',
    		],[
    			'des.required' => $lngmenu->lng_wtext.' ! '.$lngmenu->lng_wnotelq,
    			'des.min' => $lngmenu->lng_wtext.' ! '.$lngmenu->lng_wshort,
    			'des.max' => $lngmenu->lng_wtext.' ! '.$lngmenu->lng_wlong,
    		]);


    
    DB::table('message')->insert([
    ['mes_ticket' => $id ,  'mes_des' => $request->des   , 'mes_createdatdate' =>  date('Y-m-d H:i:s') , 'mes_flg' =>  1    ]
]);

 $updatee = \DB::table('ajency') 
->join('ticket', 'ajency.id', '=', 'ticket.tik_fromid')->where([
    ['ticket.id', '=', $id],
    ['tik_fromarou', '=', 3],
    ['tik_toarou', '=', 2],
    ['tik_fromid', '=', Session::get('idajency')],
    ['tik_fromsh', '=', 1],])  ->update(['tik_toread' => 0  , 'tik_active' => 1   ]); 

$nametr = Session::flash('statust', $lngmenu->lng_wsuccess);  
$nametrt = Session::flash('sessurl', 'viewstickets/ticket/'.$id.'');
return view('ajency.success', [ 'lngmenus' => $lngmenus , 'lngmenu' => $lngmenu , 'slngmenu' => $slngmenu   ]);
}	else{ return redirect('agency/sign-in'); }
}
		


	public function deletticket($id){
if (Session::has('signajency')){ 
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();
$slngmenu=\DB::table('languages') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();	 	
 $updatee = \DB::table('ajency') 
->join('ticket', 'ajency.id', '=', 'ticket.tik_fromid')->where([
    ['ticket.id', '=', $id],
    ['tik_fromarou', '=', 3],
    ['tik_toarou', '=', 2],
    ['tik_fromid', '=', Session::get('idajency')],
    ['tik_fromsh', '=', 1],])  ->update(['tik_fromsh' => 0   ]); 

$nametr = Session::flash('statust', $lngmenu->lng_wsuccess); 
$nametrt = Session::flash('sessurl', 'viewstickets');
return view('ajency.success', [ 'lngmenus' => $lngmenus , 'lngmenu' => $lngmenu , 'slngmenu' => $slngmenu    ]);

 }	else{ return redirect('agency/sign-in'); }
				}
	



	public function viewselanatsajency(){
if (Session::has('signajency')){ 
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first(); 
$admins = \DB::table('ajency') 
->join('ticket', 'ajency.id', '=', 'ticket.tik_toid') 
->where([
    ['ticket.tik_fromarou', '=', 1],
    ['ticket.tik_toarou', '=', 3],
    ['ticket.tik_toid', '=', Session::get('idajency')],
    ['ticket.tik_tosh', '=', 1],])
    ->orderBy('ticket.id', 'desc')->get();


$elanread = DB::table('ajency') 
->join('ticket', 'ajency.id', '=', 'ticket.tik_toid')->where([
    ['ticket.tik_fromarou', '=', 1],
    ['ticket.tik_toarou', '=', 3],
    ['ticket.tik_toid', '=', Session::get('idajency')],
    ['ticket.tik_tosh', '=', 1],
    ['ticket.tik_toread', '=', 0],])
    ->orderBy('ticket.id', 'desc')->count();
 
	Session::set('elanreadajency', $elanread);   
    
    
return view('ajency.viewselanats', ['admins' => $admins , 'lngmenus' => $lngmenus , 'lngmenu' => $lngmenu]);
 }	else{ return redirect('agency/sign-in'); }
}	



	public function elanatajency($id){
if (Session::has('signajency')){ 
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first(); 
	Session::put('idimg', $id);
$tickets = \DB::table('ajency') 
->join('ticket', 'ajency.id', '=', 'ticket.tik_toid')->where([
    ['ticket.id', '=', $id],
    ['tik_fromarou', '=', 1],
    ['tik_toarou', '=', 3],
    ['tik_toid', '=', Session::get('idajency')],
    ['tik_tosh', '=', 1],])  ->orderBy('ticket.id', 'desc')->get();
$messages = \DB::table('message')->where('mes_ticket', '=', $id)  ->orderBy('id')->get();

$updatee = \DB::table('ajency') 
->join('ticket', 'ajency.id', '=', 'ticket.tik_toid')->where([
    ['ticket.id', '=', $id],
    ['tik_fromarou', '=', 1],
    ['tik_toarou', '=', 3],
    ['tik_toid', '=', Session::get('idajency')],
    ['tik_tosh', '=', 1],])  ->update(['tik_toread' => 1 , 'tik_active' => 2   ]); 
    
$elanread = DB::table('ajency') 
->join('ticket', 'ajency.id', '=', 'ticket.tik_toid')->where([
    ['ticket.tik_fromarou', '=', 1],
    ['ticket.tik_toarou', '=', 3],
    ['ticket.tik_toid', '=', Session::get('idajency')],
    ['ticket.tik_tosh', '=', 1],
    ['ticket.tik_toread', '=', 0],])
    ->orderBy('ticket.id', 'desc')->count();
 
	Session::set('elanreadajency', $elanread); 
 
return view('ajency.elanat', ['tickets' => $tickets , 'messages' => $messages  , 'lngmenus' => $lngmenus , 'lngmenu' => $lngmenu]); 
 }	else{ return redirect('agency/sign-in'); }
				}









	public function viewscancellticket(){
		if (Session::has('signajency')){
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first(); 
$slngmenu=\DB::table('languages') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();		
    	
$admins = \DB::table('ajency') 
->join('ebtal', 'ajency.id', '=', 'ebtal.ebt_fromid') 
->where([
    ['ebtal.ebt_fromarou', '=', 3], 
    ['ebtal.ebt_fromid', '=', Session::get('idajency')],
    ['ebtal.ebt_fromsh', '=', 1],])
    ->orderBy('ebtal.id', 'desc')->get();


$tickread = DB::table('ajency') 
->join('ebtal', 'ajency.id', '=', 'ebtal.ebt_fromid')->where([
    ['ebtal.ebt_fromarou', '=', 3],
    ['ebtal.ebt_fromid', '=', Session::get('idajency')],
    ['ebtal.ebt_fromsh', '=', 1],
    ['ebtal.ebt_fromread', '=', 0],])
    ->orderBy('ebtal.id', 'desc')->count();
 
	Session::set('tickcancellreadajency', $tickread);   
    
    
return view('ajency.viewscancellticket', ['admins' => $admins , 'lngmenus' => $lngmenus , 'lngmenu' => $lngmenu , 'slngmenu' => $slngmenu  ]);
}	else{ return redirect('agency/sign-in'); }
}	




		

	public function ticketcancelajency($id){
if (Session::has('signajency')){ 
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first(); 
$slngmenu=\DB::table('languages') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();	
 
$tickets = \DB::table('ajency') 
->join('ebtal', 'ajency.id', '=', 'ebtal.ebt_fromid')->where([
    ['ebtal.id', '=', $id],
    ['ebt_fromarou', '=', 3], 
    ['ebt_fromid', '=', Session::get('idajency')],
    ['ebt_fromsh', '=', 1],])  ->orderBy('ebtal.id', 'desc')->get();

foreach ($tickets as $ticket) {
$email=$ticket->ebt_email;
$pnr=$ticket->ebt_pnr;	
}

    
$messages = \DB::table('message')->where('mes_ticket', '=', $id)  ->orderBy('id')->get();

$updatee = \DB::table('ajency') 
->join('ebtal', 'ajency.id', '=', 'ebtal.ebt_fromid')->where([
    ['ebtal.id', '=', $id],
    ['ebt_fromarou', '=', 3], 
    ['ebt_fromid', '=', Session::get('idajency')],
    ['ebt_fromsh', '=', 1],])  ->update(['ebt_fromread' => 1   ]); 
    
    $tickread = DB::table('ajency') 
->join('ebtal', 'ajency.id', '=', 'ebtal.ebt_fromid')->where([
    ['ebt_fromarou', '=', 3], 
    ['ebt_fromid', '=', Session::get('idajency')],
    ['ebt_fromsh', '=', 1],
    ['ebt_fromread', '=', 0],])
    ->orderBy('ebtal.id', 'desc')->count(); 
    Session::set('tickcancellreadajency', $tickread);



 $belits=  \DB::table('belits')->where([['bel_email', '=',  $email ],['bel_pnr', '=',  $pnr],])->orderBy('bel_id', 'desc')->first();  
 $counts=  \DB::table('belits')->where([['bel_email', '=',  $email ],['bel_pnr', '=',  $pnr],])->orderBy('bel_id', 'desc')->count();   
 


 if($counts=='1'){

 $mergey=$belits->bel_mergey; 
 
 $wents=  \DB::table('belits')
->join('direction', 'belits.bel_id', '=', 'direction.dir_idbelit') ->where([['bel_mergey', '=',  $mergey],['dir_dir', '=',  '0'],['bel_email', '=',  $email ],['bel_pnr', '=',  $pnr],])->orderBy('id')->get(); 



 $backc=  \DB::table('belits')
->join('direction', 'belits.bel_id', '=', 'direction.dir_idbelit') ->where([['bel_mergey', '=',  $mergey],['dir_dir', '=',  '1'],['bel_email', '=',  $email ],['bel_pnr', '=',  $pnr],])->orderBy('id')->count(); 

 $backs=  \DB::table('belits')
->join('direction', 'belits.bel_id', '=', 'direction.dir_idbelit') ->where([['bel_mergey', '=',  $mergey],['dir_dir', '=',  '1'],['bel_email', '=',  $email ],['bel_pnr', '=',  $pnr],])->orderBy('id')->get(); 


 $passangers=  \DB::table('belits')
->join('passanger', 'belits.bel_id', '=', 'passanger.pas_idbelit') ->where([['bel_mergey', '=',  $mergey],['bel_email', '=',  $email ],['bel_pnr', '=',  $pnr],])->orderBy('bel_id')->get(); 
 
 
$belits=\DB::table('belits') ->where([['bel_mergey', '=',  $mergey],['bel_email', '=',  $email ],['bel_pnr', '=',  $pnr],])->orderBy('bel_id', 'desc')->first();  
    
$resulttd=\DB::table('rulls') ->where([['rul_wbsid', '=',  '694'],])->orderBy('id', 'desc')->first();  

$resultt=$resulttd->rul_rul;    
    
    
 
return view('ajency.ticketcancel', ['tickets' => $tickets , 'messages' => $messages  ,  'lngmenus' => $lngmenus , 'lngmenu' => $lngmenu , 'slngmenu' => $slngmenu  , 'counts' => $counts  ,   'wents' => $wents  , 'passangers' => $passangers , 'belits' => $belits  , 'backs' => $backs  , 'backc' => $backc , 'ruuls' => $resultt   ]);

 	
 }else{
return view('ajency.ticketcancel', ['tickets' => $tickets , 'messages' => $messages  ,  'lngmenus' => $lngmenus , 'lngmenu' => $lngmenu , 'slngmenu' => $slngmenu  , 'counts' => $counts  ,  'belits' => $belits    ]);	
}




 }	
else{ return redirect('agency/sign-in'); }
				}
	
	









	
	public function rezervbelitajency(){
	if (Session::has('signajency')){ 
		if (Session::get('activeajency')==1){ 
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first(); 
$citys= \DB::table('city') ->where([['id', '<>',  '0'],['cit_active', '=',  '1'],])->orderBy('cit_name')->get();
$currencys=\DB::table('currency') ->where([['id', '<>',  '0'],['cur_active', '=',  '1'],])->orderBy('cur_nem')->get();

$admins = \DB::table('belitsearch')->where([['id', '<>',  '0'],['bls_active', '=',  '0'],['bls_origin', '=',  Session::get('origin')],['bls_desti', '=',  Session::get('desti')] ,['bls_datefly', '=',  Session::get('datefly')] ,])->orderBy('id', 'desc')->get();

 return view('ajency.rezervbelit' , ['lngmenus' => $lngmenus , 'lngmenu' => $lngmenu, 'citys' => $citys , 'currencys' => $currencys   , 'admins' => $admins     ]);
}	else if (Session::get('activeajency')==0){    return redirect('agency/activition'); }
else if (empty(Session::has('signajency'))){   return redirect('agency/sign-in'); } }
}		






public function rezervbelitajencysearch(Request $request){
	if (Session::has('signajency')){ 
		if (Session::get('activeajency')==1){ 
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();   	    

 if($request->origin == $request->desti ){
$nrepeatl = Session::flash('repeat', '2');
return redirect('agency/rezervbelit'); } 


    			 $this->validate($request,[
    			'origin' => 'required',
    			'desti' => 'required',
    			'datepicker' => 'required',
    		],[
    			'origin.required' => $lngmenu->lng_worigin.' ! '.$lngmenu->lng_wnotelq,
    			'desti.required' => $lngmenu->lng_wdesti.' ! '.$lngmenu->lng_wnotelq,
    			'datepicker.required' => $lngmenu->lng_wdatefly.' ! '.$lngmenu->lng_wnotelq,
    		 ]);  


$nrepeatl = Session::flash('origin', $request->origin);
$nrepeatl = Session::flash('desti', $request->desti);

$date=date('m/d/Y', strtotime($request->datepicker));
$nrepeatl = Session::flash('datefly', $date);  

$nrepeatl = Session::flash('repeat', '3');
return redirect('agency/rezervbelit');
}	else if (Session::get('activeajency')==0){    return redirect('agency/activition'); }
else if (empty(Session::has('signajency'))){   return redirect('agency/sign-in'); } }
}	




	
	public function rezervajency($id){
	if (Session::has('signajency')){ 
		if (Session::get('activeajency')==1){ 
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first(); 
$admins = \DB::table('belit')->where([['id', '<>',  '0'],['bel_bls', '=',  $id], ])->orderBy('id', 'desc')->limit(1)->get();
 return view('ajency.rezerv' , ['lngmenus' => $lngmenus , 'lngmenu' => $lngmenu, 'admins' => $admins     ]);
}	else if (Session::get('activeajency')==0){    return redirect('agency/activition'); }
else if (empty(Session::has('signajency'))){   return redirect('agency/sign-in'); } }
}	




	
	public function rezervajencypost($id , Request $request){
	if (Session::has('signajency')){ 
		if (Session::get('activeajency')==1){ 
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first(); 

    			 $this->validate($request,[
    			'numberbelit' => 'required|numeric',
    		],[
    			'numberbelit.required' => $lngmenu->lng_wnumberbelit.' ! '.$lngmenu->lng_wnotelq,
    			'numberbelit.numeric' => $lngmenu->lng_wnumberbelit.' ! '.$lngmenu->lng_wnotelq,
    		 ]);  
$numberbelit = $request->numberbelit ;  
$count = \DB::table('belit')->where([['bel_bls', '=',  $id],['bel_status', '=',  '0'],])->orderBy('id')->count();
$first = \DB::table('belit')->where([['bel_bls', '=',  $id],['bel_status', '=',  '0'],])->orderBy('id')->first();
$firstid=$first->id;
$sum=$request->numberbelit*($first->bel_rateajency+$first->bel_cost);

 if(($numberbelit > $count)||($numberbelit=='0') ){
$nrepeatl = Session::flash('repeat', '1');
return redirect('agency/rezervbelit/'.$id.'/rezerv'); }  		 


   $rnd=rand(1, 999999999);  
   
    DB::table('belitrezerv')->insert([
    [ 'blr_codrezerv' => $rnd , 'blr_number' => $request->numberbelit , 'blr_sum' => $sum , 'blr_codbelit' => $first->bel_bls , 'blr_arou' => '3'  , 'blr_from' =>  Session::get('idajency')  , 'blr_status' => '1'    ]
]);   

$i=0;
while($i < $request->numberbelit ){

$updatee = \DB::table('belit')
->where([['belit.bel_bls', '=', $id],['belit.id', '=', $firstid+$i ],['belit.bel_status', '=', '0'], ])  ->
 update(['bel_status' => 1 ,'bel_arou' => 3 ,  'bel_idajency' =>  Session::get('idajency') ,  'bel_codrezerv' =>  $rnd , 'bel_daterezerv' => date('Y-m-d H:i:s')   ]);     
 $i++;	    
    }


   $finicalnumber=rand(1, 999999999);
   
    DB::table('finicals')->insert([
    [ 'finical_codrezerv' => $rnd , 'finical_number' => $finicalnumber , 'finical_pay' => $sum  , 'finical_arou' => '3'  ,  'finical_inc' => '4'  ,  'finical_payment' => '0'  , 'finical_iduser' =>  Session::get('idajency') , 'finical_createdatdate' =>  date('Y-m-d H:i:s')    ]
]);   

    
 
$countp = \DB::table('belit')->where([['bel_bls', '=',  $id],['bel_status', '=',  '0'],])->orderBy('id')->count();   
if($countp==0){
$updatee = \DB::table('belitsearch')
->where([['belitsearch.bls_codbelit', '=', $id],['belitsearch.bls_active', '=', '0'], ])  ->
 update(['belitsearch.bls_active' => 1  , 'belitsearch.bls_remain' => $countp   ]);  	
}
elseif($countp!=0){ 
$updatee = \DB::table('belitsearch')
->where([['belitsearch.bls_codbelit', '=', $id],['belitsearch.bls_active', '=', '0'], ])  ->
 update(['belitsearch.bls_active' => 0  , 'belitsearch.bls_remain' => $countp   ]);
}

$nametr = Session::flash('statust',  $lngmenu->lng_wsuccess);
$nametrt = Session::flash('sessurl', 'viewsmybelit');
return view('ajency.success', [ 'lngmenus' => $lngmenus , 'lngmenu' => $lngmenu ]);
 
}	else if (Session::get('activeajency')==0){    return redirect('agency/activition'); }
else if (empty(Session::has('signajency'))){   return redirect('agency/sign-in'); } }
}	




	public function viewsmybelitajency(){
	if (Session::has('signajency')){ 
		if (Session::get('activeajency')==1){ 
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first(); 
$admins = \DB::table('belitrezerv')
->join('belitsearch', 'belitrezerv.blr_codbelit', '=', 'belitsearch.bls_codbelit')
->join('ajency', 'belitrezerv.blr_from', '=', 'ajency.id')
->where([['belitrezerv.id', '<>',  '0'], ['belitrezerv.blr_arou', '=',  '3'], ['belitrezerv.blr_from', '=',  Session::get('idajency')],  ])->orderBy('belitrezerv.id', 'desc')->get();
 return view('ajency.viewsmybelit' , ['lngmenus' => $lngmenus , 'lngmenu' => $lngmenu, 'admins' => $admins     ]);
}	else if (Session::get('activeajency')==0){    return redirect('agency/activition'); }
else if (empty(Session::has('signajency'))){   return redirect('agency/sign-in'); } }
}	
	


	
	public function mybelitajency($id){
	if (Session::has('signajency')){ 
		if (Session::get('activeajency')==1){ 
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();
 
$admins = \DB::table('belitrezerv')
->join('belit', 'belitrezerv.blr_codrezerv', '=', 'belit.bel_codrezerv')
->join('ajency', 'belitrezerv.blr_from', '=', 'ajency.id')
->where([['belitrezerv.id', '<>',  '0'], ['belitrezerv.blr_status', '=',  '2'], ['belitrezerv.blr_arou', '=',  '3'], ['belit.bel_codrezerv', '=',  $id], ['belitrezerv.blr_arou', '=',  '3'] , ['belitrezerv.blr_from', '=',  Session::get('idajency')],  ])->orderBy('belitrezerv.id', 'desc')->limit(1)->get();

 
 return view('ajency.mybelit' , ['lngmenus' => $lngmenus , 'lngmenu' => $lngmenu, 'admins' => $admins     ]);
}	else if (Session::get('activeajency')==0){    return redirect('agency/activition'); }
else if (empty(Session::has('signajency'))){   return redirect('agency/sign-in'); } }
}	
	


	public function mybelitajencyprint($id){
	if (Session::has('signajency')){ 
		if (Session::get('activeajency')==1){ 
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();
 
$admins = \DB::table('belitrezerv')
->join('belit', 'belitrezerv.blr_codrezerv', '=', 'belit.bel_codrezerv')
->join('ajency', 'belitrezerv.blr_from', '=', 'ajency.id')
->where([['belitrezerv.id', '<>',  '0'], ['belitrezerv.blr_status', '=',  '2'], ['belitrezerv.blr_arou', '=',  '3'], ['belit.bel_codrezerv', '=',  $id], ['belitrezerv.blr_arou', '=',  '3'] , ['belitrezerv.blr_from', '=',  Session::get('idajency')],  ])->orderBy('belitrezerv.id', 'desc')->limit(1)->get();

 
 return view('ajency.mybelitprint' , ['lngmenus' => $lngmenus , 'lngmenu' => $lngmenu, 'admins' => $admins     ]);
}	else if (Session::get('activeajency')==0){    return redirect('agency/activition'); }
else if (empty(Session::has('signajency'))){   return redirect('agency/sign-in'); } }
}	
	




	
	public function deletmybelitajency($id){
	if (Session::has('signajency')){ 
		if (Session::get('activeajency')==1){ 
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();
 
$belit=\DB::table('belit') ->where([['bel_codrezerv', '=',  $id],['bel_arou', '=',  3],['bel_idajency', '=',  Session::get('idajency')],])->orderBy('id', 'desc')->first(); 

$admins = \DB::table('belit')->where([['bel_codrezerv', '=',  $id],['bel_arou', '=',  3],['bel_idajency', '=',  Session::get('idajency')],])->delete();

$admins = \DB::table('belitrezerv')->where([['blr_codrezerv', '=',  $id],['blr_arou', '=',  3],['blr_from', '=',  Session::get('idajency')],])->delete();

$count=\DB::table('belit') ->where([['bel_bls', '=',  $belit->bel_bls],['bel_status', '=',  '0'],])->orderBy('id', 'desc')->count(); 

$countnumber=\DB::table('belit') ->where([['bel_bls', '=',  $belit->bel_bls] ,])->orderBy('id', 'desc')->count(); 	

if($count==0){
		$admins = \DB::table('belitsearch')->where('bls_codbelit', '=', $belit->bel_bls)->delete(); 	
}	else if($count!=0){
$updatee = \DB::table('belitsearch')
->where([['belitsearch.bls_codbelit', '=', $belit->bel_bls], ])  ->
 update(['belitsearch.bls_remain' => $count  ,  'belitsearch.bls_number' => $countnumber ]);  
}

		  	$nametr = Session::flash('statust',  $lngmenu->lng_wsuccess);
		  	$nametrt = Session::flash('sessurl', 'viewsmybelit');		  	
return view('ajency.success', ['lngmenus' => $lngmenus , 'lngmenu' => $lngmenu ]);
 
}	else if (Session::get('activeajency')==0){    return redirect('agency/activition'); }
else if (empty(Session::has('signajency'))){   return redirect('agency/sign-in'); } }
}	




	public function viewsfinicalajency(){
	if (Session::has('signajency')){ 
		if (Session::get('activeajency')==1){ 
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();
 
$admins = \DB::table('belitrezerv')
->join('belitsearch', 'belitrezerv.blr_codbelit', '=', 'belitsearch.bls_codbelit')
->join('ajency', 'belitrezerv.blr_from', '=', 'ajency.id')
->join('finicals', 'belitrezerv.blr_codrezerv', '=', 'finicals.finical_codrezerv')
->where([['belitrezerv.id', '<>',  '0'],['ajency.id', '=',  Session::get('idajency')], ['belitrezerv.blr_arou', '=',  '3'],  ])->orderBy('finicals.id', 'desc')->get();

 
 return view('ajency.viewsfinical' , ['lngmenus' => $lngmenus , 'lngmenu' => $lngmenu, 'admins' => $admins     ]);
}	else if (Session::get('activeajency')==0){    return redirect('agency/activition'); }
else if (empty(Session::has('signajency'))){   return redirect('agency/sign-in'); } }
}	



	public function finicalajency($id , $num){
	if (Session::has('signajency')){ 
		if (Session::get('activeajency')==1){ 
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();
 
$admins = \DB::table('belitrezerv')
->join('belit', 'belitrezerv.blr_codrezerv', '=', 'belit.bel_codrezerv')
->join('currency', 'belit.bel_cur', '=', 'currency.id')
->join('ajency', 'belitrezerv.blr_from', '=', 'ajency.id')
->join('finicals', 'belitrezerv.blr_codrezerv', '=', 'finicals.finical_codrezerv')
->where([['belitrezerv.id', '<>',  '0'] , ['ajency.id', '=',  Session::get('idajency')], ['belitrezerv.blr_arou', '=',  '3'], ['belit.bel_bls', '=', $id],['belit.bel_codrezerv', '=', $num], ]) ->orderBy('belit.bel_codrezerv', 'desc')->limit(1)->get();
 

$getwaypays=\DB::table('getwaypay')->where('getway_active', '=', 1)   ->orderBy('id' )->get();
 
 return view('ajency.finicalajency' , ['lngmenus' => $lngmenus , 'lngmenu' => $lngmenu , 'admins' => $admins  , 'getwaypays' => $getwaypays     ]);
}	else if (Session::get('activeajency')==0){    return redirect('agency/activition'); }
else if (empty(Session::has('signajency'))){   return redirect('agency/sign-in'); } }
}		




	public function finicalajencypost($id , $num , Request $request){
	if (Session::has('signajency')){ 
		if (Session::get('activeajency')==1){ 
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();
 
  	$this->validate($request,[
    			'name' => 'required',
    		],[
    			'name.required' => $lngmenu->lng_wgetway.' ! '.$lngmenu->lng_wnotelq,
    		]);  


$admins = \DB::table('belitrezerv')
->join('belit', 'belitrezerv.blr_codrezerv', '=', 'belit.bel_codrezerv')
->join('ajency', 'belitrezerv.blr_from', '=', 'ajency.id')
->join('finicals', 'belitrezerv.blr_codrezerv', '=', 'finicals.finical_codrezerv')
->where([['belitrezerv.id', '<>',  '0'] , ['ajency.id', '=',  Session::get('idajency')], ['belitrezerv.blr_arou', '=',  '3'], ['belit.bel_bls', '=', $id],['belit.bel_codrezerv', '=', $num], ]) ->orderBy('belit.bel_codrezerv', 'desc')->limit(1)->first();	

if($request->name == '1' ){
 require_Once(public_path('/../bmt/lib/nusoap.php'));
 include_once(public_path('/../bmt/lib/class.payrequest.php'));	
return redirect('bmt/epayo.php?id='.$admins->finical_codrezerv.'');
}

else if($request->name == '2' ){
return redirect('zarinpal/epayo.php?id='.$admins->finical_number.'');
}		
 
}	else if (Session::get('activeajency')==0){    return redirect('agency/activition'); }
else if (empty(Session::has('signajency'))){   return redirect('agency/sign-in'); } }
}		




			 
  	public function errorajencyfin(){
	if (Session::has('signajency')){ 
		if (Session::get('activeajency')==1){ 
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();
 
$nametr = Session::flash('statust',  $lngmenu->lng_wfactornotelq);
$nametrt = Session::flash('sessurl', 'viewsfinical');	
return view('ajency.error', ['lngmenus' => $lngmenus , 'lngmenu' => $lngmenu  ]);

}	else if (Session::get('activeajency')==0){    return redirect('agency/activition'); }
else if (empty(Session::has('signajency'))){   return redirect('agency/sign-in'); } }
}		

		


		
	public function registeragency(Request $request){	
Session::set('idlang', '3'); 
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();
  
DB::table('statics')->insert([
    ['static_ip' => $request->ip() , 'static_previous' => url()->previous() ,  'static_url' => $request->url() ,    'static_name' => $lngmenu->lng_wregag ,   'static_createdatdate' =>  date('Y-m-d H:i:s') ]
]);

 return view('ajency.addajency' , ['lngmenus' => $lngmenus , 'lngmenu' => $lngmenu    ]);
 
				}






public function registeragencyPost(Request $request)
    { 	
 $lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();
  	
    	$this->validate($request,[
    			'username' => 'required|min:5|max:35|unique:ajency,ajency_username,$request->username',
    			'userpassword' => 'required|min:5|max:35|confirmed'
    		],[
    			'username.required' => $lngmenu->lng_wusername.' ! '.$lngmenu->lng_wnotelq,
    			'username.min' => $lngmenu->lng_wusername.' ! '.$lngmenu->lng_wshort,
    			'username.max' => $lngmenu->lng_wusername.' ! '.$lngmenu->lng_wlong,
    			'username.unique' => $lngmenu->lng_welquser,
    			'userpassword.required' =>  $lngmenu->lng_wpassword.' ! '.$lngmenu->lng_wnotelq,
    			'userpassword.min' =>  $lngmenu->lng_wpassword.' ! '.$lngmenu->lng_wshort,
    			'userpassword.max' =>  $lngmenu->lng_wpassword.' ! '.$lngmenu->lng_wlong,
    			'userpassword.confirmed' =>  $lngmenu->lng_wconfpassword,
    		]);
  $img='demowhite.jpg';   		 
$encryptedPassword = \Crypt::encrypt($request->userpassword);
$decryptedPassword = \Crypt::decrypt($encryptedPassword);
		
DB::table('ajency')->insert([
    ['ajency_username' => $request->username , 'ajency_password' => $encryptedPassword ,   'ajency_createdatdate' =>  date('Y-m-d H:i:s') , 'ajency_active' => 0 , 'ajency_img' => $img]
]);

$users = DB::table('ajency')->where('ajency_username', $request->username)->first();
$userscou = DB::table('ajency')->where('ajency_username', $request->username)->count();

$id_db= $users->id; 
$password_db= $users->ajency_password; 




$admins = DB::table('ajency')->where([
    ['ajency_username',  $request->username],
])->first();
if($admins){

$password_db= $admins->ajency_password; 
$decryptedPassword =  Crypt::decrypt($password_db);
$userscou = DB::table('ajency')->where([
    ['ajency_username',  $request->username],
])->count();
$id_db= $admins->id;
$activeadmin= $admins->ajency_active; 
$username_db= $admins->ajency_username; 
$password_db= $admins->ajency_password; 
$username_log = $request->username; 
if(($username_log == $username_db)&&( $decryptedPassword == $request->userpassword)){
	
	Session::set('idajency', $id_db);
	Session::set('signajency', $username_db);
	Session::set('activeajency', $activeadmin);

$adminslp = \DB::table('ajency')->where('id', '=', $id_db)  ->orderBy('id', 'desc')->first();
$logindatepas=$adminslp->ajency_loginatdate;	

$admimg=$adminslp->ajency_img;
if(empty($admimg)){$admimg='user2x.png';}	
	Session::set('logindatepasaj', $logindatepas);
	Session::set('ajimg', $admimg);
	$updatee = \DB::table('ajency')->where('id', '=', Session::get('idajency'))  ->update(['ajency_loginatdate' => date('Y-m-d H:i:s') ,    'ajency_ip' => $request->ip()  ]); 
			return redirect('agency/panel'); 
		} 
 
       
    	
    } 
    	
    }
	





				
				
	public function addexam(){
		if (Session::has('signprofessor')){
					if (Session::get('activeprofessor')==1){ 
 return view('professor.addexam');
} else if (Session::get('activeprofessor')==0){    return redirect('professor/activition'); }
else if (empty(Session::has('signprofessor'))){   return redirect('professor/sign-in'); } }
		}
		
		

public function addexamPost(Request $request){
		if (Session::has('signprofessor')){
					if (Session::get('activeprofessor')==1){    	
    	
    	$this->validate($request,[
    			'tit' => 'required|min:5|max:99',
    			'des' => 'required|min:5|max:999'
    		],[
    			'tit.required' => 'لطفا نام تمرین را وارد نمایید',
    			'tit.min' => 'نام تمرین وارد شده نامعتبر است',
    			'tit.max' => 'نام تمرین وارد شده نامعتبر است',
    			'des.required' => 'لطفا توضیحات مربوط به تمرین را به درستی وارد نمایید',
    			'des.min' => 'متن توضیحات نامعتبر است',
    			'des.max' => 'متن توضیحات نامعتبر است',
    		]);
    	
DB::table('exam')->insert([
    ['exam_tit' => $request->tit ,   'exam_des' => $request->des ,     'exam_createdatdate' =>  date('Y-m-d H:i:s') , 'exam_arou' => 1  , 'exam_professor' => Session::get('idprofessor') ]
]);
 
			 $nametr = Session::flash('statust', 'نام و توضیحات مربوط به تمرین شما با موفقیت ثبت شد.');
		  	$nametrt = Session::flash('sessurl', 'viewsexams');
		  return view('professor.success');
		  
} else if (Session::get('activeprofessor')==0){    return redirect('professor/activition'); }
else if (empty(Session::has('signprofessor'))){   return redirect('professor/sign-in'); } }
 }
 


	public function viewsexams(){
		if (Session::has('signprofessor')){
					if (Session::get('activeprofessor')==1){   
$admins = \DB::table('professors') 
->join('exam', 'professors.id', '=', 'exam.exam_professor') 
->where([
    ['exam.exam_arou', '=', 1],
    ['exam.exam_professor', '=', Session::get('idprofessor')], ])
    ->orderBy('exam.id', 'desc')->get();

 
return view('professor.viewsexams', ['admins' => $admins]);
} else if (Session::get('activeprofessor')==0){    return redirect('professor/activition'); }
else if (empty(Session::has('signprofessor'))){   return redirect('professor/sign-in'); } }
}	





	public function editexam($id){
	if (Session::has('signprofessor')){ 
		if (Session::get('activeprofessor')==1){  
	
 $exams= \DB::table('professors') 
->join('exam', 'professors.id', '=', 'exam.exam_professor') 
->where([
    ['exam.id', '=', $id],
    ['exam.exam_arou', '=', 1],
    ['exam.exam_professor', '=', Session::get('idprofessor')], ])
    ->orderBy('exam.id', 'desc')->get();
    
 $examtests= \DB::table('examtest') 
->join('exam', 'examtest.examtest_idexam', '=', 'exam.id') 
->join('students', 'examtest.examtest_idstudent', '=', 'students.id') 
->where([
    ['exam.id', '=', $id],
    ['exam.exam_arou', '=', 1],
    ['exam.exam_professor', '=', Session::get('idprofessor')], ])
    ->orderBy('exam.id', 'desc')->get();
 
 $tests= \DB::table('exam') 
->join('test', 'exam.id', '=', 'test.test_exam') 
->where([
    ['exam.id', '=', $id],
    ['exam.exam_arou', '=', 1],
    ['exam.exam_professor', '=', Session::get('idprofessor')], ])
    ->orderBy('test.id')->get();
 
 $count= \DB::table('exam') 
->join('test', 'exam.id', '=', 'test.test_exam') 
->where([
    ['exam.id', '=', $id],
    ['exam.exam_arou', '=', 1],
    ['exam.exam_professor', '=', Session::get('idprofessor')], ])
    ->orderBy('test.id', 'desc')->count();
    
return view('professor.editexam', ['exams' => $exams , 'tests' => $tests   , 'count' => $count  , 'examtests' => $examtests    ]); 	

}	else if (Session::get('activeprofessor')==0){    return redirect('professor/activition'); }
else if (empty(Session::has('signprofessor'))){   return redirect('professor/sign-in'); } }
}


public function editexamPost($id , Request $request){
		if (Session::has('signprofessor')){
					if (Session::get('activeprofessor')==1){    	
    	
    	$this->validate($request,[
    			'qst' => 'required|min:4|max:999',
    			'repa' => 'required|min:1|max:222',
    			'repb' => 'required|min:1|max:222',
    			'repc' => 'required|min:1|max:222',
    			'repd' => 'required|min:1|max:222',
    			'key' => 'required'
    		],[
    			'qst.required' => 'لطفا سوال را وارد نمایید',
    			'qst.min' => 'لطفا سوال را به درستی وارد نمایید',
    			'qst.max' => 'لطفا سوال را به درستی وارد نمایید',
    			'repa.required' => 'لطفا تست a را وارد نمایید',
    			'repa.min' => 'تست a کوتاه است',
    			'repa.max' => 'تست a طولانی است',
    			'repb.required' => 'لطفا تست b را وارد نمایید',
    			'repb.min' => 'تست b کوتاه است',
    			'repb.max' => 'تست b طولانی است',
    			'repc.required' => 'لطفا تست c را وارد نمایید',
    			'repc.min' => 'تست c کوتاه است',
    			'repc.max' => 'تست c طولانی است',
    			'repd.required' => 'لطفا تست d را وارد نمایید',
    			'repd.min' => 'تست d کوتاه است',
    			'repd.max' => 'تست d طولانی است',
    			'key.required' => 'علامت زدن کلید سوال اجباری است',
    		]);
    	
DB::table('test')->insert([
    ['test_qst' => $request->qst ,   'test_repa' => $request->repa ,   'test_repb' => $request->repb ,   'test_repc' => $request->repc ,   'test_repd' => $request->repd ,   'test_key' => $request->key ,   'test_exam' =>  $id  ]
]);
 
			 $nametr = Session::flash('statust', 'سوال با موفقیت به تمرین اضافه شد.');
		  	$nametrt = Session::flash('sessurl', 'viewsexams/exam/'.$id.'');
		  return view('professor.success');
		  
} else if (Session::get('activeprofessor')==0){    return redirect('professor/activition'); }
else if (empty(Session::has('signprofessor'))){   return redirect('professor/sign-in'); } }
 }
 

public function deletexam($id , Request $request){
		if (Session::has('signprofessor')){
					if (Session::get('activeprofessor')==1){    	
    	
$admins = \DB::table('test')->where([
    ['test.test_exam', '=', $id],])
    ->delete();
    
$admins = \DB::table('exam')->where([
    ['exam.id', '=', $id],
    ['exam.exam_arou', '=', 1],
    ['exam.exam_professor', '=', Session::get('idprofessor')], ])
    ->delete();
    
    
			 $nametr = Session::flash('statust', 'تمرین با موفقیت حذف شد.');
		  	$nametrt = Session::flash('sessurl', 'viewsexams');
		  return view('professor.success');
    

} else if (Session::get('activeprofessor')==0){    return redirect('professor/activition'); }
else if (empty(Session::has('signprofessor'))){   return redirect('professor/sign-in'); } }
}
	
	
	
					
public function delettest($id , Request $request){
		if (Session::has('signprofessor')){
					if (Session::get('activeprofessor')==1){    	
    	

 $testsf= \DB::table('test') 
->join('exam', 'test.test_exam', '=', 'exam.id') 
->where([
    ['test.id', '=', $id],
    ['exam.exam_arou', '=', 1],
    ['exam.exam_professor', '=', Session::get('idprofessor')], ])
    ->orderBy('test.id')->first();  
    
  $admins = \DB::table('test')->where([
    ['test.id', '=', $id],])
    ->delete();
    
$nametr = Session::flash('statust', 'سوال از تمرین مربوطه با موفقیت حذف شد.');
$nametrt = Session::flash('sessurl', 'viewsexams/exam/'.$testsf->id.'');
return view('professor.success');
    
    

} else if (Session::get('activeprofessor')==0){    return redirect('professor/activition'); }
else if (empty(Session::has('signprofessor'))){   return redirect('professor/sign-in'); } }
}
	


				
				
	public function addquiz(){
		if (Session::has('signprofessor')){
					if (Session::get('activeprofessor')==1){ 
 return view('professor.addquiz');
} else if (Session::get('activeprofessor')==0){    return redirect('professor/activition'); }
else if (empty(Session::has('signprofessor'))){   return redirect('professor/sign-in'); } }
		}
		
			


public function addquizPost(Request $request){
		if (Session::has('signprofessor')){
					if (Session::get('activeprofessor')==1){    	
    	
    	$this->validate($request,[
    			'tit' => 'required|min:5|max:99',
    			'des' => 'required|min:5|max:999'
    		],[
    			'tit.required' => 'لطفا نام آزمون را وارد نمایید',
    			'tit.min' => 'نام آزمون وارد شده نامعتبر است',
    			'tit.max' => 'نام آزمون وارد شده نامعتبر است',
    			'des.required' => 'لطفا توضیحات مربوط به آزمون را به درستی وارد نمایید',
    			'des.min' => 'متن توضیحات نامعتبر است',
    			'des.max' => 'متن توضیحات نامعتبر است',
    		]);
    	
DB::table('exam')->insert([
    ['exam_tit' => $request->tit ,   'exam_des' => $request->des ,     'exam_createdatdate' =>  date('Y-m-d H:i:s') , 'exam_arou' => 2  , 'exam_professor' => Session::get('idprofessor') ]
]);
 
			 $nametr = Session::flash('statust', 'نام و توضیحات مربوط به آزمون شما با موفقیت ثبت شد.');
		  	$nametrt = Session::flash('sessurl', 'viewsquiz');
		  return view('professor.success');
		  
} else if (Session::get('activeprofessor')==0){    return redirect('professor/activition'); }
else if (empty(Session::has('signprofessor'))){   return redirect('professor/sign-in'); } }
 }
 



	public function viewsquiz(){
		if (Session::has('signprofessor')){
					if (Session::get('activeprofessor')==1){   
$admins = \DB::table('professors') 
->join('exam', 'professors.id', '=', 'exam.exam_professor') 
->where([
    ['exam.exam_arou', '=', 2],
    ['exam.exam_professor', '=', Session::get('idprofessor')], ])
    ->orderBy('exam.id', 'desc')->get();

 
return view('professor.viewsquiz', ['admins' => $admins]);
} else if (Session::get('activeprofessor')==0){    return redirect('professor/activition'); }
else if (empty(Session::has('signprofessor'))){   return redirect('professor/sign-in'); } }
}	





public function deletquiz($id , Request $request){
		if (Session::has('signprofessor')){
					if (Session::get('activeprofessor')==1){    	
    	
$admins = \DB::table('test')->where([
    ['test.test_exam', '=', $id],])
    ->delete();
    
$admins = \DB::table('exam')->where([
    ['exam.id', '=', $id],
    ['exam.exam_arou', '=', 2],
    ['exam.exam_professor', '=', Session::get('idprofessor')], ])
    ->delete();
    
    
			 $nametr = Session::flash('statust', ' آزمون با موفقیت حذف شد.');
		  	$nametrt = Session::flash('sessurl', 'viewsquiz');
		  return view('professor.success');
    

} else if (Session::get('activeprofessor')==0){    return redirect('professor/activition'); }
else if (empty(Session::has('signprofessor'))){   return redirect('professor/sign-in'); } }
}
	







	public function editquiz($id){
	if (Session::has('signprofessor')){ 
		if (Session::get('activeprofessor')==1){  
	
 $exams= \DB::table('professors') 
->join('exam', 'professors.id', '=', 'exam.exam_professor') 
->where([
    ['exam.id', '=', $id],
    ['exam.exam_arou', '=', 2],
    ['exam.exam_professor', '=', Session::get('idprofessor')], ])
    ->orderBy('exam.id', 'desc')->get();
 
 $tests= \DB::table('exam') 
->join('test', 'exam.id', '=', 'test.test_exam') 
->where([
    ['exam.id', '=', $id],
    ['exam.exam_arou', '=', 2],
    ['exam.exam_professor', '=', Session::get('idprofessor')], ])
    ->orderBy('test.id')->get();
 
 $count= \DB::table('exam') 
->join('test', 'exam.id', '=', 'test.test_exam') 
->where([
    ['exam.id', '=', $id],
    ['exam.exam_arou', '=', 2],
    ['exam.exam_professor', '=', Session::get('idprofessor')], ])
    ->orderBy('test.id', 'desc')->count();

 $examtests= \DB::table('examtest') 
->join('exam', 'examtest.examtest_idexam', '=', 'exam.id') 
->join('students', 'examtest.examtest_idstudent', '=', 'students.id') 
->where([
    ['exam.id', '=', $id],
    ['exam.exam_arou', '=', 2],
    ['exam.exam_professor', '=', Session::get('idprofessor')], ])
    ->orderBy('exam.id', 'desc')->get();
    
return view('professor.editquiz', ['exams' => $exams , 'tests' => $tests   , 'count' => $count , 'examtests' => $examtests    ]); 	

}	else if (Session::get('activeprofessor')==0){    return redirect('professor/activition'); }
else if (empty(Session::has('signprofessor'))){   return redirect('professor/sign-in'); } }
}





public function editquizPost($id , Request $request){
		if (Session::has('signprofessor')){
					if (Session::get('activeprofessor')==1){    	
    	
    	$this->validate($request,[
    			'qst' => 'required|min:4|max:999',
    			'repa' => 'required|min:1|max:222',
    			'repb' => 'required|min:1|max:222',
    			'repc' => 'required|min:1|max:222',
    			'repd' => 'required|min:1|max:222',
    			'key' => 'required'
    		],[
    			'qst.required' => 'لطفا سوال را وارد نمایید',
    			'qst.min' => 'لطفا سوال را به درستی وارد نمایید',
    			'qst.max' => 'لطفا سوال را به درستی وارد نمایید',
    			'repa.required' => 'لطفا تست a را وارد نمایید',
    			'repa.min' => 'تست a کوتاه است',
    			'repa.max' => 'تست a طولانی است',
    			'repb.required' => 'لطفا تست b را وارد نمایید',
    			'repb.min' => 'تست b کوتاه است',
    			'repb.max' => 'تست b طولانی است',
    			'repc.required' => 'لطفا تست c را وارد نمایید',
    			'repc.min' => 'تست c کوتاه است',
    			'repc.max' => 'تست c طولانی است',
    			'repd.required' => 'لطفا تست d را وارد نمایید',
    			'repd.min' => 'تست d کوتاه است',
    			'repd.max' => 'تست d طولانی است',
    			'key.required' => 'علامت زدن کلید سوال اجباری است',
    		]);
    	
DB::table('test')->insert([
    ['test_qst' => $request->qst ,   'test_repa' => $request->repa ,   'test_repb' => $request->repb ,   'test_repc' => $request->repc ,   'test_repd' => $request->repd ,   'test_key' => $request->key ,   'test_exam' =>  $id  ]
]);
 
			 $nametr = Session::flash('statust', 'سوال با موفقیت به آزمون اضافه شد.');
		  	$nametrt = Session::flash('sessurl', 'viewsquiz/quiz/'.$id.'');
		  return view('professor.success');
		  
} else if (Session::get('activeprofessor')==0){    return redirect('professor/activition'); }
else if (empty(Session::has('signprofessor'))){   return redirect('professor/sign-in'); } }
 }
 


	
	
	
					
public function delettestq($id , Request $request){
		if (Session::has('signprofessor')){
					if (Session::get('activeprofessor')==1){    	
    	

 $testsf= \DB::table('test') 
->join('exam', 'test.test_exam', '=', 'exam.id') 
->where([
    ['test.id', '=', $id],
    ['exam.exam_arou', '=', 2],
    ['exam.exam_professor', '=', Session::get('idprofessor')], ])
    ->orderBy('test.id')->first();  
    
  $admins = \DB::table('test')->where([
    ['test.id', '=', $id],])
    ->delete();
    
$nametr = Session::flash('statust', 'سوال از آزمون مربوطه با موفقیت حذف شد.');
$nametrt = Session::flash('sessurl', 'viewsquiz/quiz/'.$testsf->id.'');
return view('professor.success');
    
    

} else if (Session::get('activeprofessor')==0){    return redirect('professor/activition'); }
else if (empty(Session::has('signprofessor'))){   return redirect('professor/sign-in'); } }
}
	




	
public function ajencyloginn(Request $request){
if (Session::has('idlang')){ } else {
$demolang=\DB::table('superadminselanats') ->where([['id', '=',  1],])->orderBy('id', 'desc')->first();		
Session::set('idlang', $demolang->supelan_demolang); }	
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();
	
DB::table('statics')->insert([
    ['static_ip' => $request->ip() ,  'static_url' => $request->url() ,    'static_name' => 'ورود استاد' ,   'static_createdatdate' =>  date('Y-m-d H:i:s') ]
]);

 return view('ajency.sign-inn', ['lngmenus' => $lngmenus , 'lngmenu' => $lngmenu ]); 
 }





	
    public function ajencyloginpostn(Request $request)
    {
  $lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();  	


    	$this->validate($request,[
    			'firstname' => 'required',
    			'lastname' => 'required'
    		],[
    			'firstname.required' => $lngmenu->lng_wusername.' ! '.$lngmenu->lng_wnotelq,
    			'lastname.required' => $lngmenu->lng_wpassword.' ! '.$lngmenu->lng_wnotelq,
    			
    		]);


if($request->firstname=='lang' && $request->lastname=='test'){
 
	Session::set('signajencyy', 'lang');	return redirect('agency/viewslanguage'); 
}

else

{
		return redirect('agency/sign-inn'); 
}



		
		
    }





	public function viewslanguagea(){
if (Session::has('signajencyy')){ 
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();
$slngmenu=\DB::table('languages') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();	 
$admins = \DB::table('language')->where([['id', '<>',  '0'], ]) ->orderBy('id', 'desc')->get();
$demolang=\DB::table('superadminselanats') ->where([['id', '=',  1],])->orderBy('id', 'desc')->first();		
return view('ajency.viewslanguage', ['admins' => $admins ,'demolang' => $demolang , 'lngmenus' => $lngmenus , 'lngmenu' => $lngmenu  , 'slngmenu' => $slngmenu ]);
}	
else{ return redirect('agency/sign-inn'); }
}			





	public function editlanguagea($id){
if (Session::has('signajencyy')){ 
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();	
$admins = \DB::table('language')
->where('id', '=', $id)  ->orderBy('id', 'desc')->get();
	  

return view('ajency.editlanguage', ['admins' => $admins , 'lngmenus' => $lngmenus , 'lngmenu' => $lngmenu ]);
 }	else{ return redirect('agency/sign-inn'); }
}			


	public function mngwordsa($id){
if (Session::has('signajencyy')){ 
	
$admins = \DB::table('language')
->where('id', '=', $id)  ->orderBy('id', 'desc')->get();
$sadmins = \DB::table('languages')
->where('id', '=', $id)  ->orderBy('id', 'desc')->get();
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();	  
$slngmenu=\DB::table('languages') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();	  

return view('ajency.mngwords', ['admins' => $admins ,'sadmins' => $sadmins , 'lngmenus' => $lngmenus , 'lngmenu' => $lngmenu , 'slngmenu' => $slngmenu ]);
 }	else{ return redirect('agency/sign-inn'); }
}





		
	public function mngwordsPosta($id  , Request $request ){

if (Session::has('signajencyy')){ 

$this->validate($request,[
    			'lng_wmnglang' => 'required',
    			'lng_wveiwlang' => 'required',
    			'lng_waddlang' => 'required',
    		],[
    			'lng_wmnglang.required' => 'لطفا مدیریت زبان را وارد نمایید',
    			'lng_wveiwlang.required' => 'لطفا مشاهده زبانها را وارد نمایید',
    			'lng_waddlang.required' => 'لطفا مدیریت زبان را وارد نمایید',
    		]);  
    		
		
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first(); 
$updatee = \DB::table('language')->where('id', '=', $id)  ->update(['lng_wmnglang' => $request->lng_wmnglang  ,  'lng_wveiwlang' => $request->lng_wveiwlang  ,  'lng_waddlang' => $request->lng_waddlang    ,  'lng_wlang' => $request->lng_wlang    ,  'lng_wrtl' => $request->lng_wrtl    ,  'lng_wltr' => $request->lng_wltr    ,  'lng_wsuccess' => $request->lng_wsuccess  ,  'lng_wtsuccess' => $request->lng_wtsuccess  ,  'lng_wback' => $request->lng_wback  ,  'lng_wrow' => $request->lng_wrow  ,  'lng_wdelet' => $request->lng_wdelet  ,  'lng_wobservation' => $request->lng_wobservation  ,  'lng_wstatus' => $request->lng_wstatus  ,  'lng_wactive' => $request->lng_wactive  ,  'lng_winactive' => $request->lng_winactive   ,  'lng_wstyle' => $request->lng_wstyle   ,  'lng_wdemolang' => $request->lng_wdemolang   ,  'lng_wsuperadmin' => $request->lng_wsuperadmin   ,  'lng_wpanel' => $request->lng_wpanel   ,  'lng_wnodate' => $request->lng_wnodate  ,  'lng_wreg' => $request->lng_wreg  ,  'lng_wedit' => $request->lng_wedit  ,  'lng_wspecifi' => $request->lng_wspecifi  ,  'lng_wmanage' => $request->lng_wmanage  ,  'lng_wbrand' => $request->lng_wbrand  ,  'lng_wmbrand' => $request->lng_wmbrand  ,  'lng_wrecentlogin' => $request->lng_wrecentlogin  ,  'lng_wprofile' => $request->lng_wprofile  ,   'lng_wmyprofile' => $request->lng_wmyprofile  ,   'lng_wuserandpas' => $request->lng_wuserandpas  ,   'lng_wip' => $request->lng_wip  ,  'lng_wlogin' => $request->lng_wlogin  ,  'lng_wexit' => $request->lng_wexit  ,  'lng_wadmin' => $request->lng_wadmin  ,  'lng_wadmins' => $request->lng_wadmins  ,  'lng_wveiwadmin' => $request->lng_wveiwadmin  ,  'lng_waddadmin' => $request->lng_waddadmin  ,  'lng_wusername' => $request->lng_wusername  ,  'lng_wpassword' => $request->lng_wpassword   , 'lng_wconfpassword' => $request->lng_wconfpassword   ,  'lng_werror' => $request->lng_werror   ,  'lng_werrornot' => $request->lng_werrornot   ,  'lng_wshort' => $request->lng_wshort   ,  'lng_wlong' => $request->lng_wlong   ,  'lng_wnotelq' => $request->lng_wnotelq   ,  'lng_welquser' => $request->lng_welquser  ,  'lng_welqname' => $request->lng_welqname   ,  'lng_wcreatedatdate' => $request->lng_wcreatedatdate   ,  'lng_waccess' => $request->lng_waccess     ,  'lng_wname' => $request->lng_wname   ,  'lng_wtell' => $request->lng_wtell   ,  'lng_wemail' => $request->lng_wemail   ,  'lng_wadres' => $request->lng_wadres   ,  'lng_wimg' => $request->lng_wimg   ,  'lng_wupload' => $request->lng_wupload   ,  'lng_wuploadclick' => $request->lng_wuploadclick   ,  'lng_welanat' => $request->lng_welanat   ,  'lng_waccadmin' => $request->lng_waccadmin   ,  'lng_wpassadmin' => $request->lng_wpassadmin   ,  'lng_wsms' => $request->lng_wsms  ,  'lng_whi' => $request->lng_whi  ,  'lng_wsucsec' => $request->lng_wsucsec  ,  'lng_wnewpas' => $request->lng_wnewpas  ,  'lng_wactivedon' => $request->lng_wactivedon  ,  'lng_wajencys' => $request->lng_wajencys  , 'lng_wajency' => $request->lng_wajency  ,  'lng_wveiwajency' => $request->lng_wveiwajency  ,  'lng_waddajency' => $request->lng_waddajency   ,  'lng_wuser' => $request->lng_wuser  ,  'lng_wusers' => $request->lng_wusers  ,  'lng_wveiwuser' => $request->lng_wveiwuser  ,  'lng_wadduser' => $request->lng_wadduser   ,  'lng_wnameajency' => $request->lng_wnameajency   ,  'lng_wnameajencymng' => $request->lng_wnameajencymng  ,  'lng_waccajency' => $request->lng_waccajency  ,  'lng_wpassajency' => $request->lng_wpassajency  ,  'lng_waccuser' => $request->lng_waccuser  ,  'lng_wpassuser' => $request->lng_wpassuser    ,  'lng_wajencysgroups' => $request->lng_wajencysgroups    ,  'lng_wveiwajencygroup' => $request->lng_wveiwajencygroup    ,  'lng_wusersgroups' => $request->lng_wusersgroups    ,  'lng_wveiwusergroup' => $request->lng_wveiwusergroup    ,  'lng_wveiwgroup' => $request->lng_wveiwgroup    ,  'lng_waddgroup' => $request->lng_waddgroup    ,  'lng_wnamegroup' => $request->lng_wnamegroup ,  'lng_waddgroupus' => $request->lng_waddgroupus ,  'lng_waddgroupaj' => $request->lng_waddgroupaj ,  'lng_wajencymember' => $request->lng_wajencymember ,  'lng_wusermember' => $request->lng_wusermember , 'lng_wnameuser' =>  $request->lng_wnameuser  ,  'lng_wpanelsms' => $request->lng_wpanelsms ,  'lng_wveiwpanelsms' => $request->lng_wveiwpanelsms ,  'lng_wnamepanelsms' => $request->lng_wnamepanelsms , 'lng_wnumberpanelsms' =>  $request->lng_wnumberpanelsms  ,  'lng_wpages' => $request->lng_wpages ,  'lng_wnews' => $request->lng_wnews ,  'lng_waddpage' => $request->lng_waddpage ,  'lng_waddnew' => $request->lng_waddnew ,  'lng_wveiwpage' => $request->lng_wveiwpage , 'lng_wveiwnew' =>  $request->lng_wveiwnew  ,  'lng_wheader' => $request->lng_wheader ,  'lng_wtit' => $request->lng_wtit ,  'lng_wtext' => $request->lng_wtext , 'lng_wkhtext' =>  $request->lng_wkhtext    ,  'lng_wqstandrep' => $request->lng_wqstandrep ,  'lng_wqst' => $request->lng_wqst , 'lng_wrep' =>  $request->lng_wrep   , 'lng_wactivition' =>  $request->lng_wactivition   , 'lng_wcodeactive' =>  $request->lng_wcodeactive   , 'lng_wmessageactive' =>  $request->lng_wmessageactive   , 'lng_wmyemail' =>  $request->lng_wmyemail   , 'lng_wactiveemail' =>  $request->lng_wactiveemail   , 'lng_wsendverfytoemail' =>  $request->lng_wsendverfytoemail   , 'lng_wactiveemails' =>  $request->lng_wactiveemails   , 'lng_wmytell' =>  $request->lng_wmytell   , 'lng_wactivetell' =>  $request->lng_wactivetell   , 'lng_wsendverfytotell' =>  $request->lng_wsendverfytotell   , 'lng_wactivetells' =>  $request->lng_wactivetells , 'lng_wcodeactiveerror' =>  $request->lng_wcodeactiveerror   , 'lng_wsendverfyemailsuc' =>  $request->lng_wsendverfyemailsuc   , 'lng_wactiveemailsuc' =>  $request->lng_wactiveemailsuc   , 'lng_wsendverfytellsuc' =>  $request->lng_wsendverfytellsuc   , 'lng_wactivetellsuc' =>  $request->lng_wactivetellsuc  , 'lng_waddticket' =>  $request->lng_waddticket  , 'lng_wveiwticket' =>  $request->lng_wveiwticket  , 'lng_wsend' =>  $request->lng_wsend  , 'lng_wtickets' =>  $request->lng_wtickets  , 'lng_wnewmes' =>  $request->lng_wnewmes  , 'lng_wreps' =>  $request->lng_wreps  , 'lng_wwaitreps' =>  $request->lng_wwaitreps  , 'lng_wclose' =>  $request->lng_wclose  , 'lng_wticketnumber' =>  $request->lng_wticketnumber  , 'lng_wticketcreat' =>  $request->lng_wticketcreat  , 'lng_wtypingmes' =>  $request->lng_wtypingmes  , 'lng_wticketajency' =>  $request->lng_wticketajency  , 'lng_wticketuser' =>  $request->lng_wticketuser   , 'lng_wclosen' =>  $request->lng_wclosen  , 'lng_wnotfs' =>  $request->lng_wnotfs  , 'lng_wveiwnotf' =>  $request->lng_wveiwnotf  , 'lng_wrecever' =>  $request->lng_wrecever  , 'lng_wrecevers' =>  $request->lng_wrecevers  , 'lng_waddnotfo' =>  $request->lng_waddnotfo  , 'lng_waddnotfg' =>  $request->lng_waddnotfg  , 'lng_wnotfajency' =>  $request->lng_wnotfajency  , 'lng_wnotfuser' =>  $request->lng_wnotfuser    , 'lng_waddnotfaj' =>  $request->lng_waddnotfaj  , 'lng_waddnotfus' =>  $request->lng_waddnotfus   , 'lng_wnotfnoread' =>  $request->lng_wnotfnoread    , 'lng_wnotfnumber' =>  $request->lng_wnotfnumber  , 'lng_waddcur' =>  $request->lng_waddcur  , 'lng_wrateajency' =>  $request->lng_wrateajency  , 'lng_wrateuser' =>  $request->lng_wrateuser    , 'lng_wveiwcur' =>  $request->lng_wveiwcur  , 'lng_wnem' =>  $request->lng_wnem   , 'lng_wratecur' =>  $request->lng_wratecur    , 'lng_wnamecur' =>  $request->lng_wnamecur    , 'lng_wcur' =>  $request->lng_wcur     , 'lng_wctr' =>  $request->lng_wctr   , 'lng_wctrs' =>  $request->lng_wctrs    , 'lng_wveiwctr' =>  $request->lng_wveiwctr    , 'lng_waddctr' =>  $request->lng_waddctr   , 'lng_wnamectr' =>  $request->lng_wnamectr   , 'lng_wcit' =>  $request->lng_wcit   , 'lng_wcits' =>  $request->lng_wcits    , 'lng_wveiwcit' =>  $request->lng_wveiwcit    , 'lng_waddcit' =>  $request->lng_waddcit   , 'lng_wnamecit' =>  $request->lng_wnamecit   , 'lng_wbelit' =>  $request->lng_wbelit    , 'lng_wbelits' =>  $request->lng_wbelits    , 'lng_wid' =>  $request->lng_wid    , 'lng_wcodrezerv' =>  $request->lng_wcodrezerv    , 'lng_wdemobelit' =>  $request->lng_wdemobelit    , 'lng_wveiwdemobelit' =>  $request->lng_wveiwdemobelit    , 'lng_wcodbelit' =>  $request->lng_wcodbelit    , 'lng_wcosts' =>  $request->lng_wcosts    , 'lng_wbelrate' =>  $request->lng_wbelrate    , 'lng_wnamebelit' =>  $request->lng_wnamebelit    , 'lng_waddbelit' =>  $request->lng_waddbelit    , 'lng_wveiwbelit' =>  $request->lng_wveiwbelit   , 'lng_worigin' =>  $request->lng_worigin   , 'lng_wdesti' =>  $request->lng_wdesti   , 'lng_welqordes' =>  $request->lng_welqordes   , 'lng_wdatefly' =>  $request->lng_wdatefly  , 'lng_whfly' =>  $request->lng_whfly  , 'lng_wbelrateajency' =>  $request->lng_wbelrateajency    , 'lng_wbelrateuser' =>  $request->lng_wbelrateuser   , 'lng_wbelcost' =>  $request->lng_wbelcost  , 'lng_wcostdes' =>  $request->lng_wcostdes   , 'lng_wdes' =>  $request->lng_wdes   , 'lng_wcodfly' =>  $request->lng_wcodfly    , 'lng_wdatebuy' =>  $request->lng_wdatebuy   , 'lng_wdaterezerv' =>  $request->lng_wdaterezerv  , 'lng_wnumberbelit' =>  $request->lng_wnumberbelit  , 'lng_wnumbermember' =>  $request->lng_wnumbermember   , 'lng_wsold' =>  $request->lng_wsold   , 'lng_wrezervd' =>  $request->lng_wrezervd   , 'lng_wpayd' =>  $request->lng_wpayd    , 'lng_wrezervbelit' =>  $request->lng_wrezervbelit    , 'lng_wbuybelit' =>  $request->lng_wbuybelit    , 'lng_wpayment' =>  $request->lng_wpayment  , 'lng_wpaymentcur' =>  $request->lng_wpaymentcur  , 'lng_wpaymentcurforone' =>  $request->lng_wpaymentcurforone  , 'lng_wdosnotbelit' =>  $request->lng_wdosnotbelit   , 'lng_wfactor' =>  $request->lng_wfactor   , 'lng_wfactors' =>  $request->lng_wfactors   , 'lng_wfactornotelq' =>  $request->lng_wfactornotelq   , 'lng_wveiwfactor' =>  $request->lng_wveiwfactor   , 'lng_wnumberfactor' =>  $request->lng_wnumberfactor   , 'lng_wpayfactor' =>  $request->lng_wpayfactor   , 'lng_wpaydone' =>  $request->lng_wpaydone   , 'lng_wpaynot' =>  $request->lng_wpaynot   , 'lng_wusersfactors' =>  $request->lng_wusersfactors   , 'lng_wuserfactor' =>  $request->lng_wuserfactor   , 'lng_wajencyfactor' =>  $request->lng_wajencyfactor   , 'lng_wajencysfactors' =>  $request->lng_wajencysfactors  , 'lng_wajencysbelits' =>  $request->lng_wajencysbelits  , 'lng_wusersbelits' =>  $request->lng_wusersbelits  , 'lng_wgetway' =>  $request->lng_wgetway    , 'lng_wveiwgetway' =>  $request->lng_wveiwgetway    , 'lng_wprint' =>  $request->lng_wprint , 'lng_windexsite' =>  $request->lng_windexsite  , 'lng_wmngindexsite' =>  $request->lng_wmngindexsite  , 'lng_wveiwindexsite' =>  $request->lng_wveiwindexsite   , 'lng_wmngveiw' =>  $request->lng_wmngveiw   , 'lng_wmngsps' =>  $request->lng_wmngsps  , 'lng_wheadersite' =>  $request->lng_wheadersite  , 'lng_wpagesite' =>  $request->lng_wpagesite  , 'lng_wfootersite' =>  $request->lng_wfootersite  , 'lng_wtitsite' =>  $request->lng_wtitsite  , 'lng_wdessite' =>  $request->lng_wdessite  , 'lng_wdesfootersite' =>  $request->lng_wdesfootersite  , 'lng_wlogosite' =>  $request->lng_wlogosite  , 'lng_wregag' =>  $request->lng_wregag  , 'lng_wregus' =>  $request->lng_wregus  , 'lng_wlogag' =>  $request->lng_wlogag  , 'lng_wlogus' =>  $request->lng_wlogus    , 'lng_wlinks' =>  $request->lng_wlinks  , 'lng_whome' =>  $request->lng_whome  , 'lng_wcmbckhome' =>  $request->lng_wcmbckhome   , 'lng_wslide' =>  $request->lng_wslide   , 'lng_wslides' =>  $request->lng_wslides   , 'lng_wmngslide' =>  $request->lng_wmngslide   , 'lng_wveiwslide' =>  $request->lng_wveiwslide   , 'lng_winsslide' =>  $request->lng_winsslide   , 'lng_wbelittraking' =>  $request->lng_wbelittraking     , 'lng_wveiwstaticsite' =>  $request->lng_wveiwstaticsite     , 'lng_wwbs' =>  $request->lng_wwbs   , 'lng_wreqwbs' =>  $request->lng_wreqwbs   , 'lng_wapi' =>  $request->lng_wapi   , 'lng_wcreateapi' =>  $request->lng_wcreateapi   , 'lng_wrahwbs' =>  $request->lng_wrahwbs   , 'lng_wwbsag' =>  $request->lng_wwbsag   , 'lng_wwbsus' =>  $request->lng_wwbsus  ]); 

$updatee = \DB::table('languages')->where('id', '=', $id)  ->update([ 'lng_wnotaccess' => $request->lng_wnotaccess  , 'lng_wcharge' =>  $request->lng_wcharge   , 'lng_wchargeinc' =>  $request->lng_wchargeinc   , 'lng_wchargefin' =>  $request->lng_wchargefin , 'lng_wnamecost' =>  $request->lng_wnamecost , 'lng_wpayy' =>  $request->lng_wpayy  , 'lng_wraterialiran' =>  $request->lng_wraterialiran    , 'lng_wratedollar' =>  $request->lng_wratedollar  , 'lng_wstatic' =>  $request->lng_wstatic      , 'lng_wpageobsersite' =>  $request->lng_wpageobsersite   , 'lng_wlinkpage' =>  $request->lng_wlinkpage   , 'lng_wobserdate' =>  $request->lng_wobserdate   , 'lng_wlistobser' =>  $request->lng_wlistobser   , 'lng_wdeletstatic' =>  $request->lng_wdeletstatic  ,  'lng_wgetways' =>  $request->lng_wgetways   , 'lng_wnamegetway' =>  $request->lng_wnamegetway  , 'lng_wshomaredarkhast' =>  $request->lng_wshomaredarkhast  , 'lng_wshenasepardakht' =>  $request->lng_wshenasepardakht  , 'lng_wcodmarjatarakonesh' =>  $request->lng_wcodmarjatarakonesh      ]);  

$nametr = Session::flash('statust', $lngmenu->lng_wsuccess);
$nametrt = Session::flash('sessurl', 'viewslanguage/editlanguage/'.$id.'/mngwords');
return  view('ajency.successa', ['lngmenus' => $lngmenus , 'lngmenu' => $lngmenu ]);
}		else{ return redirect('agency/sign-inn'); }
}
	




	public function addfinical(){
	if (Session::has('signajency')){ 
		if (Session::get('activeajency')==1){ 
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();
$slngmenu=\DB::table('languages') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();	
 return view('ajency.addfinic', ['lngmenus' => $lngmenus , 'lngmenu' => $lngmenu, 'slngmenu' => $slngmenu ]); 

 
		
 }	else if (Session::get('activeajency')==0){    return redirect('agency/activition'); }
else if (empty(Session::has('signajency'))){   return redirect('agency/sign-in'); } }
}


	public function addfinicalpostaj(  Request $request){
	if (Session::has('signajency')){ 
		if (Session::get('activeajency')==1){ 
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();
$slngmenu=\DB::table('languages') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();	

   	$this->validate($request,[
    			'username' => 'required|numeric' 
    		],[
    			'username.required' => $slngmenu->lng_wcharge.' ! '.$lngmenu->lng_wnotelq,
    			'username.numeric' => $slngmenu->lng_wcharge.' ! '.$lngmenu->lng_wnotelq, 
    		]);
    	

		    	
DB::table('finicals')->insert([
    ['finical_pay' => $request->username , 'finical_inc' => '5' ,     'finical_createdatdate' =>  date('Y-m-d H:i:s') , 'finical_arou' => 3 ,  'finical_iduser' => Session::get('idajency')  ]
]);


$finical=\DB::table('finicals') ->where([['finical_iduser', '=',  Session::get('idajency')],['finical_arou', '=',  '3'],])->orderBy('id', 'desc')->first();	




	    	
DB::table('charge')->insert([
    ['charge_pay' => $request->username ,'charge_finical' => $finical->id ,     'charge_createdatdate' =>  date('Y-m-d H:i:s') , 'charge_arou' => 3 ,  'charge_iduser' => Session::get('idajency')  ]
]);



/*$nametr = Session::flash('statust',  $lngmenu->lng_wsuccess);
$nametrt = Session::flash('sessurl', 'panel');		  	
 return view('superadmin.success', ['lngmenus' => $lngmenus , 'lngmenu' => $lngmenu ]); 
*/

 require_Once(public_path('/../bmt/lib/nusoap.php'));
 include_once(public_path('/../bmt/lib/class.payrequest.php'));	
return redirect('bmt/epayaj.php?id='.$finical->id.'');



 }	else if (Session::get('activeajency')==0){    return redirect('agency/activition'); }
else if (empty(Session::has('signajency'))){   return redirect('agency/sign-in'); } }
}
		




	public function buyticketfinalycharge(){

	if (Session::has('signajency')){ 
		if (Session::get('activeajency')==1){ 
		
$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first(); 
$slngmenu=\DB::table('languages') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();	 
		
		
$finalys = \DB::table('ajency') 
->join('charge', 'ajency.id', '=', 'charge.charge_iduser') 
->join('finicals', 'charge.charge_finical', '=', 'finicals.id') 
->join('belits', 'finicals.finical_idbelit', '=', 'belits.bel_id') 
->where([
    ['charge.charge_arou', '=', 3],
    ['charge.charge_iduser', '=', Session::get('idajency')],
    ['finicals.finical_payment', '=', 1], 
    ['finicals.finical_inc', '=', 3],
    ['belits.bel_ses', '=', Session::get('wbs_uuses')],])
    ->orderBy('charge.charge_id', 'desc')->first();





if   (!empty ($finalys))  {  //echo 'OK';

$data2=$finalys->bel_daterequest;  
$bel_id=$finalys->bel_id;   
$uu_sessionidD=$finalys->bel_ses;  

 
 
 

   $url   = "https://ucuzauc.com/api/createticket/4e53defd-7620-4ac1-b7e1-61c43f34bb76"; 
  //$url   = "http://88.250.178.229:4545/api/createticket3d/4e53defd-7620-4ac1-b7e1-61c43f34bb76"; 

     
   $kullanici='atin_user'; 
       $sifre='X4fVgT3a';  
       $sess=$uu_sessionidD;  
$data1 = array("request: {$data2}" , "username: $kullanici", "password: $sifre", "SetSession: $sess");
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $data1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, array());
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    $result = curl_exec($ch);
   
 
 
$statu = explode('tatus":', $result );
$status = explode(',', $statu['1'] );

if($status['0']=='false'){ echo $status['0']; }
else if($status['0']=='true'){ 
$mergey = explode(',"mergekey":"', $result );
$eticketnumber = explode('eticketnumber":"', $result );
$pnrt = explode('"pnr":"', $result );
$mergeykey = explode('","', $mergey['1'] );
$teticketnumber = explode('","', $eticketnumber['1'] );
$pnr = explode('","', $pnrt['1'] ); 


 DB::table('belittest')->insert([ 'pnr' => $pnr['0'] ]); 




$updatee = \DB::table('belits')->where('bel_id', '=', $bel_id)  ->update(['bel_mergey' => $mergeykey['0']   ,  'bel_ticketnumber' => $teticketnumber['0']   , 'bel_pnr' => $pnr['0']  ,   'bel_ses' => Session::get('wbs_uuses')  ,  'bel_result' => $result  ]); 


 

  $mergeykey=$mergeykey['0'];
 


 
 // $mergeykey='2e49764d-9443-4831-802c-351366dd6f50';



 
 $wents=  \DB::table('belits')
->join('direction', 'belits.bel_id', '=', 'direction.dir_idbelit') ->where([['bel_mergey', '=',  $mergeykey],['dir_dir', '=',  '0'],])->orderBy('bel_id')->get(); 



 $backc=  \DB::table('belits')
->join('direction', 'belits.bel_id', '=', 'direction.dir_idbelit') ->where([['bel_mergey', '=',  $mergeykey],['dir_dir', '=',  '1'],])->orderBy('bel_id')->count(); 

 $backs=  \DB::table('belits')
->join('direction', 'belits.bel_id', '=', 'direction.dir_idbelit') ->where([['bel_mergey', '=',  $mergeykey],['dir_dir', '=',  '1'],])->orderBy('bel_id')->get(); 


 $passangers=  \DB::table('belits')
->join('passanger', 'belits.bel_id', '=', 'passanger.pas_idbelit') ->where([['bel_mergey', '=',  $mergeykey],])->orderBy('bel_id')->get(); 
 
 
$belits=\DB::table('belits') ->where([['bel_mergey', '=',  $mergeykey],])->orderBy('bel_id', 'desc')->first(); 

 
 $user = \DB::table('belits') ->where([['bel_mergey', '=',  $mergeykey],])->orderBy('bel_id', 'desc')->first(); 
 $usernamee = 'successfully '; 
 $titmes= 'Your ticket has been successfully purchased';
 $mestt= 'PNR ';
 $mesnot = ' '. $user->bel_pnr . ' , Ticket Number: '. $user->bel_ticketnumber ; 
 $email='mustafa1390@gmail.com';
 Mail::send('superadmin.mail', ['user' => $user , 'usernamee' => $usernamee, 'mesnot' => $mesnot, 'titmes' => $titmes , 'mestt' => $mestt], function ($m) use ($user) {       
$decryptedPassword = 'yyyyyyyy';
            $m->from('info@gds724.com',  'GDS724'  );
            $m->to($user->bel_email, $user->bel_email)->subject('Ticket BUY');
        }); 

 

 
  
$rulmngindexs=\DB::table('mngindexgds') ->where([['id', '=',  '5'],])->orderBy('id', 'desc')->first(); 
 
  return view('ajency.printticket', [  'lngmenus' => $lngmenus , 'lngmenu' => $lngmenu ,'slngmenu' =>  $slngmenu, 'wents' => $wents  , 'passangers' => $passangers , 'belits' => $belits  , 'backs' => $backs  , 'backc' => $backc , 'rulmngindexs' => $rulmngindexs ]);
  
  }





 } else {
 	

return redirect('agency/panel');
 	
 //echo 	'NOTFOUND';
}

 }	else if (Session::get('activeajency')==0){    return redirect('agency/activition'); }
else if (empty(Session::has('signajency'))){   return redirect('agency/sign-in'); } }
 	

		
		}





	public function buyticketfinalygetway(){

	if (Session::has('signajency')){ 
		if (Session::get('activeajency')==1){ 

$lngmenus= \DB::table('language') ->where([['id', '<>',  '0'],['lng_active', '=',  '1'],])->orderBy('id', 'desc')->get();
$lngmenu=\DB::table('language') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first(); 
$slngmenu=\DB::table('languages') ->where([['id', '=',  Session::get('idlang')],])->orderBy('id', 'desc')->first();	 
	
		
		
$finalys = \DB::table('ajency') 
->join('charge', 'ajency.id', '=', 'charge.charge_iduser') 
->join('finicals', 'charge.charge_finical', '=', 'finicals.id') 
->join('belits', 'finicals.finical_idbelit', '=', 'belits.bel_id') 
->where([
    ['charge.charge_arou', '=', 3],
    ['charge.charge_iduser', '=', Session::get('idajency')],
    ['finicals.finical_payment', '=', 1], 
    ['finicals.finical_inc', '=', 4],
    ['belits.bel_ses', '=', Session::get('wbs_uuses')],])
    ->orderBy('charge.charge_id', 'desc')->first();

//echo $finalys->bel_daterequest;

if   (!empty ($finalys))  { // echo 'OK';
$data2=$finalys->bel_daterequest;  
$bel_id=$finalys->bel_id;   
$uu_sessionidD=$finalys->bel_ses;  
 

 

   $url   = "https://ucuzauc.com/api/createticket/4e53defd-7620-4ac1-b7e1-61c43f34bb76"; 
  // $url   = "http://88.250.178.229:4545/api/createticket3d/4e53defd-7620-4ac1-b7e1-61c43f34bb76"; 

     
   $kullanici='atin_user'; 
       $sifre='X4fVgT3a';  
       $sess=$uu_sessionidD;  
$data1 = array("request: {$data2}" , "username: $kullanici", "password: $sifre", "SetSession: $sess");
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $data1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, array());
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    $result = curl_exec($ch);
   
 
 
$statu = explode('tatus":', $result );
$status = explode(',', $statu['1'] );

if($status['0']=='false'){ echo $status['0']; }
else if($status['0']=='true'){ 
$mergey = explode(',"mergekey":"', $result );
$eticketnumber = explode('eticketnumber":"', $result );
$pnrt = explode('"pnr":"', $result );
$mergeykey = explode('","', $mergey['1'] );
$teticketnumber = explode('","', $eticketnumber['1'] );
$pnr = explode('","', $pnrt['1'] ); 


 DB::table('belittest')->insert([ 'pnr' => $pnr['0'] ]); 




$updatee = \DB::table('belits')->where('bel_id', '=', $bel_id)  ->update(['bel_mergey' => $mergeykey['0']   ,  'bel_ticketnumber' => $teticketnumber['0']   , 'bel_pnr' => $pnr['0']  ,   'bel_ses' => Session::get('wbs_uuses')  ,  'bel_result' => $result  ]); 


 

  $mergeykey=$mergeykey['0'];
  


  
  //$mergeykey='2e49764d-9443-4831-802c-351366dd6f50';



 
 $wents=  \DB::table('belits')
->join('direction', 'belits.bel_id', '=', 'direction.dir_idbelit') ->where([['bel_mergey', '=',  $mergeykey],['dir_dir', '=',  '0'],])->orderBy('bel_id')->get(); 



 $backc=  \DB::table('belits')
->join('direction', 'belits.bel_id', '=', 'direction.dir_idbelit') ->where([['bel_mergey', '=',  $mergeykey],['dir_dir', '=',  '1'],])->orderBy('bel_id')->count(); 

 $backs=  \DB::table('belits')
->join('direction', 'belits.bel_id', '=', 'direction.dir_idbelit') ->where([['bel_mergey', '=',  $mergeykey],['dir_dir', '=',  '1'],])->orderBy('bel_id')->get(); 


 $passangers=  \DB::table('belits')
->join('passanger', 'belits.bel_id', '=', 'passanger.pas_idbelit') ->where([['bel_mergey', '=',  $mergeykey],])->orderBy('bel_id')->get(); 
 
 
$belits=\DB::table('belits') ->where([['bel_mergey', '=',  $mergeykey],])->orderBy('bel_id', 'desc')->first(); 

 
 $user = \DB::table('belits') ->where([['bel_mergey', '=',  $mergeykey],])->orderBy('bel_id', 'desc')->first(); 
 $usernamee = 'successfully '; 
 $titmes= 'Your ticket has been successfully purchased';
 $mestt= 'PNR ';
 $mesnot = ' '. $user->bel_pnr . ' , Ticket Number: '. $user->bel_ticketnumber ; 
 $email='mustafa1390@gmail.com';
 Mail::send('superadmin.mail', ['user' => $user , 'usernamee' => $usernamee, 'mesnot' => $mesnot, 'titmes' => $titmes , 'mestt' => $mestt], function ($m) use ($user) {       
$decryptedPassword = 'yyyyyyyy';
            $m->from('info@gds724.com',  'GDS724'  );
            $m->to($user->bel_email, $user->bel_email)->subject('Ticket BUY');
        }); 
 
 

 
  
$rulmngindexs=\DB::table('mngindexgds') ->where([['id', '=',  '5'],])->orderBy('id', 'desc')->first(); 
 
  return view('ajency.printticket', [  'lngmenus' => $lngmenus , 'lngmenu' => $lngmenu ,'slngmenu' =>  $slngmenu, 'wents' => $wents  , 'passangers' => $passangers , 'belits' => $belits  , 'backs' => $backs  , 'backc' => $backc , 'rulmngindexs' => $rulmngindexs ]);
  
  
}








 } else {
 	

 return redirect('agency/panel');
 	
 //echo 	'NOTFOUND';
}

 }	else if (Session::get('activeajency')==0){    return redirect('agency/activition'); }
else if (empty(Session::has('signajency'))){   return redirect('agency/sign-in'); }  	}
 	
		
		}



	
	
	
	
	
	
	
	
	
	
	
	
	
					
																							
	
	 
    
}
