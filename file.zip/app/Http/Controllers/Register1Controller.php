<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\note;

use Validator;

class Register1Controller extends Controller
{
	
	
	
	
	
    public function formValidation()
    {
    	return view('paneltest1/formvalidation');
    }

    public function formValidationPost(Request $request)
    {
    	$this->validate($request,[
    			'firstname' => 'required|min:5|max:35',
    			'lastname' => 'required|min:5|max:35',
    			'email' => 'required|email|unique:users',
    			'mobileno' => 'required|numeric',
    			'password' => 'required|min:3|max:20',
    			'confirm_password' => 'required|min:3|max:20|same:password',
    			'details' => 'required'
    		],[
    			'firstname.required' => ' نشده.',
    			'firstname.min' => ' The first name must be at least 5 characters.',
    			'firstname.max' => ' The first name may not be greater than 35 characters.',
    			'lastname.required' => ' The last name field is required.',
    			'lastname.min' => ' The last name must be at least 5 characters.',
    			'lastname.max' => ' The last name may not be greater than 35 characters.',
    		]);

		$note=new note;
		$note->note_name = $request->firstname;
		$note->note_us = md5($request->password);
		$note->save();
    	dd('You are successfully added all fields.');
    	
    }
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	public function save(Request $request)
{
    // set form validation rules
    $this->validate($request, [
        'title' => 'required',
        'body'  => 'required'
    ]);

    // if the validation passes, save to database and redirect
}
	
	
	
	public function login(){
		return view('paneltest1/login');
		
	}
	
	
	public function register(){
		return view('paneltest1/register');
		
	}
	
	
	
	
	
	public function insert(Request $request ){
		





		$user=new user;
		$user->firstname = $request->firstname;
		$user->password = md5($request->password);
		$user->save();
	
	
	}
	
	
    //
}
