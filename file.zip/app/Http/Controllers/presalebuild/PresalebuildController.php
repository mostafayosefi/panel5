<?php

namespace App\Http\Controllers\presalebuild;

use Illuminate\Http\Request;
use Auth;
use Session;
use DB;
use Crypt;
use Rule;
use Mail;

use Validator;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class PresalebuildController extends Controller
{ 
 
     
   public function indexpre(Request $request){ 

   
$mngindex=  DB::table('user')  ->where('id' , '<>' , 0)->orderBy('id')->first();  
return view('presalebuild.index', [ 'mngindex' => $mngindex    ]);


}	

 


    
}
