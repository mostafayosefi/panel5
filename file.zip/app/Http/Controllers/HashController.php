<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;


     use Decrypt;
     use Redirect;
     use Hash;
use App\Http\Requests;

use App\note;


class HashController extends Controller
{
	
 public function actionIndex()
    {
    	
    	
		 return view('hash');
	 }
	
	
	
	
	
	
 public function signinPost(Request $request)
    {
    	 
    	 
    	 
  	 
    		//	$note=new note;
$contraseniaEncriptada = 	md5($request->txtContrasenia);

	$output = false;
 
		$key =  env('APP_KEY');
		$iv = md5($key);
	
	
			//$output = mcrypt_encrypt(MCRYPT_RIJNDAEL_256, md5($key), $request->txtContrasenia, MCRYPT_MODE_CBC, $iv);
			//$output = base64_encode($output);
			
	$output=mcrypt_decrypt(MCRYPT_RIJNDAEL_256, md5($key), base64_decode($request->txtContrasenia), MCRYPT_MODE_CBC, $iv);
	$output = rtrim($output, "");
	
	








		//$note->note_us = md5($request->password);	
	//		$contraseniaEncriptada = Hash::make($request->txtContrasenia);
		
	//	$contraseniaEncriptada =  Crypt::decrypt($request->txtContrasenia);
		
		
 	
		
	
	 return View('hash', ['contraseniaEncriptada' => $output]);
	 }
	
	
	
	
	
	
	
	
	
	
	
	
	


	
	
	
	
	
	
	
	/*
	public function actionIndex()
 {
  if($_POST)
  {
   if(Input::has('txtContrasenia'))
   {
    $contraseniaEncriptada=Crypt::encrypt(Input::get('txtContrasenia'));
 
    return View::make('hash', ['contraseniaEncriptada' => $contraseniaEncriptada]);
   }
 
   if(Input::has('txtContraseniaEncriptada'))
   {
    $contraseniaDesencriptada=Crypt::decrypt(Input::get('txtContraseniaEncriptada'));
 
    return View::make('hash', ['contraseniaDesencriptada' => $contraseniaDesencriptada]);
   }
  }
 
  return view('hash');
 }
	
	*/
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
    //
}
