<?php

namespace App\Http\Controllers;




use App\Http\Requests;

class CardsController extends Controller
{
	
	

   
    public function index()
    {
    	
    	
    	  	$users = \ DB::table('users')->where('active', [1])->get();
    	  	
    	//$users = \ DB::table('users')->where('name', 'John')->get();
       // $users = \DB::select('select * from users where active = ?', [1]);

        return view('cards.index', ['users' => $users]);
    }
     
    


	public function show($id){

  
/*  
    $users = \ DB::table('users')->where('users.active','1')
    ->join('notes', 'notes.note_us', '=', 'users.id');
 */ 
  
  
  /*
  $users = \ DB::table('users')
        ->join('notes', function ($join) {
            $join->on('users.id', '=', 'notes.note_us')
           ->where('id', '=', 2);
        })
        ->get();
      
   */
   
   /*
   $users = \DB::table('users')
            ->join('notes', 'users.id', '=', 'notes.note_us')
            ->select('users.*', 'notes.note_name')
               ->where('id', '=', $id) 
            ->get();     
     */
     
     $users = \DB::table('users')->where('id', $id)->first();   
        
        
          //$users = \DB::select('select * from users where id = ?', [$id]);
         
         return view('cards.note', ['users' => $users]);
         
         
         
         
                //$notes = \DB::select('select * from notes where note_id = ?', [$id]);
         
        //  return view('cards.note', ['notes' => $notes]);
		
	}
 

	public function store(){
		
	
		return \Request::all();
	}

    //
}
