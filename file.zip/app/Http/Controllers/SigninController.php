<?php

namespace App\Http\Controllers;

use App\Http\Requests;
use Validator;
use Auth;
use Session;
use DB;
use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\ThrottlesLogins;
use Illuminate\Foundation\Auth\AuthenticatesAndRegistersUsers;
use Illuminate\Http\Request;
 



class SigninController extends Controller
{
	

    use AuthenticatesAndRegistersUsers, ThrottlesLogins;

    protected $redirectTo = '/';

    /**
     * Create a new authentication controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest', ['except' => 'logout']);
    }

    /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator(array $data)
    {
        return Validator::make($data, [
            'name' => 'required|max:255',
            'email' => 'required|email|max:255|unique:users',
            'password' => 'required|confirmed|min:6',
        ]);
    }

    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return User
     */
    protected function create(array $data)
    {
        return User::create([
            'name' => $data['name'],
            'email' => $data['email'],
            'password' => bcrypt($data['password']),
        ]);
    }

	
	
	
	
	
	
	
	
	
	
		
public function sigin(){
return view('sign-in');
	}
	
	
	
	
	
    public function signinPost(Request $request)
    {
    	$this->validate($request,[
    			'firstname' => 'required|min:5|max:35',
    			'lastname' => 'required|min:5|max:35'
    		],[
    			'firstname.required' => 'لطفا نام کاربری را وارد نمایید',
    			'firstname.min' => 'نام کاربری شما باید بیشتر از 5 کاراکتر باشد',
    			'firstname.max' => 'یوزرنیم شما باید کمتر از 35 کارکتر باشد',
    			'lastname.required' => 'لطفا رمز ورود را وارد نمایید',
    			'lastname.min' => ' رمز کوتاه است',
    			'lastname.max' => ' رمزعبور طولانی است ',
    		]);

/*
		$note=new note;
		$note->note_name = $request->firstname;
		$note->note_us = md5($request->password);
		$note->save();
	*/	
	
	
	$output = false;
	$key =  env('APP_KEY');
	$iv = md5($key);
	$output = mcrypt_encrypt(MCRYPT_RIJNDAEL_256, md5($key), $request->userpassword, MCRYPT_MODE_CBC, $iv);
	$output = base64_encode($output);


		 

 
$admins = DB::table('admins')->where([
    ['admin_username',  $request->firstname],
    ['admin_active', '<>', '1'],
])->first();




$userscou = DB::table('admins')->where('admin_username', $request->firstname)->count();
if($userscou != 0){
		$id_db= $admins->id;
		$username_db= $admins->admin_username; 
$password_db= $admins->admin_password; 

$username_log = $request->firstname; 
		$password_log = md5($request->password);

if($username_log == $username_db){
			session_start();
			$_SESSION['iddb']=$id_db;
			
			return redirect('superadmin/panel');
		}
		}
		
		else
		
    	$nametr = Session::flash('statust', 'لطفا اطلاعات را به درستی وارد نمایید.');
		
		 return view('sign-in');
    	
    }
	
	
	
	
	
	
	
	
	
	
	
    //
}
