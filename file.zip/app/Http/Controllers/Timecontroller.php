<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use jDate;

class Timecontroller extends Controller
{
    //
    public function time(){
		// default timestamp is now
$date = \Morilog\Jalali\jDate::forge();
// OR
$date = jdate();

// pass timestamps
$date = jDate::forge(1333857600);
// OR
$date = jdate(1333857600);

// pass strings to make timestamps
$date = jDate::forge('last sunday');

// get the timestamp
$date = jDate::forge('last sunday')->time(); // 1333857600

// format the timestamp
$date = jDate::forge('last sunday')->format('%B %d، %Y'); // دی 02، 1391

// get a predefined format
//$date = jDate::forge('last sunday')->format('datetime'); // 1391-10-02 00:00:00
//$date = jDate::forge('last sunday')->format('date'); // 1391-10-02
//$date = jDate::forge('last sunday')->format('time'); // 00:00:00

// amend the timestamp value, relative to existing value
//$date = jDate::forge('2012-10-12')->reforge('+ 3 days')->format('date'); // 1391-07-24

// get relative 'ago' format
//$date = jDate::forge('now - 10 minutes')->ago(); // 10 دقیقه پیش
// OR
//$date = jdate('now - 10 minutes')->ago(); // 10 دقیقه پیش
    	return $date;
	}
}
