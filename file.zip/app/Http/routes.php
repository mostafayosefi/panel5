<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::auth();
 


Route::group(['namespace' => 'Superadmin'], function () {
	
Route::get('superadmin','SuperadminController@superadminlogin'); 
Route::get('superadmin/sign-in','SuperadminController@superadminlogin'); 
Route::post('superadmin/sign-in', 'SuperadminController@superadminPosts');
Route::get('superadmin/sign-out','SuperadminController@superadminsignout');
Route::get('superadmin/myprofile/edit/sup','SuperadminController@myprofile');
Route::post('superadmin/myprofile/edit/sup','SuperadminController@editmyprofilePost'); 
Route::post('superadmin/myprofile/dropzone/store', ['as'=>'dropzone.storesup','uses'=>'SuperadminController@dropzoneStoredmyprofile']);
Route::post('superadmin/myprofile/securityysup', ['as'=>'securityysup','uses'=>'SuperadminController@securityysup']); 
 	
Route::get('superadmin/panel','SuperadminController@panel');
Route::get('superadmin/table','SuperadminController@table'); 
Route::get('superadmin/success','SuperadminController@success'); 
 
Route::get('superadmin/addareaagancy','SuperadminController@addareaagancy'); 
Route::post('superadmin/addareaagancy','SuperadminController@addareaagancypost'); 
Route::get('superadmin/viewsreaagancy','SuperadminController@viewsreaagancy'); 
Route::get('superadmin/viewsreaagancy/edit/{id}','SuperadminController@editareaagancy'); 
Route::post('superadmin/viewsreaagancy/edit/{id}','SuperadminController@editareaagancypost'); 
Route::get('superadmin/viewsreaagancy/delet/{id}','SuperadminController@deletareaagancy'); 


Route::get('superadmin/addsubareaagancy','SuperadminController@addsubareaagancy');
Route::post('superadmin/addsubareaagancy','SuperadminController@addsubareaagancypost');
Route::get('superadmin/viewssubareaagancy','SuperadminController@viewssubareaagancy'); 
Route::get('superadmin/viewssubareaagancy/edit/{id}','SuperadminController@editsubareaagancy'); 
Route::post('superadmin/viewssubareaagancy/edit/{id}','SuperadminController@editsubareaagancypost'); 
Route::get('superadmin/viewssubareaagancy/delet/{id}','SuperadminController@viewssubareaagancydelet'); 












 
Route::get('superadmin/addagency','SuperadminController@addajency'); 
Route::post('superadmin/addagency','SuperadminController@addajencyPost');
Route::get('superadmin/viewsagencys','SuperadminController@viewsajancys'); 
Route::get('superadmin/viewsagencys/editagency/{id}','SuperadminController@editajency'); 
Route::post('superadmin/viewsagencys/editagency/{id}','SuperadminController@editajencyPost'); 
Route::post('superadmin/viewsagencys/dropzone/store', ['as'=>'dropzone.storeajency','uses'=>'SuperadminController@dropzoneStoreajency']);
Route::post('superadmin/viewsagencys/securityyajency', ['as'=>'securityyajency','uses'=>'SuperadminController@securityyajency']);
Route::get('superadmin/viewsagencys/delet/{id}','SuperadminController@deletajency');
Route::get('superadmin/viewsagencys/editagency/acc/{id}','SuperadminController@accjency');
Route::get('superadmin/viewsagencys/editagency/rej/{id}','SuperadminController@rejajency');



Route::get('superadmin/adduser','SuperadminController@addusersup'); 
Route::post('superadmin/adduser','SuperadminController@addusertPost');
Route::get('superadmin/viewsusers','SuperadminController@viewsuserssup');
Route::get('superadmin/viewsusers/edituser/{id}','SuperadminController@editusersup');
Route::post('superadmin/viewsusers/edituser/{id}','SuperadminController@editusersupPost'); 
Route::post('superadmin/viewsusers/dropzone/store', ['as'=>'dropzone.storeuser','uses'=>'SuperadminController@dropzoneStoreuser']);
Route::post('superadmin/viewsusers/securityystud', ['as'=>'securityystud','uses'=>'SuperadminController@securityystud']);
Route::get('superadmin/viewsusers/delet/{id}','SuperadminController@deletusersup');
Route::get('superadmin/viewsusers/edituser/acc/{id}','SuperadminController@accusersup');
Route::get('superadmin/viewsusers/edituser/rej/{id}','SuperadminController@rejusersup');
Route::get('superadmin/viewsusers/loginuser/{id}','SuperadminController@loginusersup');





















});



Route::group(['namespace' => 'ajency'], function () {

Route::get('agency','AjencyController@ajencylogin');
Route::get('agency/sign-in','AjencyController@ajencylogin');
Route::post('agency/sign-in','AjencyController@ajencyloginpost');
Route::get('agency/panel','AjencyController@panelajency');
Route::get('agency/panel/{id}','AjencyController@panelajencyid');
Route::get('agency/sign-out','AjencyController@ajencysignout');	
Route::get('agency/myprofile/edit','AjencyController@editprofileajency');	
Route::post('agency/myprofile/edit','AjencyController@editprofileajencypost');	
Route::get('agency/myprofile/charge','AjencyController@chargeagencyaj');	
Route::post('agency/myprofile/dropzone/storeajencyprofile', ['as'=>'dropzone.storeajencyprofile','uses'=>'AjencyController@dropzoneStoreajencyfile']);
Route::post('agency/myprofile/securityajencyprofile', ['as'=>'securityajencyprofile','uses'=>'AjencyController@securityajencyprofile']);
Route::get('agency/myprofile/webservice','AjencyController@webservicmyeagency');
Route::post('agency/myprofile/webservice','AjencyController@webservicmyeagencypost');

Route::get('agency/activition','AjencyController@activitionajency');
Route::post('agency/activition/emailajencyactivitionverfy', ['as'=>'emailajencyactivitionverfy','uses'=>'AjencyController@emailajencyactivitionverfy']);
Route::post('agency/activition/emailajencyactivition', ['as'=>'emailajencyactivition','uses'=>'AjencyController@emailajencyactivition']);
Route::post('agency/activition/tellajencyactivitionverfy', ['as'=>'tellajencyactivitionverfy','uses'=>'AjencyController@tellajencyactivitionverfy']);
Route::post('agency/activition/tellajencyactivition', ['as'=>'tellajencyactivition','uses'=>'AjencyController@tellajencyactivition']);
Route::post('agency/activition/dropzone/storeajencydoc', ['as'=>'dropzone.storeajencydoc','uses'=>'AjencyController@storeajencydoca']);




Route::get('agency/registeragency','AjencyController@registeragency');
Route::post('agency/registeragency','AjencyController@registeragencyPost');  



Route::get('agency/sign-inn','AjencyController@ajencyloginn');
Route::post('agency/sign-inn','AjencyController@ajencyloginpostn');
 

	
});


 






 

Route::group(['namespace' => 'user'], function () {
	
Route::get('user/login','UserController@loginuser');
Route::post('user/login','UserController@loginuserpost');

Route::get('user/paneluser','UserController@paneluseruser');


Route::get('user','UserController@userlogin');
Route::get('user/sign-in','UserController@userlogin');
Route::post('user/sign-in','UserController@userloginpost');
Route::get('user/panel','UserController@paneluser');
Route::get('user/panel/{id}','UserController@paneluserid');

Route::get('user/sign-out','UserController@usersignout');	
Route::get('user/myprofile/edit','UserController@editprofileuser');	

Route::get('user/myprofile/charge','UserController@editprofileusercharge');	
Route::get('user/myprofile/viewscharge/detcharge/{id}','UserController@editprofiledetcharge');
 
	
Route::post('user/myprofile/edit','UserController@editprofileuserPost');	
Route::post('user/myprofile/dropzone/storeuserprofile', ['as'=>'dropzone.storeuserprofile','uses'=>'UserController@dropzoneStoreuserprofile']);
Route::post('user/myprofile/securityuserprofile', ['as'=>'securityuserprofile','uses'=>'UserController@securityuserprofile']);

 
Route::get('user/activition','UserController@activitionuser');
Route::post('user/activition/emailuseractivitionverfy', ['as'=>'emailuseractivitionverfy','uses'=>'UserController@emailuseractivitionverfy']);
Route::post('user/activition/emailuseractivition', ['as'=>'emailuseractivition','uses'=>'UserController@emailuseractivition']);
Route::post('user/activition/telluseractivitionverfy', ['as'=>'telluseractivitionverfy','uses'=>'UserController@telluseractivitionverfy']);
Route::post('user/activition/telluseractivition', ['as'=>'telluseractivition','uses'=>'UserController@telluseractivition']);


Route::get('user/addproject','UserController@addproject');
Route::post('user/addproject','UserController@addprojectpost'); 
 
 
	
Route::get('user/registeruser','UserController@adduserfruser');
Route::post('user/registeruser','UserController@adduserfruserPost');   
});
 
 
  