<!DOCTYPE html>
<html>
    <head>
        <title>Laravel</title>

 <!-- <link  rel="stylesheet" href="/blog/public/{{ elixir('css/app.css') }} "/>  --> 
 
 <link  rel="stylesheet" href="css/app.css"/> 
    </head>
    <body>
        <section class="container">
        @yield('content')
        </section>
        
    </body>
</html>
