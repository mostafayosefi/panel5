
@extends('superadmin.layoutsuperadmin')

@section('title')
<title>موفقیت </title>
@stop

 
@section('superadmin')

      
       <section class="content">
          <div class="row">
         <div class="col-md-3"></div>
         <div class="col-md-6">
         
   
                     
                     @if(!empty(Session::get('statust'))) 
                     
     <div class="alert alert-success alert-dismissable">
                   <h4>	<i class="icon fa fa-check"></i> موفقیت!</h4>
                     {{ Session::get('statust')}}
                     <br>
                     برای بازگشت کلیک نمایید
                     <a href="{{ url('/superadmin/') }}/{{ Session::get('sessurl')}}">بازگشت</a>
                     </div> 
                      @endif
                     <?php  Session::forget('statust'); ?>
                     
      
                  
    
         


                </div>
                
                
                </div>
                </section>
         
         

@stop

