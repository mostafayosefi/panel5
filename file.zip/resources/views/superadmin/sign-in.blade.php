
@extends('layoutlogin')

@section('title')
<title> ورود سوپر ادمین </title>
@stop

@section('contentsignin')



    <div class="login-box">
      <div class="login-logo">
    
      </div><!-- /.login-logo -->
      


      <div class="login-box-body">
            
  <div style="text-align: center;" class="alert alert-info">
            <img src="{{env('APP_URL')}}/build/style/dist/img/Teacher.png" alt="ورود" title="ورود سوپر ادمین" />
            <br />
                ورود&nbsp;سوپر ادمین
            </div>

      
        <p class="login-box-msg">نام کاربری و رمزعبور خود را وارد نمایید</p>
        
        
        
<form method="POST" action="{{env('APP_URL')}}/superadmin/sign-in" autocomplete="off">

      @if(!empty(Session::get('statust')))
      <div class="alert alert-danger">
				<strong>اخطار!</strong>
				<ul><li>{{ Session::get('statust')}}</li></ul>
				</div>
        @endif
      
      
      
      
      
	@if(count($errors))
			<div class="alert alert-danger">
				<strong>اخطار!</strong> لطفا اطلاعات را به درستی وارد نمایید.
				<br/>
				<ul>
					@foreach($errors->all() as $error)
					<li>{{ $error }}</li>
					@endforeach
				</ul>
			</div>
		@endif




          <div class="form-group has-feedback {{ $errors->has('firstname') ? 'has-error' : '' }}">
            <input type="text"  id="firstname" name="firstname" class="form-control" placeholder="نام کاربری"  value="{{ old('firstname') }}">
            <span class="glyphicon glyphicon-user form-control-feedback"></span>
          </div>
          <div class="form-group has-feedback {{ $errors->has('lastname') ? 'has-error' : '' }}">
            <input type="password" id="lastname" name="lastname" class="form-control" placeholder="رمزعبور" value="{{ old('lastname') }}">
            <span class="glyphicon glyphicon-lock form-control-feedback"></span>
          </div>
          <input type="hidden" name="_token" value="{{ csrf_token() }}">
          
          
          <div class="row">
       
       <div class="col-xs-12">
       <button class="btn btn-primary btn-block btn-flat">ورود</button>
       
            </div><!-- /.col -->
          </div>
          </br>
        			 <span id="msgbox" style="display:none; background:#f8f3a4;  font-size:14px;"> 
			                
               </span>
        </form>


 <!--
        <div class="social-auth-links text-center">
 <div class="col-xs-9">
          <a href="forgetpass.php" class="btn btn-block btn-social btn-google btn-flat"><i class="fa fa-angellist"></i>فراموشی رمزعبور</a> </div> <div class="col-xs-9">
<a href="index.php" class="btn btn-block btn-social btn-facebook btn-flat"><i class="fa fa-archive"></i> بازگشت به صفحه اصلی</a>
        </div> 
        <div class="col-xs-9">
<a href="register.php" class="btn btn-block btn-social btn-adn btn-flat"><i class="fa fa-list"></i>ثبت نام در سامانه</a>
        </div>
        </div>  -->

      </div>
      
      
      
      
      
      
      <!-- /.login-box-body -->
</div>


</body>



@stop
