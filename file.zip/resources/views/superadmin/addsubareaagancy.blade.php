
@extends('superadmin.layoutsuperadmin')

@section('title')
<title>ثبت بخش</title>
@stop
 
@section('superadmin')

        <section class="content-header">
          <h1>
           پنل
            <small> سوپر ادمین</small>
          </h1>
          <ol class="breadcrumb">
   			<li><a href="{{ url('/superadmin/panel') }}"><i class="fa fa-dashboard"></i>پنل</a></li>
            <li><a href="{{ url('/superadmin/addsubareaagancy') }}">ثبت بخش</a></li>
            <li class="active">ثبت</li>
          </ol>
        </section>
        
        <section class="content">
          <div class="row">
         <div class="col-md-3"></div>
         <div class="col-md-6">
          <div class="box box-warning">
                <div class="box-header with-border">
                  <h3 class="box-title">ثبت بخش</h3>
                </div><!-- /.box-header -->
                <div class="box-body">
                  <form method="POST" action="" autocomplete="off" enctype="multipart/form-data"  >
                  
                  
                  	@if(count($errors))
			<div class="alert alert-danger">
				<strong>اخطار!</strong> لطفا اطلاعات را به درستی وارد نمایید.
				<br/>
				<ul>
					@foreach($errors->all() as $error)
					<li>{{ $error }}</li>
					@endforeach
				</ul>
			</div>
		@endif
                  
                  
             
                
<div class="form-group {{ (($errors->has('category'))||(Session::get('repeat')==1))  ? 'has-error' : '' }}">  
@if (Session::get('repeat')==1) <label>لطفا منطقه را انتخاب نمایید</label> @else
<label>منطقه</label> @endif
                    <select class="form-control select2" style="width: 100%;" name="category">
                    @foreach ($admins as $admin)
                      <option value="{{$admin->areaagancy_id}}">{{$admin->areaagancy_name}}</option>
                 @endforeach
                 
                    </select>
                  </div><!-- /.form-group -->            
                   
                     
                    
                    <div class="form-group {{ $errors->has('file') ? 'has-error' : '' }}">
                <label for="published_at">انتخاب تصویر</label>
                <input type="file" name="file" id="file">
            </div>
                    


                    <div class="form-group {{ $errors->has('groupname') ? 'has-error' : '' }}">
 @if ($errors->has('groupname'))                 
<label class="control-label" for="inputError"><i class="fa fa-times-circle-o"></i>نام بخش را به درستی وارد نمایید</label>
@endif
<input type="text" class="form-control" id="groupname" name="groupname" placeholder="نام بخش "  value="{{ old('groupname') }}">
                    </div> 

 

                
                
                     <input type="hidden" name="_token" value="{{ csrf_token() }}">
   					<div class="row">
       					<div class="col-xs-12">
       <button class="btn btn-primary btn-block btn-flat">ثبت بخش</button>
       
            </div> 
          </div>






                  </form>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
              	
              </div>
              <div class="col-md-3"></div>
       
          </div>
          </section>

@stop

 
@section('scriptfooter')
        
 
  
    <!-- Select2 -->
    <script src="{{env('APP_URL')}}/build/style/plugins/select2/select2.full.min.js"></script>
    <!-- InputMask -->
    <script src="{{env('APP_URL')}}/build/style/plugins/input-mask/jquery.inputmask.js"></script>
    <script src="{{env('APP_URL')}}/build/style/plugins/input-mask/jquery.inputmask.date.extensions.js"></script>
    <script src="{{env('APP_URL')}}/build/style/plugins/input-mask/jquery.inputmask.extensions.js"></script>
    <!-- date-range-picker -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.2/moment.min.js"></script>
    <script src="{{env('APP_URL')}}/build/style/plugins/daterangepicker/daterangepicker.js"></script>
    <!-- bootstrap color picker -->
    <script src="{{env('APP_URL')}}/build/style/plugins/colorpicker/bootstrap-colorpicker.min.js"></script>
    <!-- bootstrap time picker -->
    <script src="{{env('APP_URL')}}/build/style/plugins/timepicker/bootstrap-timepicker.min.js"></script>
    <!-- SlimScroll 1.3.0 -->
    <script src="{{env('APP_URL')}}/build/style/plugins/slimScroll/jquery.slimscroll.min.js"></script>
    <!-- iCheck 1.0.1 -->
    <script src="{{env('APP_URL')}}/build/style/plugins/iCheck/icheck.min.js"></script>
    <!-- FastClick -->
    <script src="{{env('APP_URL')}}/build/style/plugins/fastclick/fastclick.min.js"></script>

  <script src="{{env('APP_URL')}}/build/style/js/ga.js"></script>
  <script src="{{env('APP_URL')}}/build/style/js/ckeditor/ckeditor.js"></script>
  
  
    <script>
      $(function () {
        //Initialize Select2 Elements
        $(".select2").select2();

        //Datemask dd/mm/yyyy
        $("#datemask").inputmask("dd/mm/yyyy", {"placeholder": "dd/mm/yyyy"});
        //Datemask2 mm/dd/yyyy
        $("#datemask2").inputmask("mm/dd/yyyy", {"placeholder": "mm/dd/yyyy"});
        //Money Euro
        $("[data-mask]").inputmask();

        //Date range picker
        $('#reservation').daterangepicker();
        //Date range picker with time picker
        $('#reservationtime').daterangepicker({timePicker: true, timePickerIncrement: 30, format: 'MM/DD/YYYY h:mm A'});
        //Date range as a button
        $('#daterange-btn').daterangepicker(
            {
              ranges: {
                'Today': [moment(), moment()],
                'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
                'Last 7 Days': [moment().subtract(6, 'days'), moment()],
                'Last 30 Days': [moment().subtract(29, 'days'), moment()],
                'This Month': [moment().startOf('month'), moment().endOf('month')],
                'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
              },
              startDate: moment().subtract(29, 'days'),
              endDate: moment()
            },
        function (start, end) {
          $('#reportrange span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'));
        }
        );

        //iCheck for checkbox and radio inputs
        $('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
          checkboxClass: 'icheckbox_minimal-blue',
          radioClass: 'iradio_minimal-blue'
        });
        //Red color scheme for iCheck
        $('input[type="checkbox"].minimal-red, input[type="radio"].minimal-red').iCheck({
          checkboxClass: 'icheckbox_minimal-red',
          radioClass: 'iradio_minimal-red'
        });
        //Flat red color scheme for iCheck
        $('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
          checkboxClass: 'icheckbox_flat-green',
          radioClass: 'iradio_flat-green'
        });

        //Colorpicker
        $(".my-colorpicker1").colorpicker();
        //color picker with addon
        $(".my-colorpicker2").colorpicker();

        //Timepicker
        $(".timepicker").timepicker({
          showInputs: false
        });
      });
    </script>
  
  
@stop  
   
