@extends('superadmin.layoutsuperadmin')

@section('title')
<title>مشاهده آژانس ها</title>
@stop

 
@section('superadmin')

        <section class="content-header">
           <h1>
           پنل
            <small> سوپر ادمین</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="{{ url('/superadmin/panel') }}"><i class="fa fa-dashboard"></i> پنل</a></li>
            <li><a href="{{ url('/superadmin/viewsagencys') }}">مشاهده آژانس ها</a></a></li>
          </ol>
        </section>


<section class="content">

<div class="row">

<div class="col-xs-12">

              <div class="box">
                <div class="box-header">
                  <h3 class="box-title"> آژانس ها</h3>
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table id="example1" class="table table-bordered table-striped">
@if   (empty ($admins))                 
         
<tr>داده ای وجود ندارد<tr>
@elseif ($admins)     
                    <thead>
                      <tr> 
                        <th>ردیف</th>
                        <th>نام کاربری</th> 
                        <th>تاریخ ثبت نام</th>
                        <th>وضعیت</th>
                        <th>حذف</th> 
                      </tr>
                    </thead>
                    <tbody>
             
                    
 <?php  $i=1;    ?>                   
@foreach ($admins as $admin)
<tr>
                        <td>{{$i++}} </td>
                        <td>{{$admin->ajency_username}} </td> 
 
                        <td>{{jDate::forge($admin->ajency_createdatdate)->format('Y/m/d ساعت H:i a')}}</td>
@if($admin->ajency_active == '1')                       
<td><a href="viewsagencys/editagency/{{$admin->id}}"   ><span class="label label-success">فعال</span></a></td>
@elseif($admin->ajency_active != '1')
<td><a href="viewsagencys/editagency/{{$admin->id}}"  ><span class="label label-warning">غیرفعال</span></a></td>
@endif
 <td><a href="viewsagencys/delet/{{$admin->id}}"   > <span class="label label-danger">حذف</span></a></td>
</tr>


@endforeach

    
                    </tbody>
                    <tfoot>
                      <tr> 
                        <th>ردیف</th>
                        <th>نام کاربری</th> 
                        <th>تاریخ ثبت نام</th>
                        <th>وضعیت</th>
                        <th>حذف</th> 
                      </tr>
                    </tfoot>
                    @endif
                  </table>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col --> 
            </div><!-- /.col --> 
        </section><!-- /.content --> 
<style> @media only screen and (min-width: 30px) and (max-width: 2860px) { .box-body { overflow-x: scroll; }  </style>
@stop

