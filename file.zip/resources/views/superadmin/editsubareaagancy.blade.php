
@extends('superadmin.layoutsuperadmin')

@section('title')
<title>ویرایش بخش</title>
@stop
 
@section('superadmin')

        <section class="content-header">
          <h1>
           پنل
            <small> سوپر ادمین</small>
          </h1>
          <ol class="breadcrumb">
   			<li><a href="{{ url('/superadmin/panel') }}"><i class="fa fa-dashboard"></i>پنل</a></li>
            <li><a href="{{ url('/superadmin/viewssubareaagancy') }}">مشاهده بخشهای مناطق</a></li> 
            <li class="active">منطقه {{$admins->areaagancy_name}}</li>
            <li class="active">بخش {{$admins->aria_name}}</li>
          </ol>
        </section>
        
        <section class="content">
          <div class="row">
         <div class="col-md-3"></div>
         <div class="col-md-6">
          <div class="box box-warning">
                <div class="box-header with-border">
                  <h3 class="box-title">ویرایش بخش</h3>
                </div><!-- /.box-header -->
                <div class="box-body">
                  <form method="POST" action="" autocomplete="off">
                  
                  
                  	@if(count($errors))
			<div class="alert alert-danger">
				<strong>اخطار!</strong> لطفا اطلاعات را به درستی وارد نمایید.
				<br/>
				<ul>
					@foreach($errors->all() as $error)
					<li>{{ $error }}</li>
					@endforeach
				</ul>
			</div>
		@endif
                  
                  
                  
                    
                    
   
<div class="form-group {{ $errors->has('cat') ? 'has-error' : '' }}">               
 @if ($errors->has('cat'))                 
<label class="control-label" for="inputError"><i class="fa fa-times-circle-o"></i>نام منطقه</label>
@else 
 <label class="control-label" for="">نام منطقه</label> 
@endif
 
<input type="text" class="form-control" id="cat" name="cat"  placeholder="نام منطقه"  value="{{$admins->areaagancy_name}}" disabled="disabled"> 
                    </div>     
   
   
   
<div class="form-group {{ $errors->has('groupname') ? 'has-error' : '' }}">               
 @if ($errors->has('groupname'))                 
<label class="control-label" for="inputError"><i class="fa fa-times-circle-o"></i>نام بخش</label>
@else 
 <label class="control-label" for="">نام بخش</label> 
@endif
 
<input type="text" class="form-control" id="groupname" name="groupname" placeholder="نام بخش"  value="{{$admins->aria_name}}">
                    </div>     
   
   

                
                
                     <input type="hidden" name="_token" value="{{ csrf_token() }}">
   					<div class="row">
       					<div class="col-xs-12">
       <button class="btn btn-primary btn-block btn-flat">ویرایش</button>
       
            </div> 
          </div>






                  </form>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
              	
              </div>
              <div class="col-md-3"></div>
       
          </div>
          </section>

@stop

    
