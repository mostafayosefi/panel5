
@extends('superadmin.layoutsuperadmin')

@section('title')
<title>ویرایش کاربر </title>
@stop 
 
@section('superadmin')

        <section class="content-header">
          <h1>
           پنل
            <small> سوپر ادمین</small>
          </h1>
          <ol class="breadcrumb">
   			<li><a href="{{ url('/superadmin/panel') }}"><i class="fa fa-dashboard"></i>پنل</a></li>
            <li><a href="{{ url('/superadmin/viewsusers') }}">مشاهده کاربران</a></li>
            <li class="active">ویرایش اطلاعات کاربر </li>
          </ol>
        </section>
        
      <script src="{{env('APP_URL')}}/build/style/uploadcssjs/jquery.js"></script> 
    <link href="{{env('APP_URL')}}/build/style/uploadcssjs/dropzone.min.css" rel="stylesheet">
     <script src="{{env('APP_URL')}}/build/style/uploadcssjs/dropzone.min.js"></script>
    
    
  
    


        <section class="content">
          <div class="row">
            <div class="col-xs-12">
              <div class="box">


 
 
 
 
 
 
 
 
 
      <header class="panel-heading summary-head"   >
                                <h4>پروفایل</h4>
                                <p>ویرایش مشخصات کاربر</p>
                        
                          </header>
	
	

 <?php  $i=1;    ?>                   
@foreach ($admins as $admin)

  <div class="col-lg-12">
  
    <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">مشخصات کاربر</h3>
              <div class="box-tools pull-right">
                <button class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse"><i class="fa fa-minus"></i></button>
                <button class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <div class="box-body">
  
    <div class="col-lg-4 col-xs-12"> 
    	<div class="ch-info">
							</br>
								<p>کد کاربر:{{$admin->user_ncode}}</p>
								<p>نام کاربری:{{$admin->user_username}}</p>
								<p>نام و نام خانوادگی:{{$admin->user_name}}</p>
								<p>تلفن:{{$admin->user_tell}}</p>
								<p>ایمیل:{{$admin->user_email}}</p>
								<p>آدرس:{{$admin->user_adres}}</p>
  
							</div>
                
  </div>
  <div class="col-lg-4 col-xs-12">   	
@if ($admin->user_img)
<img src="{{env('APP_URL')}}/public/images/{{$admin->user_img}}" class="img-circle" alt="User Image" width="128"  height="128"  /> 
@else
<img src="{{env('APP_URL')}}/build/style/img/user2x.png" class="img-circle" alt="User Image" width="128"  height="128"  /> 
@endif
  <div id="res"></div>
  </div>    
 <div class="col-lg-4 col-xs-12">  
   
                    @if($admin->user_active == '1') 
                    <div class="callout callout-success">
                    <h4>حساب کاربری فعال است</h4>
                    <p>حساب کاربری شما قبلا فعال شده است  </p>
<center><a href="rej/{{$admin->id}}"  style="color: #ffffff"><button type="button" class="btn btn-warning">غیرفعال</button></a></center>
                  </div> 
 @elseif($admin->user_active != '1')
 <div class="callout callout-warning">
                    <h4>حساب کاربری غیرفعال است</h4>
                    <p>جهت فعال کردن روی دکمه زیر کلیک نمایید </p>
 <center><a href="acc/{{$admin->id}}"  style="color: #ffffff"><button type="button" class="btn btn-success">فعال</button></a></center>                                     
</div> 
@endif

<p>تاریخ ثبت نام:<br>{{jDate::forge($admin->user_createdatdate)->format('l d F Y ساعت H:i a')}}</p>
<p>IP کاربر:<br>{{$admin->user_ip}}</p>
								<p>تاریخ آخرین ورود:<br>
								@if($admin->user_loginatdate)
								{{jDate::forge($admin->user_loginatdate)->format('l d F Y ساعت H:i a')}}
								@elseif(empty($admin->user_loginatdate))
								کاربر هنوز وارد پنل کاربری خود نشده است
								@endif
								</p>
								
								
								
<div id="reas"></div>
</div></div></div></div>

<div class="col-lg-12">
                                <section class="panel">
                                    <header class="panel-heading tab-bg-dark-navy-blue">
                                        <ul class="nav nav-tabs nav-justified ">
                                            <li class="active">
                                                <a href="#popular" data-toggle="tab">مشخصات
                                              </a>
                                            </li>
                                    
                                            <li class="">
                                                <a href="#recent" data-toggle="tab">تصویر پروفایل
                                              </a>
                                            </li>
                                    
                                            <li class="">
                                                <a href="#pass" data-toggle="tab">رمزعبور
                                              </a>
                                            </li>
                                        </ul>
                                    </header>
                                    <div class="panel-body">
                                        <div class="tab-content tasi-tab">
                                            <div class="tab-pane active" id="popular"> 
   <div class="col-lg-6">                                              

      <form method="POST" action=""  >
                  
                  
                  	@if(count($errors))
			<div class="alert alert-danger">
				<strong>اخطار!</strong>
				<br />
				 لطفا اطلاعات را به درستی وارد نمایید.
				<br/>
				<ul>
					@foreach($errors->all() as $error)
					<li>{{ $error }}</li>
					@endforeach
				</ul>
			</div>
		@endif
       
   
<div class="form-group {{ $errors->has('name') ? 'has-error' : '' }}">               
 @if ($errors->has('name'))                 
<label class="control-label" for="inputError"><i class="fa fa-times-circle-o"></i> نام و نام خانوادگی را بصورت صحیح وارد کنید</label>
@else 
 <label class="control-label" for="">نام و نام خانوادگی</label>   
@endif
<input type="text" class="form-control" id="name" name="name" placeholder="نام و نام خانوادگی "  @if ($admin->user_name) value="{{$admin->user_name}}"@else value="{{ old('name') }}" @endif >
</div>         
   
        
     
       
   
<div class="form-group {{ $errors->has('tell') ? 'has-error' : '' }}">               
 @if ($errors->has('tell'))                 
<label class="control-label" for="inputError"><i class="fa fa-times-circle-o"></i>شماره تلفن را بصورت صحیح وارد کنید</label>
@else 
 <label class="control-label" for="">تلفن</label> 
@endif
<input type="text" class="form-control" id="tell" name="tell" placeholder="تلفن " @if ($admin->user_tell) value="{{$admin->user_tell}}"@else value="{{ old('tell') }}" @endif >
                    </div> 
       
   
<div class="form-group {{ $errors->has('email') ? 'has-error' : '' }}">               
 @if ($errors->has('email'))                 
<label class="control-label" for="inputError"><i class="fa fa-times-circle-o"></i>ایمیل را بصورت صحیح وارد کنید</label>
@else 
 <label class="control-label" for="">ایمیل</label> 
@endif
<input type="text" class="form-control" id="email" name="email" placeholder="ایمیل " @if ($admin->user_email) value="{{$admin->user_email}}"@else value="{{ old('email') }}" @endif >
                    </div>  
       
   
<div class="form-group {{ $errors->has('adres') ? 'has-error' : '' }}">               
 @if ($errors->has('adres'))                 
<label class="control-label" for="inputError"><i class="fa fa-times-circle-o"></i>آدرس را بصورت صحیح وارد کنید</label>
@else 
 <label class="control-label" for="">آدرس</label> 
@endif
<textarea  class="form-control" id="adres" name="adres" placeholder="آدرس " rows="4">
	@if ($admin->user_adres)  {{$admin->user_adres}} @else  {{ old('adres') }} @endif 
</textarea>
                    </div>     
   
   
   
   
   
   
   
   
   
       
       
  
                          
			   
						                                    
   <br>                     
		
                     <input type="hidden" name="_token" value="{{ csrf_token() }}">
   					<div class="row">
       					<div class="col-xs-12">
       <button class="btn btn-primary btn-block btn-flat">ویرایش اطلاعات</button>
       
            </div> 
          </div> 
               
               </form>     
                                     </div>  
                                               
                                            </div>
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
<div class="tab-pane " id="recent">
  
  
      
      
                                    
         <div class="col-md-12">
            <h1>آپلود تصویر پروفایل</h1>
            <center>
 @if ($admin->user_img)
<img src="{{env('APP_URL')}}/public/images/{{$admin->user_img}}" class="img-circle" alt="User Image" width="256"  height="256"  /> 
@else
<img src="{{env('APP_URL')}}/build/style/img/user2x.png" class="img-circle" alt="User Image" width="256"  height="256"  /> 
@endif
</center>
            {!! Form::open([ 'route' => [ 'dropzone.storeuser' ], 'files' => true, 'enctype' => 'multipart/form-data', 'class' => 'dropzone', 'id' => 'image-upload' ]) !!}
            <div>
                <h3>برای آپلود تصویر پروفایل کلیک نمایید</h3>
            </div>
            {!! Form::close() !!}
        </div>   
    
</div>
		                            

<div class="tab-pane " id="pass">
<div class="col-md-12">
            <h3>رمزعبور</h3>
   <div class="col-lg-6">                                              
             {!! Form::open([ 'route' => [ 'securityystud' ], 'files' => true, 'enctype' => 'multipart/form-data' ]) !!}         
                  
                  	@if(count($errors))
			<div class="alert alert-danger">
				<strong>اخطار!</strong>
				<br />
				 لطفا اطلاعات را به درستی وارد نمایید.
				<br/>
				<ul>
					@foreach($errors->all() as $error)
					<li>{{ $error }}</li>
					@endforeach
				</ul>
			</div>
		@endif
       

                    <div class="form-group {{ $errors->has('userpassword') ? 'has-error' : '' }}">
 @if ($errors->has('userpassword'))                 
<label class="control-label" for="inputError"><i class="fa fa-times-circle-o"></i>رمز را بصورت صحیح وارد کنید</label>
@endif
<input type="password" class="form-control" id="userpassword" name="userpassword" placeholder="رمزعبور"  value="{{ old('userpassword') }}">
                    </div>




                    <div class="form-group {{ $errors->has('userpassword') ? 'has-error' : '' }}">
 @if ($errors->has('userpassword'))                 
<label class="control-label" for="inputError"><i class="fa fa-times-circle-o"></i>رمزعبور با تکرار آن مطابقت ندارد</label>
@endif
<input type="password" class="form-control" id="userpassword_confirmation" name="userpassword_confirmation" placeholder="رمزعبور"  value="{{ old('userpassword_confirmation') }}">
                    </div>

	   
						                                    
   <br>                     
		
<input type="hidden" class="form-control" id="tell" name="tell" value="{{$admin->user_tell}}" >
<input type="hidden" class="form-control" id="email" name="email" value="{{$admin->user_email}}" >
                     <input type="hidden" name="_token" value="{{ csrf_token() }}">
   					<div class="row">
       					<div class="col-xs-12">
       <button class="btn btn-primary btn-block btn-flat">ویرایش رمزعبور</button>
       
            </div> 
          </div> 
               
 {!! Form::close() !!}
               
                  
      </div>
            
            
            
            </div>
            
            
   <div class="col-lg-6">  </div>
</div>















						
			
                                                </br>
                                                
                                                
                                                
                                         
                                            </div>
                                            
                                            

                                            
                                            
                                        </div>         
          
 @endforeach         
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          </section>
          

@stop

