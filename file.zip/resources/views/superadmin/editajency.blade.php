
@extends('superadmin.layoutsuperadmin')

@section('title')
<title>ویرایش آژانس</title>
@stop 
 
@section('superadmin')

        <section class="content-header">
           <h1>
           پنل
            <small> سوپر ادمین</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="{{ url('/superadmin/panel') }}"><i class="fa fa-dashboard"></i> پنل</a></li>
            <li><a href="{{ url('/superadmin/viewsagencys') }}">مشاهده آژانس ها</a></a></li>
            <li class="active">ویرایش</li>
          </ol>
        </section>
        
          
      <script src="{{env('APP_URL')}}/build/style/uploadcssjs/jquery.js"></script> 
    <link href="{{env('APP_URL')}}/build/style/uploadcssjs/dropzone.min.css" rel="stylesheet">
     <script src="{{env('APP_URL')}}/build/style/uploadcssjs/dropzone.min.js"></script>
  
    
    
<!--
    <script src="http://demo.itsolutionstuff.com/plugin/jquery.js"></script>   
    <link href="https://cdnjs.cloudflare.com/ajax/libs/dropzone/4.0.1/min/dropzone.min.css" rel="stylesheet">
     <script src="https://cdnjs.cloudflare.com/ajax/libs/dropzone/4.2.0/min/dropzone.min.js"></script>
-->

        <section class="content">
          <div class="row">
            <div class="col-xs-12">
              <div class="box">


 
 
 
 
 
 
 
 
 
      <header class="panel-heading summary-head"   >
                     <h4>پروفایل</h4>
             <p>ویرایش مشخصات آژانس </p>
                        
                          </header>
	
	

 <?php  $i=1;    ?>                   
@foreach ($admins as $admin)

  <div class="col-lg-12">
  
    <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">مشخصات</h3>
              <div class="box-tools pull-right">
                <button class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse"><i class="fa fa-minus"></i></button>
                <button class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <div class="box-body">
  
    <div class="col-lg-4 col-xs-12"> 
    	<div class="ch-info">
							</br>
								<p>نام کاربری:{{$admin->ajency_username}}</p>
								<p>نام آژانس:{{$admin->ajency_name}}</p>
								<p>نام مدیر آژانس:{{$admin->ajency_namemng}}</p>
								<p>تلفن:{{$admin->ajency_tell}}</p>
								<p>ایمیل:{{$admin->ajency_email}}</p>
								<p>آدرس:{{$admin->ajency_adres}}</p>
 
				 
								
								
							</div>
                  
                  
  </div>
  <div class="col-lg-4 col-xs-12">   	
@if ($admin->ajency_img)
<img src="{{env('APP_URL')}}/public/images/{{$admin->ajency_img}}" class="img-circle" alt="User Image" width="128"  height="128"  /> 
@else
<img src="{{env('APP_URL')}}/build/style/img/user2x.png" class="img-circle" alt="User Image" width="128"  height="128"  /> 
@endif
  <div id="res"></div>
  </div>    
 <div class="col-lg-4 col-xs-12">  
   
                    @if($admin->ajency_active == '1') 
                    <div class="callout callout-success">
                    <h4>فعال</h4>
<center><a href="rej/{{$admin->id}}"   ><span class="label label-warning">غیرفعال کردن</span></a></center>
                  </div> 
 @elseif($admin->ajency_active != '1')
 <div class="callout callout-warning">
                    <h4>غیرفعال</h4>
 <center><a href="acc/{{$admin->id}}"   ><span class="label label-success">فعال کردن</span></a></center>                                     
</div> 
@endif

<p>تاریخ ثبت نام:<br>
 
{{jDate::forge($admin->ajency_createdatdate)->format('l d F Y ساعت H:i a')}}
 
</p>
<p>IP  :<br>{{$admin->ajency_ip}}</p>
								<p>آخرین ورود:<br>
								@if($admin->ajency_loginatdate) 
								{{jDate::forge($admin->ajency_loginatdate)->format('l d F Y ساعت H:i a')}} 
								@elseif(empty($admin->ajency_loginatdate))
								داده ای وجود ندارد
								@endif
								</p>
<div id="reas"></div>
</div></div></div></div>

<div class="col-lg-12">
                                <section class="panel">
                                    <header class="panel-heading tab-bg-dark-navy-blue">
                                        <ul class="nav nav-tabs nav-justified ">
                                            <li class="active">
                                                <a href="#popular" data-toggle="tab">مشخصات
                                              </a>
                                            </li>
                                    
                                            <li class="">
                                                <a href="#recent" data-toggle="tab">عکس
                                              </a>
                                            </li>
                                    
                                            <li class="">
                                                <a href="#pass" data-toggle="tab">رمزعبور
                                              </a>
                                            </li>
                                        </ul>
                                    </header>
                                    <div class="panel-body">
                                        <div class="tab-content tasi-tab">
                                            <div class="tab-pane active" id="popular"> 
   <div class="col-lg-6">                                              

      <form method="POST" action=""  >
                  
                  
               
                  	@if(count($errors))
			<div class="alert alert-danger">
				<strong>اخطار!</strong> لطفا اطلاعات را به درستی وارد نمایید.
				<br/>
				<ul>
					@foreach($errors->all() as $error)
					<li>{{ $error }}</li>
					@endforeach
				</ul>
			</div>
		@endif
                  
                  
   
<div class="form-group {{ $errors->has('nameajency') ? 'has-error' : '' }}">               
 @if ($errors->has('nameajency'))                 
<label class="control-label" for="inputError"><i class="fa fa-times-circle-o"></i> نام آژانس</label>
@else 
 <label class="control-label" for="">نام آژانس</label>   
@endif
<input type="text" class="form-control"   name="nameajency" placeholder="نام آژانس "  @if ($admin->ajency_name) value="{{$admin->ajency_name}}"@else value="{{ old('nameajency') }}" @endif >
</div>       
   
   
<div class="form-group {{ $errors->has('nameajencymng') ? 'has-error' : '' }}">               
 @if ($errors->has('nameajencymng'))                 
<label class="control-label" for="inputError"><i class="fa fa-times-circle-o"></i> نام مدیر آژانس</label>
@else 
 <label class="control-label" for="">نام مدیر آژانس</label>   
@endif
<input type="text" class="form-control"  name="nameajencymng" placeholder="نام مدیر آژانس "  @if ($admin->ajency_namemng) value="{{$admin->ajency_namemng}}"@else value="{{ old('nameajencymng') }}" @endif >
</div>   
       
   
<div class="form-group {{ $errors->has('tell') ? 'has-error' : '' }}">               
 @if ($errors->has('tell'))                 
<label class="control-label" for="inputError"><i class="fa fa-times-circle-o"></i>تلفن</label>
@else 
 <label class="control-label" for="">تلفن</label> 
@endif
<input type="text" class="form-control" id="tell" name="tell" placeholder="تلفن " @if ($admin->ajency_tell) value="{{$admin->ajency_tell}}"@else value="{{ old('tell') }}" @endif >
                    </div> 
       
   
<div class="form-group {{ $errors->has('email') ? 'has-error' : '' }}">               
 @if ($errors->has('email'))                 
<label class="control-label" for="inputError"><i class="fa fa-times-circle-o"></i>ایمیل</label>
@else 
 <label class="control-label" for="">ایمیل</label> 
@endif
<input type="text" class="form-control" id="email" name="email" placeholder="ایمیل " @if ($admin->ajency_email) value="{{$admin->ajency_email}}"@else value="{{ old('email') }}" @endif >
                    </div>  
       
   
<div class="form-group {{ $errors->has('adres') ? 'has-error' : '' }}">               
 @if ($errors->has('adres'))                 
<label class="control-label" for="inputError"><i class="fa fa-times-circle-o"></i>آدرس</label>
@else 
 <label class="control-label" for="">آدرس</label> 
@endif
<textarea  class="form-control" id="adres" name="adres" placeholder="آدرس " rows="4">
	@if ($admin->ajency_adres)  {{$admin->ajency_adres}} @else  {{ old('adres') }} @endif 
</textarea>
                    </div>     
   
   
   
   
   
   
   
   
   
       
       
  
                          
			   
						                                    
   <br>                     
		
                     <input type="hidden" name="_token" value="{{ csrf_token() }}">
   					<div class="row">
       					<div class="col-xs-12">
       <button class="btn btn-primary btn-block btn-flat">ویرایش</button>
       
            </div> 
          </div> 
               
               </form>     
                                     </div>  
                                               
                                            </div>
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
<div class="tab-pane " id="recent">
  
  
      
      
                                    
         <div class="col-md-12">
            <h1>آپلود </h1>
            <center>
 @if ($admin->ajency_img)
<img src="{{env('APP_URL')}}/public/images/{{$admin->ajency_img}}" class="img-circle" alt="User Image" width="256"  height="256"  /> 
@else
<img src="{{env('APP_URL')}}/build/style/img/user2x.png" class="img-circle" alt="User Image" width="256"  height="256"  /> 
@endif
</center>
            {!! Form::open([ 'route' => [ 'dropzone.storeajency' ], 'files' => true, 'enctype' => 'multipart/form-data', 'class' => 'dropzone', 'id' => 'image-upload' ]) !!}
            <div>
                <h3>برای آپلود تصویر کلیک نمایید</h3>
            </div>
            {!! Form::close() !!}
        </div>   
    
</div>
		                            

<div class="tab-pane " id="pass">
<div class="col-md-12">
            <h3>رمزعبور</h3>
   <div class="col-lg-6">                                              
             {!! Form::open([ 'route' => [ 'securityyajency' ], 'files' => true, 'enctype' => 'multipart/form-data' ]) !!}         
                  
                 
   
                  	@if(count($errors))
			<div class="alert alert-danger">
				<strong>اخطار!</strong> لطفا اطلاعات را به درستی وارد نمایید.
				<br/>
				<ul>
					@foreach($errors->all() as $error)
					<li>{{ $error }}</li>
					@endforeach
				</ul>
			</div>
		@endif

                    <div class="form-group {{ $errors->has('userpassword') ? 'has-error' : '' }}">
 @if ($errors->has('userpassword'))                 
<label class="control-label" for="inputError"><i class="fa fa-times-circle-o"></i>رمزعبور</label>
@endif
<input type="password" class="form-control" id="userpassword" name="userpassword" placeholder="رمزعبور"  value="{{ old('userpassword') }}">
                    </div>




                    <div class="form-group {{ $errors->has('userpassword') ? 'has-error' : '' }}">
 @if ($errors->has('userpassword'))                 
<label class="control-label" for="inputError"><i class="fa fa-times-circle-o"></i>تکرار رمزعبور</label>
@endif
<input type="password" class="form-control" id="userpassword_confirmation" name="userpassword_confirmation" placeholder="تکرار رمزعبور"   value="{{ old('userpassword_confirmation') }}">
                    </div>

	   
						                                    
   <br>  

<input type="hidden" class="form-control" id="tell" name="tell" value="{{$admin->ajency_tell}}" >
<input type="hidden" class="form-control" id="email" name="email" value="{{$admin->ajency_email}}" >
  


 
                          
		
                     <input type="hidden" name="_token" value="{{ csrf_token() }}">
   					<div class="row">
       					<div class="col-xs-12">
       <button class="btn btn-primary btn-block btn-flat">ویرایش</button>
       
            </div> 
          </div> 
               
 {!! Form::close() !!}
               
                  
      </div>
            
            
            
            </div>
            
            
   <div class="col-lg-6">  </div>
</div>















						
			
                                                </br>
                                                
                                                
                                                
                                         
                                            </div>
                                            
                                            

                                            
                                            
                                        </div>         
          
 @endforeach         
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          </section>
          

@stop

