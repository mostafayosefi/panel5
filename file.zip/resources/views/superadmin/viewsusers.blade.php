@extends('superadmin.layoutsuperadmin')

@section('title')
<title>مشاهده کاربران</title>
@stop

 
@section('superadmin')

        <section class="content-header">
          <h1>
           پنل
            <small> سوپر ادمین</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="{{ url('/superadmin/panel') }}"><i class="fa fa-dashboard"></i>پنل</a></li>
            <li><a href="{{ url('/superadmin/viewsusers') }}">مشاهده کاربران</a></li>
          </ol>
        </section>




      <!-- Main content -->
        <section class="content">

 <div class="row">
          
          
            <div class="col-xs-12">
              
              

              <div class="box">
                <div class="box-header">
                  <h3 class="box-title">لیست کاربران</h3>
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table id="example1" class="table table-bordered table-striped">
@if   (empty ($admins))                 
<tr>داده ای وجود ندارد<tr>
@elseif ($admins)     
                    <thead>
                      <tr>
                        <th>ردیف</th>
                        <th>نام کاربری</th> 
                        <th>تاریخ ثبت نام</th>
                        <th>وضعیت</th>
                        <th>حذف</th>
                        <th>ورود</th>
                      </tr>
                    </thead>
                    <tbody>
             
                    
 <?php  $i=1;  ?>                   
@foreach ($admins as $admin)
<tr>
                        <td>{{$i++}} </td>
                        <td>{{$admin->user_username}} </td> 
                        <td>{{jDate::forge($admin->user_createdatdate)->format('Y/m/d ساعت H:i a')}}</td>
@if($admin->user_active == '1')                       
<td><a href="viewsusers/edituser/{{$admin->id}}" > <span class="label label-success">فعال</span></a></td>
@elseif($admin->user_active != '1')
<td><a href="viewsusers/edituser/{{$admin->id}}"   ><span class="label label-warning">غیرفعال</span></a></td>
@endif

 <td><a href="viewsusers/delet/{{$admin->id}}"  > <span class="label label-danger">حذف</span></a></td>
<td><a href="viewsusers/loginuser/{{$admin->id}}"  target="_blank"> <span class="label label-info">ورود به پنل</span></a></td>
</tr>
@endforeach

    
                    </tbody>
                    <tfoot>
                      <tr>
                        <th>ردیف</th>
                        <th>نام کاربری</th> 
                        <th>تاریخ ثبت نام</th>
                        <th>وضعیت</th>
                        
                        <th>حذف</th>
                        <th>ورود</th>
                      </tr>
                    </tfoot>
                    @endif
                  </table>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
            </div><!-- /.col -->
           
            
        </section><!-- /.content -->
        

<style> @media only screen and (min-width: 30px) and (max-width: 2860px) { .box-body { overflow-x: scroll; }  </style>
        
        
@stop

