
@extends('superadmin.layoutsuperadmin')

@section('title')
<title>ثبت آژانس</title>
@stop
 
@section('superadmin')

        <section class="content-header">
          <h1>
           پنل
            <small> سوپر ادمین</small>
          </h1>
          <ol class="breadcrumb">
   			<li><a href="{{ url('/superadmin/panel') }}"><i class="fa fa-dashboard"></i>پنل</a></li>
            <li><a href="{{ url('/superadmin/addagency') }}">ثبت آژانس</a></li>
            <li class="active">ثبت</li>
          </ol>
        </section>
        
        <section class="content">
          <div class="row">
         <div class="col-md-3"></div>
         <div class="col-md-6">
          <div class="box box-warning">
                <div class="box-header with-border">
                  <h3 class="box-title">ثبت آژانس</h3>
                </div><!-- /.box-header -->
                <div class="box-body">
                  <form method="POST" action="" autocomplete="off">
                  
                  
               
                  	@if(count($errors))
			<div class="alert alert-danger">
				<strong>اخطار!</strong> لطفا اطلاعات را به درستی وارد نمایید.
				<br/>
				<ul>
					@foreach($errors->all() as $error)
					<li>{{ $error }}</li>
					@endforeach
				</ul>
			</div>
		@endif
                  
                  
                  
                    
                    
                    


                    <div class="form-group {{ $errors->has('username') ? 'has-error' : '' }}">
 @if ($errors->has('username'))                 
<label class="control-label" for="inputError"><i class="fa fa-times-circle-o"></i>نام کاربری را به صورت صحیح وارد نمایید</label>
@endif
<input type="text" class="form-control" id="username" name="username" placeholder="نام کاربری "  value="{{ old('username') }}">
                    </div> 


                    <div class="form-group {{ $errors->has('userpassword') ? 'has-error' : '' }}">
 @if ($errors->has('userpassword'))                 
<label class="control-label" for="inputError"><i class="fa fa-times-circle-o"></i>رمز را بصورت صحیح وارد کنید</label>
@endif
<input type="password" class="form-control" id="userpassword" name="userpassword" placeholder="رمزعبور"  value="{{ old('userpassword') }}">
                    </div>




                    <div class="form-group {{ $errors->has('userpassword') ? 'has-error' : '' }}">
 @if ($errors->has('userpassword'))                 
<label class="control-label" for="inputError"><i class="fa fa-times-circle-o"></i>رمزعبور با تکرار آن مطابقت ندارد</label>
@endif
<input type="password" class="form-control" id="userpassword_confirmation" name="userpassword_confirmation" placeholder="رمزعبور"  value="{{ old('userpassword_confirmation') }}">
                    </div>


                
                
                     <input type="hidden" name="_token" value="{{ csrf_token() }}">
   					<div class="row">
       					<div class="col-xs-12">
       <button class="btn btn-primary btn-block btn-flat">ثبت</button>
       
            </div> 
          </div>






                  </form>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
              	
              </div>
              <div class="col-md-3"></div>
       
          </div>
          </section>

@stop

    
