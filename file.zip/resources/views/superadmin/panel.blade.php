
@extends('superadmin.layoutsuperadmin')

@section('title')
<title>پنل </title>
@stop

 
@section('superadmin')

        <section class="content-header">
          <h1>
           پنل
            <small> سوپر ادمین</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="{{ url('/superadmin/panel') }}"><i class="fa fa-dashboard"></i>پنل</a></li>
            <li><a href="">مشاهده پنل</a></li>
          </ol>
        </section>






        <section class="content">

 
     
                      
                         <div class="row">
                         
              <div class="col-lg-3 col-xs-6">
              <!-- small box -->
              <div class="small-box bg-green">
                <div class="inner">
                  <h3>{{$countuser}}&nbsp;کاربر</h3>
                  <p>کاربران </p>
                </div>
                <div class="icon">
                  <i class="ion ion-users"></i>
                </div>
                <a href="{{ url('/superadmin/viewsusers') }}" class="small-box-footer">اطلاعات بیشتر <i class="fa fa-arrow-circle-left"></i></a>
              </div>
            </div><!-- ./col -->  
            
            
            
                                     
              <div class="col-lg-3 col-xs-6">
              <!-- small box -->
              <div class="small-box bg-blue">
                <div class="inner">
                  <h3>{{$countajency}}&nbsp;آژانس املاک</h3>
                  <p>آژانسهای املاک </p>
                </div>
                <div class="icon">
                  <i class="ion ion-users"></i>
                </div>
                <a href="{{ url('/superadmin/viewsagencys') }}" class="small-box-footer">اطلاعات بیشتر <i class="fa fa-arrow-circle-left"></i></a>
              </div>
            </div><!-- ./col -->  
                              
                              
                                     
              <div class="col-lg-3 col-xs-6">
              <!-- small box -->
              <div class="small-box bg-yellow">
                <div class="inner">
                  <h3>{{$countareaagancy}}&nbsp;منطقه</h3>
                  <p>مناطق </p>
                </div>
                <div class="icon">
                  <i class="ion ion-users"></i>
                </div>
                <a href="{{ url('/superadmin/viewsreaagancy') }}" class="small-box-footer">اطلاعات بیشتر <i class="fa fa-arrow-circle-left"></i></a>
              </div>
            </div><!-- ./col -->   
                              
                              
                                     
              <div class="col-lg-3 col-xs-6">
              <!-- small box -->
              <div class="small-box bg-red">
                <div class="inner">
                  <h3>{{$countaria}}&nbsp;بخش</h3>
                  <p>بخشهای مناطق </p>
                </div>
                <div class="icon">
                  <i class="ion ion-users"></i>
                </div>
                <a href="{{ url('/superadmin/viewssubareaagancy') }}" class="small-box-footer">اطلاعات بیشتر <i class="fa fa-arrow-circle-left"></i></a>
              </div>
            </div><!-- ./col -->    
   
                         </div>
                      
                      
            </section>












@stop

