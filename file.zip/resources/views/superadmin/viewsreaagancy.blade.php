@extends('superadmin.layoutsuperadmin')

@section('title')
<title>مشاهده مناطق</title>
@stop

 
@section('superadmin')

        <section class="content-header">
          <h1>
           پنل
            <small> سوپر ادمین</small>
          </h1>
          <ol class="breadcrumb">
            <li><a href="{{ url('/superadmin/panel') }}"><i class="fa fa-dashboard"></i>پنل</a></li>
            <li><a href="{{ url('/superadmin/viewsreaagancy') }}">مشاهده مناطق</a></li>
          </ol>
        </section>




      <!-- Main content -->
 <section class="content">
      <div class="row">
        <div class="col-xs-12">



              <div class="box">
                <div class="box-header">
                  <h3 class="box-title">لیست مناطق</h3>
                </div><!-- /.box-header -->
                <div class="box-body">
                  <table id="example1" class="table table-bordered table-striped">
@if   (empty ($admins))                 
<tr>داده ای وجود ندارد<tr>
@elseif ($admins)     
                    <thead>
                      <tr>
                        <th>ردیف</th>
                        <th>نام منطقه</th> 
                        <th>ویرایش</th>   
                        <th>حذف</th>
                      </tr>
                    </thead>
                    <tbody>
             
                    
 <?php  $i=1; $date = jDate::forge('last sunday')->format('%B %d، %Y');  ?>                   
@foreach ($admins as $admin)
<tr>
                        <td>{{$i++}} </td>
                        <td>{{$admin->areaagancy_name}} </td>                  
 
 
      
<td><a href="viewsreaagancy/edit/{{$admin->areaagancy_id}}"><span class="label label-success">ویرایش</span></a></td> 
 
 

<td><a href="viewsreaagancy/delet/{{$admin->areaagancy_id}}"><span class="label label-danger">حذف</span></a></td> 
 
</tr>
@endforeach

    
                    </tbody>
                    <tfoot>
                      <tr>
                        <th>ردیف</th>
                        <th>نام منطقه</th>
                        <th>ویرایش</th>    
                        <th>حذف</th>
                      </tr>
                    </tfoot>
                    @endif
                  </table>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
            </div> 
          </div><!-- /.row -->
        </section><!-- /.content -->
@stop

