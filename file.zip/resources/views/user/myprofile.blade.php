
@extends('user.layoutuser')

@section('title')
<title>{{$lngmenu->lng_wmyprofile}} </title>
@stop 
 
@section('superadmin')

        <section class="content-header">
          <h1>
           {{$lngmenu->lng_wpanel}}
            <small>{{$lngmenu->lng_wuser}}</small>
          </h1>
          <ol class="breadcrumb">
   			<li><a href="{{ url('/user/panel') }}"><i class="fa fa-dashboard"></i>{{$lngmenu->lng_wpanel}}</a></li>
            <li><a href="{{ url('/user/myprofile/edit') }}">{{$lngmenu->lng_wmyprofile}}</a></li>
            <li class="active">{{$lngmenu->lng_wedit}}</li>
          </ol>
        </section>
        
  
  
          
      <script src="{{env('APP_URL')}}/build/style/uploadcssjs/jquery.js"></script> 
    <link href="{{env('APP_URL')}}/build/style/uploadcssjs/dropzone.min.css" rel="stylesheet">
     <script src="{{env('APP_URL')}}/build/style/uploadcssjs/dropzone.min.js"></script>
  
    
  
    
<!--
    <script src="http://demo.itsolutionstuff.com/plugin/jquery.js"></script>   
    <link href="https://cdnjs.cloudflare.com/ajax/libs/dropzone/4.0.1/min/dropzone.min.css" rel="stylesheet">
     <script src="https://cdnjs.cloudflare.com/ajax/libs/dropzone/4.2.0/min/dropzone.min.js"></script>
-->

        <section class="content">
          <div class="row">
            <div class="col-xs-12">
              <div class="box">


 
 
 
 
 
 
 
 
 
      <header class="panel-heading summary-head"   >
                                <h4>{{$lngmenu->lng_wmyprofile}}</h4>
                                <p>{{$lngmenu->lng_wedit}}</p>
                        
                          </header>
	
	

 <?php  $i=1;    ?>                   
@foreach ($admins as $admin)

  <div class="col-lg-12">
  
    <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">{{$lngmenu->lng_wspecifi}}</h3>
              <div class="box-tools pull-right">
                <button class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse"><i class="fa fa-minus"></i></button>
                <button class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <div class="box-body">
  
    <div class="col-lg-4 col-xs-12"> 
    	<div class="ch-info">
							</br>								
								<p>کد کاربر:{{$admin->user_ncode}}</p>
								<p>{{$lngmenu->lng_wusername}}:{{$admin->user_username}}</p>
								<p>{{$lngmenu->lng_wname}}:{{$admin->user_name}}</p>
								<p>{{$lngmenu->lng_wtell}}:{{$admin->user_tell}}</p>
								<p>{{$lngmenu->lng_wemail}}:{{$admin->user_email}}</p>
								<p>{{$lngmenu->lng_wadres}}:{{$admin->user_adres}}</p> 
 
 		
							</div>
                
  </div>
  <div class="col-lg-4 col-xs-12">   	
@if ($admin->user_img)
<img src="{{env('APP_URL')}}/public/images/{{$admin->user_img}}" class="img-circle" alt="User Image" width="128"  height="128"  /> 
@else
<img src="{{env('APP_URL')}}/build/style/img/user2x.png" class="img-circle" alt="User Image" width="128"  height="128"  /> 
@endif
  <div id="res"></div>
  </div>      
 <div class="col-lg-4 col-xs-12">  

                    @if($admin->user_active == '1') 
                    <div class="callout callout-success">
                    <h4>{{$lngmenu->lng_wactive}}</h4>


                  </div> 
 @elseif($admin->user_active != '1')
 <div class="callout callout-warning">
                    <h4>{{$lngmenu->lng_winactive}}</h4>

                                   
</div> 
@endif


   
<p>{{$lngmenu->lng_wcreatedatdate}}:<br>

								@if($lngmenu->lng_style=='style')
{{jDate::forge($admin->user_createdatdate)->format('l d F Y ساعت H:i a')}}
@else
{{$admin->user_createdatdate}}
@endif
</p>


<p>{{$lngmenu->lng_wrecentlogin}}:<br>
@if($lngmenu->lng_style=='style')
{{jDate::forge($admin->user_loginatdate)->format('l d F Y ساعت H:i a')}} @else {{$admin->user_loginatdate}} @endif
</p>
<p>{{$lngmenu->lng_wip}}:{{$admin->user_ip}}</p>

<div id="reas"></div>
</div></div></div></div>

<div class="col-lg-12">
                                <section class="panel">
                                    <header class="panel-heading tab-bg-dark-navy-blue">
                                        <ul class="nav nav-tabs nav-justified ">
                                            <li class="active">
                                                <a href="#popular" data-toggle="tab">{{$lngmenu->lng_wspecifi}}
                                              </a>
                                            </li>
                                    
                                            <li class="">
                                                <a href="#recent" data-toggle="tab">{{$lngmenu->lng_wimg}}
                                              </a>
                                            </li>
                                    
                                            <li class="">
                                                <a href="#pass" data-toggle="tab">{{$lngmenu->lng_wpassword}}
                                              </a>
                                            </li>
                                        </ul>
                                    </header>
                                    <div class="panel-body">
                                        <div class="tab-content tasi-tab">
                                            <div class="tab-pane active" id="popular"> 
   <div class="col-lg-6">                                              

      <form method="POST" action=""  >
                  
         
 
        @if(count($errors))
			<div class="alert alert-danger">
				<strong>{{$lngmenu->lng_werror}}!</strong> {{$lngmenu->lng_werrornot}}
				<br/>
				<ul>
					@foreach($errors->all() as $error)
					<li>{{ $error }}</li>
					@endforeach
				</ul>
			</div>
		@endif
                
   
<div class="form-group {{ $errors->has('name') ? 'has-error' : '' }}">               
 @if ($errors->has('name'))                 
<label class="control-label" for="inputError"><i class="fa fa-times-circle-o"></i> {{$lngmenu->lng_wname}}</label>
@else 
 <label class="control-label" for="">{{$lngmenu->lng_wname}}</label>   
@endif
<input type="text" class="form-control"   name="name" placeholder="{{$lngmenu->lng_wname}} "  @if ($admin->user_name) value="{{$admin->user_name}}"@else value="{{ old('name') }}" @endif >
</div>       
   
   
   
   
<div class="form-group {{ $errors->has('tell') ? 'has-error' : '' }}">               
 @if ($errors->has('tell'))                 
<label class="control-label" for="inputError"><i class="fa fa-times-circle-o"></i>{{$lngmenu->lng_wtell}}</label>
@else 
 <label class="control-label" for="">{{$lngmenu->lng_wtell}}</label> 
@endif
<input type="text" class="form-control" id="tell" name="tell" placeholder="{{$lngmenu->lng_wtell}} " @if ($admin->user_tell) value="{{$admin->user_tell}}"@else value="{{ old('tell') }}" @endif >
                    </div> 
       
   
<div class="form-group {{ $errors->has('email') ? 'has-error' : '' }}">               
 @if ($errors->has('email'))                 
<label class="control-label" for="inputError"><i class="fa fa-times-circle-o"></i>{{$lngmenu->lng_wemail}}</label>
@else 
 <label class="control-label" for="">{{$lngmenu->lng_wemail}}</label> 
@endif
<input type="text" class="form-control" id="email" name="email" placeholder="{{$lngmenu->lng_wemail}} " @if ($admin->user_email) value="{{$admin->user_email}}"@else value="{{ old('email') }}" @endif >
                    </div>  
       
   
<div class="form-group {{ $errors->has('adres') ? 'has-error' : '' }}">               
 @if ($errors->has('adres'))                 
<label class="control-label" for="inputError"><i class="fa fa-times-circle-o"></i>{{$lngmenu->lng_wadres}}</label>
@else 
 <label class="control-label" for="">{{$lngmenu->lng_wadres}}</label> 
@endif
<textarea  class="form-control" id="adres" name="adres" placeholder="{{$lngmenu->lng_wadres}} " rows="4">
	@if ($admin->user_adres)  {{$admin->user_adres}} @else  {{ old('adres') }} @endif 
</textarea>
                    </div>     
   
   
   
   
   
   
						                                    
   <br>                     
		
                     <input type="hidden" name="_token" value="{{ csrf_token() }}">
   					<div class="row">
       					<div class="col-xs-12">
       <button class="btn btn-primary btn-block btn-flat">{{$lngmenu->lng_wedit}}</button>
       
            </div> 
          </div> 
               
               </form>     
                                     </div>  
                                               
                                            </div>
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
<div class="tab-pane " id="recent">
  
  
      
      
                                    
         <div class="col-md-12">
             <h1>{{$lngmenu->lng_wupload}}</h1>
            <center>
 @if ($admin->user_img)
<img src="{{env('APP_URL')}}/public/images/{{$admin->user_img}}" class="img-circle" alt="User Image" width="256"  height="256"  /> 
@else
<img src="{{env('APP_URL')}}/build/style/img/user2x.png" class="img-circle" alt="User Image" width="256"  height="256"  /> 
@endif
</center>

            {!! Form::open([ 'route' => [ 'dropzone.storeuserprofile' ], 'files' => true, 'enctype' => 'multipart/form-data', 'class' => 'dropzone', 'id' => 'image-upload' ]) !!}
            <div>
                 <h3>{{$lngmenu->lng_wuploadclick}}</h3>
            </div>
            {!! Form::close() !!}
        </div>   
    
</div>
		                            

<div class="tab-pane " id="pass">
<div class="col-md-12">
            <h3>{{$lngmenu->lng_wpassword}}</h3>
   <div class="col-lg-6">                                              
             {!! Form::open([ 'route' => [ 'securityuserprofile' ], 'files' => true, 'enctype' => 'multipart/form-data' ]) !!}         
                  
 
        @if(count($errors))
			<div class="alert alert-danger">
				<strong>{{$lngmenu->lng_werror}}!</strong> {{$lngmenu->lng_werrornot}}
				<br/>
				<ul>
					@foreach($errors->all() as $error)
					<li>{{ $error }}</li>
					@endforeach
				</ul>
			</div>
		@endif
                

                    <div class="form-group {{ $errors->has('userpassword') ? 'has-error' : '' }}">
 @if ($errors->has('userpassword'))                 
<label class="control-label" for="inputError"><i class="fa fa-times-circle-o"></i>{{$lngmenu->lng_wpassword}}</label>
@endif
<input type="password" class="form-control" id="userpassword" name="userpassword" placeholder="{{$lngmenu->lng_wpassword}}"  value="{{ old('userpassword') }}">
                    </div>




                    <div class="form-group {{ $errors->has('userpassword') ? 'has-error' : '' }}">
 @if ($errors->has('userpassword'))                 
<label class="control-label" for="inputError"><i class="fa fa-times-circle-o"></i>{{$lngmenu->lng_wconfpassword}}</label>
@endif
<input type="password" class="form-control" id="userpassword_confirmation" name="userpassword_confirmation" placeholder="  {{$lngmenu->lng_wpassword}} "  value="{{ old('userpassword_confirmation') }}">
                    </div>

	   
						                                    
   <br>                     
	
		
<input type="hidden" class="form-control" id="tell" name="tell" value="{{$admin->user_tell}}" >
<input type="hidden" class="form-control" id="email" name="email" value="{{$admin->user_email}}" >	
                     <input type="hidden" name="_token" value="{{ csrf_token() }}">
   					<div class="row">
       					<div class="col-xs-12">
       <button class="btn btn-primary btn-block btn-flat">{{$lngmenu->lng_wedit}}</button>
       
            </div> 
          </div> 
               
 {!! Form::close() !!}
               
                  
      </div>
            
            
            
            </div>
            
            
   <div class="col-lg-6">  </div>
</div>















						
			
                                                </br>
                                                
                                                
                                                
                                         
                                            </div>
                                            
                                            

                                            
                                            
                                        </div>         
          
 @endforeach         
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          
          </section>
          

@stop

