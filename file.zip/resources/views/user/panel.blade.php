
@extends('user.layoutuser')

@section('title')
<title>پنل </title>
@stop

 
@section('superadmin')

      
      
       <section class="content">


 <div class="row">
          

<div class="col-md-4">
 <div class="panel colourable" data-step="1" data-intro=" ">
  <div class="panel-heading">   <span class="panel-title">{{$admins->user_name}}</span>  
   <a href="myprofile/edit" class="btn-success"><span class="fa fa-cog"></span> &nbsp; ویرایش پروفایل</a> 
  </div>
  <div class="list-group">
  <div class="list-group-item">کد مشتری شما <label class="badge badge-info">{{$admins->user_ncode}}</label></div>
 </div> </div> </div>
 
  
              
                      
              <div class="col-lg-3 col-xs-6">
              <!-- small box -->
              
              
            </div><!-- ./col -->
              <div class="col-lg-3 col-xs-6">
              <!-- small box -->
           
           
            </div><!-- ./col -->
                      </div><!-- /.row -->





                </section>
         

@stop

