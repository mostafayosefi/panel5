 
 
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="initial-scale=1.0,maximum-scale=1.0,user-scalable=no">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="msapplication-tap-highlight" content="no"/>

    <link rel="shortcut icon" type="image/png" href="assets/img/favicon-16x16.png" sizes="16x16">
    <link rel="shortcut icon" type="image/png" href="assets/img/favicon-32x32.png" sizes="32x32">

    <title>پنل کاربری - ورود</title>

    <!-- uikit -->
    <link rel="stylesheet" href="{{env('APP_URL')}}/build/alta/bower_components/uikit/css/uikit.almost-flat.min.css"/>

    <!-- altair admin login page -->
    <link rel="stylesheet" href="{{env('APP_URL')}}/build/alta/assets/css/login_page.min.css" />

</head>
<body class="login_page">

<div class="login_page_wrapper">
    <div class="md-card" id="login_card">
        <div class="md-card-content large-padding" id="login_form">
            <div class="login_heading">
                <div class="user_avatar"></div>
            </div>
            



      
        @if(count($errors))
        
        
			<span style="color: red" >
			 
				<strong>اخطار!</strong> لطفا اطلاعات را به درستی وارد نمایید. 
				<br/>
				<ul>
					@foreach($errors->all() as $error)
					<li>{{ $error }}</li>
					@endforeach
				</ul>
		 
				
			</span>
		@endif
      
      
      
 <br>

            <form action="" method="POST">
                <div class="uk-form-row">
                    <label  for="email danger">رایانامه</label>
                    <input class="md-input {{ $errors->has('email') ? 'md-input-danger' : '' }}" dir="ltr" type="text" id="email" name="email" />  
                </div>
                <div class="uk-form-row">
                    <label for="login_password">گذرواژه</label>
                    <input class="md-input {{ $errors->has('pass') ? 'md-input-danger' : '' }}" dir="ltr" type="password" id="pass" name="pass" />
                </div>
                
          <input type="hidden" name="_token" value="{{ csrf_token() }}">
                
                <div class="uk-margin-medium-top">
                    <input type="submit" class="md-btn md-btn-primary md-btn-block md-btn-large" value="ورود">
                </div>
                <div class="uk-margin-top">
                    <a href="#" id="login_help_show" class="uk-float-left">نمی توانید وارد شوید؟</a>
                        <span class="icheck-inline">
                            <input type="checkbox" name="login_page_stay_signed" id="login_page_stay_signed" data-md-icheck />
                            <label for="login_page_stay_signed" class="inline-label">به خاطر سپاری</label>
                        </span>
                </div>
            </form>
        </div>
        <div class="md-card-content large-padding uk-position-relative" id="login_help" style="display: none">
            <button type="button" class="uk-position-top-right uk-close uk-margin-right uk-margin-top back_to_login"></button>
            <h2 class="heading_b uk-text-success">نمی توانید وارد شوید؟</h2>
            <p>کاربر گرامی، در صورتی که سامانه اطلاعات ارسالی شما را نادرست اعلام می کند؛ می توانید از <a href="#" id="password_reset_show">بازیابی گذرواژه</a> جهت صدور گذرواژه تازه اقدام نمائید.</p>
        </div>
        <div class="md-card-content large-padding" id="login_password_reset" style="display: none">
            <button type="button" class="uk-position-top-right uk-close uk-margin-right uk-margin-top back_to_login"></button>
            <h2 class="heading_a uk-margin-large-bottom">بازیابی گذرواژه؟</h2>
            <form action="resetpass.html" method="POST">
                <div class="uk-form-row">
                    <label for="email">رایانامه</label>
                    <input class="md-input" dir="ltr" type="text" id="email" name="email" />
                </div>
                <div class="uk-margin-medium-top">
                    <input type="submit" class="md-btn md-btn-primary md-btn-block" value="بازیابی گذرواژه">
                </div>
            </form>
        </div>
        <div class="md-card-content large-padding" id="register_form" style="display: none">
            <button type="button" class="uk-position-top-right uk-close uk-margin-right uk-margin-top back_to_login"></button>
            <h2 class="heading_a uk-margin-medium-bottom">ثبت نام</h2>
            <form action="register.html" method="POST">
                <div class="uk-form-row">
                    <label for="email">رایانامه</label>
                    <input class="md-input" dir="ltr" type="email" id="email" name="email" />
                </div>
                <div class="uk-form-row">
                    <label for="mobile">شماره موبایل</label>
                    <input class="md-input" dir="ltr" type="text" id="mobile" name="mobile" />
                </div>
                <div class="uk-form-row">
                    <label for="pass">گذرواژه</label>
                    <input class="md-input" dir="ltr" type="password" id="pass" name="pass" />
                </div>
                <div class="uk-form-row">
                    <label for="cpass">تکرار گذرواژه</label>
                    <input class="md-input" dir="ltr" type="password" id="cpass" name="cpass" />
                </div>
                <div class="uk-margin-medium-top">
                    <input type="submit" class="md-btn md-btn-primary md-btn-block md-btn-large" value="ثبت نام">
                </div>
            </form>
        </div>
    </div>
    <div class="uk-margin-top uk-text-center">
        <a href="#" id="signup_form_show">ساخت حساب کاربری</a>
    </div>
</div>

<!-- common functions -->
<script src="{{env('APP_URL')}}/build/alta/assets/js/common.min.js"></script>
<script src="{{env('APP_URL')}}/build/alta/assets/js/altair_admin_common.min.js"></script>
<script src="{{env('APP_URL')}}/build/alta/assets/js/pages/login.min.js"></script>
</body>
</html>

          