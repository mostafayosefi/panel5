<!doctype html>
<html lang="es">
<head>
 <meta charset="UTF-8">
 <title>HASH</title>
</head>
<body>
 <form action="hash" method="post">
 <input type="hidden" name="_token" value="{{ csrf_token() }}">
  <label for="txtContrasenia">Ingrese la contrase�a a encriptar</label>
  <input type="text" id="txtContrasenia" name="txtContrasenia">
  <input type="submit" value="Encriptar">
 </form>
 
 <form action="" method="post">
 <input type="hidden" name="_token" value="{{ csrf_token() }}">
  <label for="txtContraseniaEncriptada">Ingrese la contrase�a a desencriptar</label>
  <input type="text" id="txtContraseniaEncriptada" name="txtContraseniaEncriptada">
  <input type="submit" value="Desencriptar">
 </form>
 
 <b>{{{$contraseniaEncriptada or ''}}}</b>
 <b>{{{$contraseniaDesencriptada or ''}}}</b>
</body>
</html>