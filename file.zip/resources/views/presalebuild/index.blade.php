
@extends('presalebuild.layoutpresale')

@section('title')
<title>پروژه پیش فروش ساختمان</title>
@stop
 
@section('body')
 

  
 

    <div class="news-page">
        <div class="container">

            <div class="row pt-2">
                            </div>

            <div class="row title-row">



                <div class="col-lg-4 page-title pr-lg-0">
                    <h1>سایت ما <span>مطالب مرتبط با حوزه املاک و بازار مسکن</span></h1>
                </div>
                <div class="col-lg-8 social-links">
                    <div class="col-12 col-md-9 text-left float-right py-1">ما را در شبکه های اجتماعی دنبال کنید</div>
                    <div class="col-12 col-md-3  float-left pl-lg-0">
                        <ul class="links float-left">
                            <li><a href="#"  rel="nofollow"><i class="sh-instagram"></i></a></li>
                            <li><a href="#"  rel="nofollow"><i class="sh-google-plus"></i></a></li>
                            <li><a href="#"  rel="nofollow"><i class="sh-facebook"></i></a></li>
                            <li><a href="#"  rel="nofollow"><i class="sh-linkedin"></i></a></li>
                            <li><a href="#"  rel="nofollow"><i class="sh-telegram"></i></a></li>
                        </ul>
                    </div>
                </div>
            </div>

           <div class="row  section-top">
                <div class="col-lg-4 vertical-slider pr-lg-0 pt-4 pt-lg-0 pt-md-0 col-md-6 d-none d-md-block">
                    <h2 class="pt-md-0 pt-lg-3">آخرین مطالب</h2>
                    <div class="swiper-container-news-top">
                        <!-- Additional required wrapper -->
                        <div class="swiper-wrapper">
                            <!-- Slides -->
                                                        <div class="swiper-slide short-list">
                                <a href="#">
                                    <div class="list1-image ">
                                            <img src="{{env('APP_URL')}}/public/images/15220814031024.png" srcset="{{env('APP_URL')}}/public/images/15220814031024.png"   height="100" alt="محله آریاشهر (صادقیه) را بهتر بشناسیم" title="محله آریاشهر (صادقیه) را بهتر بشناسیم">
                                    </div>
                                </a>
                                <div class="list1-content">
                                    <a href="#">
                                        <span class="list1-title">محله آریاشهر (صادقیه) را بهتر بشناسیم</span>
                                        <span class="blue-link">ادامه مطلب > </span>
                                    </a>
                                </div>
                            </div>
                                                        <div class="swiper-slide short-list">
                                <a href="#">
                                    <div class="list1-image ">
                                            <img src="{{env('APP_URL')}}/public/images/1493304748trlarge.gif" srcset="{{env('APP_URL')}}/public/images/1493304748trlarge.gif"   height="100"  alt="محلۀ پونک تهران کجاست؟" title="محلۀ پونک تهران کجاست؟">
                                    </div>
                                </a>
                                <div class="list1-content">
                                    <a href="#">
                                        <span class="list1-title">محلۀ پونک تهران کجاست؟</span>
                                        <span class="blue-link">ادامه مطلب > </span>
                                    </a>
                                </div>
                            </div>
                                                     
                                                    </div>
                        <!-- If we need pagination -->
                        <div class="swiper-pagination"></div>

                        <!-- If we need navigation buttons -->
                        <div class="button-prev">
                            <i class="sh-up"></i>
                        </div>
                        <div class="button-next">
                            <i class="sh-down"></i>
                        </div>

                    </div>
                </div>
                <div class="col-lg-8 top-news pr-lg-4 px-lg-0 flex-first flex-lg-last col-md-6">

                    <div class="swiper-container-news-top1">
                        <!-- Additional required wrapper -->
                        <div class="swiper-wrapper">
                            <!-- Slides -->
                                                            <div class="swiper-slide short-list">
 <a href="#">
                                        <img src="{{env('APP_URL')}}/public/images/1493304748trlarge.gif" srcset="{{env('APP_URL')}}/public/images/1493304748trlarge.gif"  height="455" alt="با خرید آپارتمان و طراحی دکوراسیون کودک صاحب خانه عروسک‌ها شویم" title="با خرید آپارتمان و طراحی دکوراسیون کودک صاحب خانه عروسک‌ها شویم">
                                        <div class="hoverable">
                                            <h2>با خرید آپارتمان و طراحی دکوراسیون کودک صاحب خانه عروسک‌ها شویم</h2>
                                            <span class="text-justify d-none d-sm-block">یکی از نکات مهمی که در شکل گیری شخصیت و حتی خلق و خوی ما تاثیر گذار است؛ دکوراسیون و چیدمان اتاق است؛ اگر در انتظار فرزند هستید؛ یا  در این مدت فکری به حال طراحی اتاق کودکتان نکرده‌اید؛ پیشنهاد می‌کنیم...</span>

                                        </div>
                                    </a>
                                </div>
                                                            <div class="swiper-slide short-list">
 <a href="#">
                                        <img src="{{env('APP_URL')}}/public/images/15220814031024.png" srcset="{{env('APP_URL')}}/public/images/15220814031024.png"   height="455" alt="مانند حرفه‌ای‌ها کمیسیون املاک در سال 98 را محاسبه کنید" title="مانند حرفه‌ای‌ها کمیسیون املاک در سال 98 را محاسبه کنید" >
                                        <div class="hoverable">
                                            <h2>مانند حرفه‌ای‌ها کمیسیون املاک در سال 98 را محاسبه کنید</h2>
                                            <span class="text-justify d-none d-sm-block">نیمه اول سال معمولا به عنوان زمان اصلی رهن و اجاره آپارتمان و یا خرید ملک شناخته می‌شود؛ اما نکته‌ای که شاید بیشتر ما از آن غافل هستیم؛ حق کمیسیون یا حق‌الزحمه‌ای است که باید به مشاوران املاک پرداخت...</span>

                                        </div>
                                    </a>
                                </div>
                                                        
                                                    </div>
                        <!-- If we need pagination -->
                        <div class="swiper-pagination"></div>
                    </div>


                </div>
            </div>

            <div class="row  section-advise">
                <div class="col-lg-12 px-lg-0">
                    <h3>در حال بازدید</h3>
                </div>
            </div>
            <div class="row">
                <div class="col-12 px-lg-0">
                    <div class="swiper-container-advise pb-5 pb-lg-0">
                        <!-- Additional required wrapper -->
                        <div class="swiper-wrapper">
                            <!-- Slides -->
                                                            <div class="swiper-slide">
                                    <div class="list2-image ">
 <a href="#">
                                            <img src="{{env('APP_URL')}}/public/images/1551523594faribanaderi-hms-photokade-2.jpg" srcset="{{env('APP_URL')}}/public/images/1551523594faribanaderi-hms-photokade-2.jpg" height="275" alt="مصاحبه با خانم رضایی، از جوانان موفق حوزه املاک" title="مصاحبه با خانم رضایی، از جوانان موفق حوزه املاک">
                                        </a>
                                    </div>
                                    <div class="list2-content">
                                        <span class="list2-category">پیشنهاد مشاورین املاک</span>
 <a href="#">
                                            <span class="list2-title">مصاحبه با خانم رضایی، از جوانان موفق حوزه املاک</span>
                                            <span class="blue-link">ادامه مطلب > </span>
                                        </a>
                                    </div>
                                </div>
                                                            <div class="swiper-slide">
                                    <div class="list2-image ">
 <a href="#">
                                            <img src="{{env('APP_URL')}}/public/images/15220814031024.png" srcset="{{env('APP_URL')}}/public/images/15220814031024.png" height="275" alt="4 نکته برای تهیه آگهی جذاب در املاک" title="4 نکته برای تهیه آگهی جذاب در املاک">
                                        </a>
                                    </div>
                                    <div class="list2-content">
                                        <span class="list2-category">پیشنهاد مشاورین املاک</span>
 <a href="#">
                                            <span class="list2-title">4 نکته برای تهیه آگهی جذاب در املاک</span>
                                            <span class="blue-link">ادامه مطلب > </span>
                                        </a>
                                    </div>
                                </div> 
                                                    </div>
                        <!-- If we need pagination -->
                        <div class="swiper-pagination"></div>

                        <div class="swiper-button-prev swiper-button-prev-model-2"></div>
                        <div class="swiper-button-next swiper-button-next-model-2"></div>
                    </div>

                </div>
            </div>



      
 

        </div>



    </div>



@stop