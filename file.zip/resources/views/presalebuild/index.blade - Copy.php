
@extends('presalebuild.layoutpresale')

@section('title')
<title>پروژه پیش فروش ساختمان</title>
@stop
 
@section('body')
 

    
    <div class="home-page">
        <section id="page_section" class="page_section home-page-cover slide1 clearfix pb-5">

            <h1 class="text-center pb-4 pt-4">خدمات پیش فروش ساختمان</h1>
            <div class="search_container container">
                <form class="filter_form filter_form_home advanced_search clearfix" action="#" id="filter-form">

    <div class="row mb-3 px-xl-5" id="searchContent" data-form="search">
     <div class="col-12 main-search pb-5 pb-lg-4">

         <div class="row">

             <div class="col-12 col-lg-3 my-2 px-2">
                 <select class="big-size w-100" name="sales_type">
                                              <option value="sale">خرید</option>
                                              <option value="rent">رهن و اجاره</option>
                                      </select>
             </div>
             <div class="col-12 col-lg-9 my-2 px-2">

                 <div class="row">
                     <div class="col-12 col-lg-9 col-xl-10 pl-lg-0">
                            <div class="search-input clearfix ">
    <div class="row m-0">
        <div class="result-box multiple p-0 col-auto">
        </div>

        <div class="col searchform pr-lg-0">
            <i class="sh-location"></i>
            <input id="searchtext" name="location" class="big-size form-control searchtext search-location form-input float-right with-icon dirty" type="text" autocomplete="off" placeholder="استان ، شهر یا محله">
            <input type="hidden" id="location_ids" name="location_ids" class="area-input" value="">
        </div>
        <div class="search-box">
        </div>
    </div>
</div>
                     </div>
                     <div class="col-12 col-lg-3 col-xl-2 pr-lg-0 pt-3 pt-lg-0 d-none d-lg-block">
                         <button class="shabesh-button main-search-btn w-100 green big-size">جستجو</button>
                     </div>
                 </div>

             </div>
         </div>

  

         <div class="row">

             <div class="col-12 pt-2 px-2 d-lg-none mb-3 mb-lg-0">
                 <button class="shabesh-button green w-100 big-size">جستجو</button>
             </div>

         </div>

      
         <div class="more-btn-mobile d-lg-none">
             <span>معیار های بیشتر</span>
             <i class="sh-add"></i>
         </div>

     </div>
    </div>
</form>



                <div class="app-download">
                    <div class="down-img text-center my-3">
                        <img src="{{env('APP_URL')}}/build/presalebuild/device.png" width="80" alt="دانلود اپلیکیشن " title="دانلود اپلیکیشن ">
                    </div>
                    <div class="download-links text-center">
                        <span class="download-our-app">دانلود اپلیکیشن</span>
                        <ul class="dl-links mt-3">
                            <li>
                                <a class="ml-3" href="#" target="_blank" rel="nofollow">
                                    <i class="sh-android"></i>
                                    <span>گوگل پلی</span>
                                </a>
                            </li>
                            <li>
                                <a class="ml-3" href="#" target="_blank" rel="nofollow">
                                    <i class="sh-apple"></i>
                                    <span>وب اپ</span>
                                </a>
                            </li>
                            <li>
                                <a class="" href="#" target="_blank" rel="nofollow">
                                    <i class="sh-bazzar"></i>
                                    <span>بازار</span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>

            </div>

        </section>

        <section class="w-100 mb-3 mt-4">
            <div class="container">
                <div class="text-center">
                    <h2 class="home-divider home-announce-title mb-3">
                        <span>آپارتمان های پیشنهادی  </span>
                    </h2>
                </div>
                <div class="row">
                    <div class="col-12 col-lg-9">
                        <div class="row">
                                                                                        <div class="col-12 col-md-6 my-2 px-2">
                                    <a href="#">
                                        <div class="home-announce-container">
                                            <img class="w-100" src="{{env('APP_URL')}}/build/presalebuild/timthumb.php">
                                            <div class="home-announce-info">
                                                <span class="home-announce-title">
                                                    آپارتمان 110 متری برای فروش در جردن ، تهران 
                                                </span>
                                                <ul class="home-announce-prop">
                                                    <li>آپارتمان</li>
                                                    <li class="with-icon">
                                                        <i class="sh-meter"></i>
                                                        <span>110</span>
                                                    </li>
                                                                                                            <li class="with-icon">
                                                            <i class="sh-bed2"></i>
                                                            <span>2</span>
                                                        </li>
                                                                                                                                                        </ul>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                                                            <div class="col-12 col-md-6 my-2 px-2">
                                    <a href="#">
                                        <div class="home-announce-container">
                                            <img class="w-100" src="{{env('APP_URL')}}/build/presalebuild/timthumb(1).php">
                                            <div class="home-announce-info">
                                                <span class="home-announce-title">
                                                    آپارتمان 145 متری برای فروش در چیتگر ، تهران 
                                                </span>
                                                <ul class="home-announce-prop">
                                                    <li>آپارتمان</li>
                                                    <li class="with-icon">
                                                        <i class="sh-meter"></i>
                                                        <span>145</span>
                                                    </li>
                                                                                                            <li class="with-icon">
                                                            <i class="sh-bed2"></i>
                                                            <span>3</span>
                                                        </li>
                                                                                                                                                                <li class="imp">2,500,000,000 تومان</li>
                                                                                                    </ul>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                                                            <div class="col-12 col-md-6 my-2 px-2">
                                    <a href="#">
                                        <div class="home-announce-container">
                                            <img class="w-100" src="{{env('APP_URL')}}/build/presalebuild/timthumb(2).php">
                                            <div class="home-announce-info">
                                                <span class="home-announce-title">
                                                    آپارتمان 97 متری برای فروش در ظفر ، تهران 
                                                </span>
                                                <ul class="home-announce-prop">
                                                    <li>آپارتمان</li>
                                                    <li class="with-icon">
                                                        <i class="sh-meter"></i>
                                                        <span>97</span>
                                                    </li>
                                                                                                            <li class="with-icon">
                                                            <i class="sh-bed2"></i>
                                                            <span>2</span>
                                                        </li>
                                                                                                                                                                <li class="imp">2,500,000,000 تومان</li>
                                                                                                    </ul>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                                                            <div class="col-12 col-md-6 my-2 px-2">
                                    <a href="#">
                                        <div class="home-announce-container">
                                            <img class="w-100" src="{{env('APP_URL')}}/build/presalebuild/timthumb(3).php">
                                            <div class="home-announce-info">
                                                <span class="home-announce-title">
                                                    آپارتمان 107 متری برای فروش در جنت آباد جنوبی ، تهران 
                                                </span>
                                                <ul class="home-announce-prop">
                                                    <li>آپارتمان</li>
                                                    <li class="with-icon">
                                                        <i class="sh-meter"></i>
                                                        <span>107</span>
                                                    </li>
                                                                                                            <li class="with-icon">
                                                            <i class="sh-bed2"></i>
                                                            <span>2</span>
                                                        </li>
                                                                                                                                                                <li class="imp">1,850,000,000 تومان</li>
                                                                                                    </ul>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                                                    </div>

                    </div>
                    <div class="col-12 col-lg-3 d-none d-md-block">
                        <div class="row">

                            <div class="col-12 col-md-6 col-lg-12 my-2 px-2">
                                <a href="#" target="_blank">
                                    <div class="home-announce-container">
                                        <img class="w-100" src="{{env('APP_URL')}}/build/presalebuild/375.jpg">
                                    </div>
                                </a>
                            </div>

                            <div class="col-12 col-md-6 col-lg-12 my-2 px-2">
                                <a href="#" target="_blank">
                                    <div class="home-announce-container">
                                        <img class="w-100" src="{{env('APP_URL')}}/build/presalebuild/mika-375.jpg">
                                    </div>
                                </a>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </section>

        

        <section class="pop-search pt-2 pb-2 link-box home-link-box">
            <div class="container  bg-white">

                <div class="row">
                    <div class="col-12">
                        <div class="text-center w-100 py-3 active link-toggler">
                            <div class="mx-auto btn-inner">
                                <h2>جستجو بر اساس استان های ایران
                                    <i class="closed sh-arrowdown"></i>
                                    <i class="opened sh-arrowup"></i>
                                </h2>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row homepage-link-holder px-4">
                                            <div class="col-xl-3 col-md-6 px-2">
                            <ul class="column">
                                <li class="p-2"><span class="ml-2"><i class="sh-add"></i></span>
                                    <a>تهران</a>
                                    <ul class="inner-ul">

                                        <li>
                                                                                                                                                                                                        <div class="w-100 link-hold">
                                                            <a class="blue-link medium-sans" href="#">
                                                                خرید آپارتمان در تهران
                                                            </a>
                                                        </div>
                                                                                                                                                                                                                <div class="w-100 link-hold">
                                                            <a class="blue-link medium-sans" href="#">
                                                                خرید اداری در تهران
                                                            </a>
                                                        </div>
                                                                                                                                                                                                                <div class="w-100 link-hold">
                                                            <a class="blue-link medium-sans" href="#">
                                                                خرید تجاری در تهران
                                                            </a>
                                                        </div>
                                                                                                                                                                                                                <div class="w-100 link-hold">
                                                            <a class="blue-link medium-sans" href="#">
                                                                خرید زمین در تهران
                                                            </a>
                                                        </div>
                                                                                                                                                                                                                <div class="w-100 link-hold">
                                                            <a class="blue-link medium-sans" href="#">
                                                                خرید کلنگی در تهران
                                                            </a>
                                                        </div>
                                                                                                                                                                                                                <div class="w-100 link-hold">
                                                            <a class="blue-link medium-sans" href="#">
                                                                خرید ویلا در تهران
                                                            </a>
                                                        </div>
                                                                                                                                                                                                                                                                                                            <div class="w-100 link-hold">
                                                            <a class="blue-link medium-sans" href="#">
                                                                رهن و اجاره آپارتمان در تهران
                                                            </a>
                                                        </div>
                                                                                                                                                                                                                <div class="w-100 link-hold">
                                                            <a class="blue-link medium-sans" href="#">
                                                                رهن و اجاره اداری در تهران
                                                            </a>
                                                        </div>
                                                                                                                                                                                                                <div class="w-100 link-hold">
                                                            <a class="blue-link medium-sans" href="#">
                                                                رهن و اجاره تجاری در تهران
                                                            </a>
                                                        </div>
                                                                                                                                                                                        </li>

                                    </ul>
                                </li>

                            </ul>
                        </div>
                                            <div class="col-xl-3 col-md-6 px-2">
                            <ul class="column">
                                <li class="p-2"><span class="ml-2"><i class="sh-add"></i></span>
                                    <a>البرز</a>
                                    <ul class="inner-ul">

                                        <li>
                                                                                                                                                                                                        <div class="w-100 link-hold">
                                                            <a class="blue-link medium-sans" href="#">
                                                                خرید آپارتمان در البرز
                                                            </a>
                                                        </div>
                                                                                                                                                                                                                <div class="w-100 link-hold">
                                                            <a class="blue-link medium-sans" href="#">
                                                                خرید اداری در البرز
                                                            </a>
                                                        </div>
                                                                                                                                                                                                                <div class="w-100 link-hold">
                                                            <a class="blue-link medium-sans" href="#">
                                                                خرید تجاری در البرز
                                                            </a>
                                                        </div>
                                                                                                                                                                                                                <div class="w-100 link-hold">
                                                            <a class="blue-link medium-sans" href="#">
                                                                خرید زمین در البرز
                                                            </a>
                                                        </div>
                                                                                                                                                                                                                <div class="w-100 link-hold">
                                                            <a class="blue-link medium-sans" href="#">
                                                                خرید کلنگی در البرز
                                                            </a>
                                                        </div>
                                                                                                                                                                                                                <div class="w-100 link-hold">
                                                            <a class="blue-link medium-sans" href="#">
                                                                خرید ویلا در البرز
                                                            </a>
                                                        </div>
                                                                                                                                                                                                                                                                                                            <div class="w-100 link-hold">
                                                            <a class="blue-link medium-sans" href="#">
                                                                رهن و اجاره آپارتمان در البرز
                                                            </a>
                                                        </div>
                                                                                                                                                                                                                <div class="w-100 link-hold">
                                                            <a class="blue-link medium-sans" href="#">
                                                                رهن و اجاره اداری در البرز
                                                            </a>
                                                        </div>
                                                                                                                                                                                                                <div class="w-100 link-hold">
                                                            <a class="blue-link medium-sans" href="#">
                                                                رهن و اجاره تجاری در البرز
                                                            </a>
                                                        </div>
                                                                                                                                                                                        </li>

                                    </ul>
                                </li>

                            </ul>
                        </div>
                                            <div class="col-xl-3 col-md-6 px-2">
                            <ul class="column">
                                <li class="p-2"><span class="ml-2"><i class="sh-add"></i></span>
                                    <a>مازندران</a>
                                    <ul class="inner-ul">

                                        <li>
                                                                                                                                                                                                        <div class="w-100 link-hold">
                                                            <a class="blue-link medium-sans" href="#">
                                                                خرید آپارتمان در مازندران
                                                            </a>
                                                        </div>
                                                                                                                                                                                                                <div class="w-100 link-hold">
                                                            <a class="blue-link medium-sans" href="#">
                                                                خرید اداری در مازندران
                                                            </a>
                                                        </div>
                                                                                                                                                                                                                <div class="w-100 link-hold">
                                                            <a class="blue-link medium-sans" href="#">
                                                                خرید تجاری در مازندران
                                                            </a>
                                                        </div>
                                                                                                                                                                                                                <div class="w-100 link-hold">
                                                            <a class="blue-link medium-sans" href="#">
                                                                خرید زمین در مازندران
                                                            </a>
                                                        </div>
                                                                                                                                                                                                                <div class="w-100 link-hold">
                                                            <a class="blue-link medium-sans" href="#">
                                                                خرید کلنگی در مازندران
                                                            </a>
                                                        </div>
                                                                                                                                                                                                                <div class="w-100 link-hold">
                                                            <a class="blue-link medium-sans" href="#">
                                                                خرید ویلا در مازندران
                                                            </a>
                                                        </div>
                                                                                                                                                                                                                                                                                                            <div class="w-100 link-hold">
                                                            <a class="blue-link medium-sans"  href="#">
                                                               aaaaaa
                                                            </a>
                                                        </div>
                                                                                                                                                                               <div class="w-100 link-hold">
                                                            <a class="blue-link medium-sans"  href="#">
                                                               aaaaaa
                                                            </a>
                                                        </div>
                                                        
                                                                 <div class="w-100 link-hold">
                                                            <a class="blue-link medium-sans"  href="#">
                                                               aaaaaa
                                                            </a>
                                                        </div>
                                                                                                                                                                                        </li>

                                    </ul>
                                </li>

                            </ul>
                        </div>
                                            <div class="col-xl-3 col-md-6 px-2">
                            <ul class="column">
                                <li class="p-2"><span class="ml-2"><i class="sh-add"></i></span>
                                    <a>گیلان</a>
                                    <ul class="inner-ul">

                                        <li>
                                                                                                                                     <div class="w-100 link-hold">
                                                            <a class="blue-link medium-sans"  href="#">
                                                               aaaaaa
                                                            </a>
                                                        </div>
                                                        
                                                                 <div class="w-100 link-hold">
                                                            <a class="blue-link medium-sans"  href="#">
                                                               aaaaaa
                                                            </a>
                                                        </div>
                                                                                                                                                                                        </li>

                                    </ul>
                                </li>

                            </ul>
                        </div>
                                            <div class="col-xl-3 col-md-6 px-2">
                            <ul class="column">
                                <li class="p-2"><span class="ml-2"><i class="sh-add"></i></span>
                                    <a>خراسان رضوی</a>
                                    <ul class="inner-ul">
                                        <li>
                                                                                                                                     <div class="w-100 link-hold">
                                                            <a class="blue-link medium-sans"  href="#">
                                                               aaaaaa
                                                            </a>
                                                        </div>
                                                        
                                                                 <div class="w-100 link-hold">
                                                            <a class="blue-link medium-sans"  href="#">
                                                               aaaaaa
                                                            </a>
                                                        </div>
                                                                                                                                                                                        </li>

                                    </ul>
                                </li>

                            </ul>
                        </div>
                                            <div class="col-xl-3 col-md-6 px-2">
                            <ul class="column">
                                <li class="p-2"><span class="ml-2"><i class="sh-add"></i></span>
                                    <a>اصفهان</a>
                                    <ul class="inner-ul">

                                                                  <li>
                                                                                                                                     <div class="w-100 link-hold">
                                                            <a class="blue-link medium-sans"  href="#">
                                                               aaaaaa
                                                            </a>
                                                        </div>
                                                        
                                                                 <div class="w-100 link-hold">
                                                            <a class="blue-link medium-sans"  href="#">
                                                               aaaaaa
                                                            </a>
                                                        </div>
                                                                                                                                                                                        </li>

                                    </ul>
                                </li>

                            </ul>
                        </div>
                                            <div class="col-xl-3 col-md-6 px-2">
                            <ul class="column">
                                <li class="p-2"><span class="ml-2"><i class="sh-add"></i></span>
                                    <a>آذربایجان شرقی</a>
                                    <ul class="inner-ul">

                                                                   <li>
                                                                                                                                     <div class="w-100 link-hold">
                                                            <a class="blue-link medium-sans"  href="#">
                                                               aaaaaa
                                                            </a>
                                                        </div>
                                                        
                                                                 <div class="w-100 link-hold">
                                                            <a class="blue-link medium-sans"  href="#">
                                                               aaaaaa
                                                            </a>
                                                        </div>
                                                                                                                                                                                        </li>

                                    </ul>
                                </li>

                            </ul>
                        </div>
                                            <div class="col-xl-3 col-md-6 px-2">
                            <ul class="column">
                                <li class="p-2"><span class="ml-2"><i class="sh-add"></i></span>
                                    <a>هرمزگان</a>
                                    <ul class="inner-ul">
                                        <li>
                                                                                                                                     <div class="w-100 link-hold">
                                                            <a class="blue-link medium-sans"  href="#">
                                                               aaaaaa
                                                            </a>
                                                        </div>
                                                        
                                                                 <div class="w-100 link-hold">
                                                            <a class="blue-link medium-sans"  href="#">
                                                               aaaaaa
                                                            </a>
                                                        </div>
                                                                                                                                                                                        </li>

                                    </ul>
                                </li>

                            </ul>
                        </div>
                                            <div class="col-xl-3 col-md-6 px-2">
                            <ul class="column">
                                <li class="p-2"><span class="ml-2"><i class="sh-add"></i></span>
                                    <a>آذربایجان غربی</a>
                                    <ul class="inner-ul">
                                        <li>
                                                                                                                                     <div class="w-100 link-hold">
                                                            <a class="blue-link medium-sans"  href="#">
                                                               aaaaaa
                                                            </a>
                                                        </div>
                                                        
                                                                 <div class="w-100 link-hold">
                                                            <a class="blue-link medium-sans"  href="#">
                                                               aaaaaa
                                                            </a>
                                                        </div>
                                                                                                                                                                                        </li>

                                    </ul>
                                </li>

                            </ul>
                        </div>
                                            <div class="col-xl-3 col-md-6 px-2">
                            <ul class="column">
                                <li class="p-2"><span class="ml-2"><i class="sh-add"></i></span>
                                    <a>اردبیل</a>
                                    <ul class="inner-ul">

                                                                  <li>
                                                                                                                                     <div class="w-100 link-hold">
                                                            <a class="blue-link medium-sans"  href="#">
                                                               aaaaaa
                                                            </a>
                                                        </div>
                                                        
                                                                 <div class="w-100 link-hold">
                                                            <a class="blue-link medium-sans"  href="#">
                                                               aaaaaa
                                                            </a>
                                                        </div>
                                                                                                                                                                                        </li>

                                    </ul>
                                </li>

                            </ul>
                        </div>
                                            <div class="col-xl-3 col-md-6 px-2">
                            <ul class="column">
                                <li class="p-2"><span class="ml-2"><i class="sh-add"></i></span>
                                    <a>ایلام</a>
                                    <ul class="inner-ul">
                                        <li>
                                                                                                                                     <div class="w-100 link-hold">
                                                            <a class="blue-link medium-sans"  href="#">
                                                               aaaaaa
                                                            </a>
                                                        </div>
                                                        
                                                                 <div class="w-100 link-hold">
                                                            <a class="blue-link medium-sans"  href="#">
                                                               aaaaaa
                                                            </a>
                                                        </div>
                                                                                                                                                                                        </li>

                                    </ul>
                                </li>

                            </ul>
                        </div>
                                            <div class="col-xl-3 col-md-6 px-2">
                            <ul class="column">
                                <li class="p-2"><span class="ml-2"><i class="sh-add"></i></span>
                                    <a>بوشهر</a>
                                    <ul class="inner-ul">

                                                                     <li>
                                                                                                                                     <div class="w-100 link-hold">
                                                            <a class="blue-link medium-sans"  href="#">
                                                               aaaaaa
                                                            </a>
                                                        </div>
                                                        
                                                                 <div class="w-100 link-hold">
                                                            <a class="blue-link medium-sans"  href="#">
                                                               aaaaaa
                                                            </a>
                                                        </div>
                                                                                                                                                                                        </li>

                                    </ul>
                                </li>

                            </ul>
                        </div>
                                           
                                      
                        
                         
                                    </div>

            </div>
        </section>

        <section class="homepage-top special-announce">
            <div class="container pt-5 pb-3">

                <div class="row">
                    <div class="col-lg-8 col-md-12 pl-lg-5">
                        <div class="row">
                            <div class="col-md-4 col-6 px-2 mb-3">
                                <div class="inner">
                                    <div class="img-holder">

                                        <img src="{{env('APP_URL')}}/build/presalebuild/search1.jpg" srcset="img/homepageimg/search2.jpg" class="w-100" alt="نقشه آگهی ها" title="نقشه آگهی ها">

                                    </div>
                                    <div class="title medium-sans px-3 pt-3 pb-2">
                                        <h3>                                    نقشه آگهی ها</h3>
                                    </div>
                                    <div class="sub-title px-3 pb-3">
                                        <p>                                    با قابلیت جستجوی روی نقشه از آگهی های محله مورد نظرتان و همچنین امکانات اطراف آن مطلع شوید .</p>
                                    </div>
                                    <a href="#" class="sh-link medium-sans px-3  d-block">
                                        جستجوی آگهی ها روی نقشه
                                        <i class="sh-arrowdown"></i>
                                    </a>
                                </div>

                            </div>
                            <div class="col-md-4 col-6 px-2 mb-3">
                                <div class="inner">
                                    <div class="img-holder">
                                        <img src="{{env('APP_URL')}}/build/presalebuild/moshaver1.jpg" srcset="img/homepageimg/moshaver2.jpg" class="w-100" alt="مشاوران املاک " title="مشاوران  املاک">
                                    </div>
                                    <div class="title medium-sans px-3 pt-3 pb-2">
                                        <h3>مشاورین املاک</h3>
                                    </div>
                                    <div class="sub-title px-3 pb-3">
                                        <p>با برترین مشاورین املاک شهر یا محله خود آشنا شوید و با مشاهده پروفایل و تماس با آنها تصمیمی درست بگیرید.</p>
                                    </div>
                                    <a href="#" class="sh-link medium-sans px-3  d-block">
                                        جستجوی مشاورین املاک
                                        <i class="sh-arrowdown"></i>
                                    </a>
                                </div>

                            </div>

                            <div class="col-md-4 col-6 px-2 mb-3">
                                <div class="inner">
                                    <div class="img-holder">

                                        <img src="{{env('APP_URL')}}/build/presalebuild/blog1.jpg" srcset="img/homepageimg/blog2.jpg" class="w-100" alt=" بلاگ  " title=" بلاگ" >

                                    </div>
                                    <div class="title medium-sans px-3 pt-3 pb-2">
                                        <h3>                                 بلاگ    </h3>
                                    </div>
                                    <div class="sub-title px-3 pb-3">
                                        <p>
                                            با بلاگ  از آخرین اخبار و مقالات ملک مطلع شدید و تصمیم درست بگیرید.
                                        </p>
                                    </div>
                                    <a href="#" class="sh-link medium-sans px-3  d-block">
                                       سایت 
                                        <i class="sh-arrowdown"></i>
                                    </a>
                                </div>

                            </div>

                        </div>
                    </div>
                    <div class="col-lg-4 col-md-12 px-2">
                        <div class="inner">

                            <div class="title medium-sans px-3 py-3">
                                <h4>                            اولین نفر مطلع شوید !</h4>
                            </div>

                            <div class="sub-title px-3 pb-3 is-alert">
                                <p>                            از آخرین آگهی های درج شده در سایت  در سریعترین زمان مطلع شوید.</p>

                            </div>

                            <div class="w-100 px-3 pb-3">
                                <button class="shabesh-button green w-100 alert-panel">
                                    به من اطلاع بده
                                    <i class="sh-alarm2"></i>
                                </button>
                            </div>
                        </div>
                    </div>

                </div>
            </div>


        </section>

            </div>

@stop