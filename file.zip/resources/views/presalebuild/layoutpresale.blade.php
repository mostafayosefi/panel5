 
    @yield('title')
  
 <!DOCTYPE html>
 
<html lang="fa-IR" dir="rtl"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
 
    
     
    <meta http-equiv="content-language" content="fa">
    <meta name="language" content="fa">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
 

    <link rel="alternate" type="application/rss+xml" title="RSS FEED" href="#">
    <meta property="og:locale" content="fa">
 
    <link rel="stylesheet" type="text/css" href="{{env('APP_URL')}}/build/presalebuild/base.css" media="all">
    <link rel="stylesheet" type="text/css" href="{{env('APP_URL')}}/build/presalebuild/app.css" media="all">
    
</head>
<body itemscope="" itemtype="http://schema.org/WebPage">

 
 

    <div class="main ">
    
            <header class="header" itemscope="" itemtype="https://schema.org/WPHeader">

    <div class="container">
        <div class="row">
            <nav class="col  navbar navbar-expand-lg navbar-light" itemscope="" itemtype="http://www.schema.org/SiteNavigationElement">
                <a class="navbar-brand mr-md-0 pr-lg-0 pl-4" href="#"><img class="img-responsive pt-1 px-md-0 pt-md-1" src="{{env('APP_URL')}}/build/presalebuild/logo.jpg" srcset="{{env('APP_URL')}}/build/presalebuild/logo.jpg" width="92" alt="پروژه پیش فروش ساختمان" title="پروژه پیش فروش ساختمان">
                    <span class="hidden" itemprop="name">پروژه پیش فروش ساختمان</span>
                </a>

                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="true" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>


                <div class="navbar-collapse px-2 px-md-0 pt-4 pt-lg-0 collapse show" id="navbarSupportedContent" style="">
                    <ul class="navbar-nav  pt-0">
                        <li class="nav-item px-2 pb-4 pb-lg-0  pr-2 pr-lg-0">
                            <a class="main-link" href="#">خرید</a>
                        </li>
                        <li class="nav-item pb-4 pb-lg-0 pr-2 pr-lg-0">
                            <a class="main-link" href="#">رهن و اجاره</a>
                        </li>
                        <li class="nav-item pb-4 pb-lg-0 pr-2 pr-lg-0">
                            <a class="main-link" href="#">پروژه ها</a>
                        </li>
                        <li class="nav-item pb-4 pb-lg-0 pr-2 pr-lg-0">
                            <a class="main-link" href="#">مشاورین املاک</a>
                        </li>
                        <li class="nav-item pb-4 pb-lg-0 pr-2 pr-lg-0">
                            <a class="main-link" href="{{ url('/user/registeruser') }}">ثبت نام</a>
                        </li>
                        <li class="nav-item pb-4 pb-lg-0 pr-2 pr-lg-0">
                            <a class="main-link" href="{{ url('/user') }}">ورود</a>
                        </li>
                    </ul>
                    <div class="mr-auto pl-lg-0 clearfix pr-2 pr-lg-0 pb-4 pb-lg-0">
                        <div class="login_btn authenticate_btn float-right pl-4 pt-2">
                            <button type="button" data-toggle="modal" data-target="#authModal"> ورود / ثبت نام</button>
                        </div>

                        <div class="profile_btn authenticate_btn hidden float-right pl-4 pt-2">

                            <a href="#"><i class="sh-user"></i>
                                <span id="username">پروفایل</span>
                            </a>

                        </div>
                        <div class="float-left  text-left">

                            <a class="shabesh-button yellow bold mt-2" href="#"> ثبت آگهی رایگان</a>

                        </div>
                    </div>

                </div>

            </nav>
        </div>
    </div>

</header>
        
   
    @yield('body')
    
    
                        <footer id="footer" class="footer-section  hidden-print" itemscope="" itemtype="http://schema.org/WPFooter">
    <div class="container py-3">
        <div class="w-100 line py-3">
      
        </div>

        <div class="row">
            <div class="col-lg-2 col-sm-4 py-3"><a class="footer-link medium-sans" href="#">خرید</a> </div>
            <div class="col-lg-2 col-sm-4 py-3"><a class="footer-link medium-sans" href="#">بلاگ</a></div>
            <div class="col-lg-2 col-sm-4 py-3"><a class="footer-link medium-sans" href="#">رهن و اجاره</a> </div>
            <div class="col-lg-2 col-sm-4 py-3"><a class="footer-link medium-sans" href="#"> مشاورین املاک</a> </div>
            <div class="col-lg-2 col-sm-4 py-3"><a class="footer-link medium-sans" href="#">اپلیکیشن</a></div>
            <div class="col-lg-2 col-sm-4 py-3"><a class="footer-link medium-sans" href="#">آژانس های املاک</a></div>
        </div>

        <div class="w-100 line-top py-3">
            <div class="row">
                <div class="col-md-8">
                    <div class="row">
                        <div class="col-lg-3 col-sm-4 py-3"><a class="footer-link medium-sans" href="#">درباره ما</a> </div>
                        <div class="col-lg-3 col-sm-4 py-3"><a class="footer-link medium-sans" href="#">سوالات متداول</a> </div>
                        <div class="col-lg-3 col-sm-4 py-3"><a class="footer-link medium-sans" href="#">ویژه مشاورین املاک</a> </div>
                        <div class="col-lg-3 col-sm-4 py-3"><a class="footer-link medium-sans" href="#">تماس با ما</a> </div>
                        <div class="col-lg-3 col-sm-4 py-3"><a class="footer-link medium-sans" href="#">ضوابط و قوانین</a> </div>
                        <div class="col-lg-3 col-sm-4 py-3"><a class="footer-link medium-sans" href="#">تبلیغات</a> </div>


                    </div>
                </div>
                <div class="col-md-4">
                    <div class="enamad clearfix float-md-left float-right">
                 
                    </div>

                </div>
            </div>
        </div>
        <div class="w-100 title medium-sans pt-4 text-center text-md-right">
            ما را در شبکه های اجتماعی دنبال کنید
        </div>
        <div class="w-100 icons py-3 text-center text-md-right">
            <a href="#" class="facebook" rel="nofollow">
                <i class="sh-facebook"></i>
            </a>

            <a href="#" class="linkdin mr-2" rel="nofollow">
                <i class="sh-linkedin"></i>
            </a>
            <a href="#" class="telegram mr-2" rel="nofollow">
                <i class="sh-telegram"></i>
            </a>
            <a href="#" class="aparat mr-2" rel="nofollow">
                <i class="sh-aparat"></i>
            </a>
            <a href="#" class="insta mr-2" rel="nofollow">
                <i class="sh-instagram"></i>
            </a>

        </div>
 

    </div>
</footer>
            
    <div class="modal mobile-call-modal fade" id="call-modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content pt-0">
            <div class="modal-header">
                <h5 class="modal-title text-center w-100" id="usertypelabel">تماس با ما</h5>
                <button type="button" class="close call-close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true"><i class="sh-quit"></i> </span>
                </button>
            </div>
            <div class="modal-body pt-0" id="call-modal-result">

            </div>
        </div>
    </div>
</div>    <!-- Modal -->
<div class="modal fade" id="authModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-body p-0">

                <button class="close" data-dismiss="modal" aria-label="Close">
                    <i class="sh-quit"></i>
                </button>

                <button class="back hidden">
                    بازگشت
                </button>


                <div class="auth-container login-chooser" style="">

                    <div class="auth-head">

                        <span class="login-icons">
                            <i class="sh-user"></i>
                            ورود / ثبت نام
                        </span>

                        <div class="fav-text mt-4">
                            <img class="mb-4" width="32" src="{{env('APP_URL')}}/build/presalebuild/warning-img2x.png" title="علاقه مندی" alt="علاقه مندی">
                            <span class="px-0"></span>

                        </div>

                        <div class="alarm-text mt-4">
                            <img class="mb-4" width="26" src="{{env('APP_URL')}}/build/presalebuild/alarm.png" title="اطلاع رسانی" alt="اطلاع رسانی">
                            <span class="px-0"></span>

                        </div>

                    </div>

                    <form class="auth-form" data-submit="checknumber">
                        <div class="row text-center auth-title">
                        برای <span>ورود</span> یا <span>ثبت‌ نام</span> شماره تلفن همراه خود را وارد کنید
                        </div>
                        <div class="row">
                            <div class="form-item col-12">
                                <input type="text" name="mobile" id="mobile1" class="number-only flex-label" pattern="09[0-9]{9}" required="">
                                <label for="mobile">شماره موبایل</label>
                                <span class="error-input">شماره موبایل ۱۱ رقمی را وارد کنید .</span>
                                <span class="example">مثال : ۰۹۱۲۰۰۰۰۰۰۰</span>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-12 mt-4">
                                <button class="shabesh-button green w-100 submit-button submit-form " data-action="registerContainer">ادامه</button>
                            </div>
                        </div>
                    </form>

                </div>

                <div class="auth-container login-container" style="display: none;">
                    <div class="auth-head">

                        <span>
                            <i class="sh-user"></i>
                            ورود / ثبت نام
                        </span> 
                    </div>

                    <form class="auth-form" data-submit="login">
                        <div class="row text-center auth-title">
                            رمز عبور خود را وارد کنید
                        </div>
                        <div class="row">
                            <div class="form-item col-12 mb-2">
                                <input type="text" name="mobile" id="login_mobile" class="flex-label" required="" readonly="">
                                <label for="login_mobile" class="fixed">شماره موبایل</label>
                                <span class="error-input">شماره موبایل خود را وارد نمایید</span>
                            </div>
                        </div>

                        <div class="row">
                            <div class="form-item col-12 mb-2">
                                <input type="password" id="login_password" name="password" class="flex-label" minlength="8" autocomplete="off" required="">
                                <label for="login_password">رمز عبور</label>
                                <span class="error-input">رمز عبور را حداقل ۸ کاراکتر وارد نمایید</span>
                            </div>
                        </div>

                        <div class="row pt-3">
                            <div class="col-12">
                                <button type="submit" class="shabesh-button green w-100 submit-button submit-form ">ورود</button>
                            </div>
                        </div>
                        <input type="hidden" name="user_id" id="login_user_id">


                        <div class="row">
                            <div class="col-12">
                                <button type="button" class="shabesh-button green cleared w-100 cleared forget-pass">فراموشی رمز عبور</button>
                            </div>
                        </div>
                    </form>

                </div>


                <div class="auth-container reset-password" style="display: none;">
                    <div class="auth-head">
                        <span>بازیابی رمز عبور</span>
                    </div>
                    <form class="auth-form" data-submit="reset-pass">
                        <div class="row text-center auth-title">
کد ارسال شده به شماره همراه و رمز عبور جدید را وارد کنید .
                        </div>

                        <input type="hidden" name="user_id" class="reset-userid">


                        <div class="row confirm-code">
                            <div class="form-item col-12">
                                <input type="text" name="remember_token" id="remember_token" class="flex-label" required="">
                                <label for="remember_token">کد ارسالی</label>
                                <span class="error-input">کد ارسالی را وارد کنید .</span>
                            </div>
                        </div>

                        <div class="row">
                            <div class="form-item col-12">
                                <input type="password" name="password" id="new_password" class="flex-label" minlength="8" autocomplete="off" required="">
                                <label for="new_password">رمز عبور جدید</label>
                                <span class="error-input">رمز عبور را حداقل ۸ کاراکتر وارد کنید .</span>
                            </div>
                        </div>

                        <div class="row">
                            <div class="form-item col-12">
                                <input type="password" name="repassword" id="renewpassword" class="flex-label" minlength="8" autocomplete="off" required="">
                                <label for="renewpassword">تکرار رمز عبور</label>
                                <span class="error-input">تکرار رمز عبور را حداقل ۸ کاراکتر وارد کنید .</span>
                            </div>
                        </div>


                        <div class="row pt-3">
                            <div class="col-12">
                                <button class="shabesh-button w-100 green submit-button  submit-form ">تغییر رمز</button>
                            </div>
                        </div>

                    </form>
                </div>



                <div class="auth-container register-code" style="display: none;">
                    <div class="auth-head">

                        <span>
                            <i class="sh-user"></i>
                            ورود / ثبت نام
                        </span>
                    </div>

                    <form class="auth-form" data-submit="register/confirm">
                        <div class="row text-center auth-title">
                            لطفاً کد ارسال شده به تلفن همراه خود را وارد کنید
                        </div>
                        <div class="row">
                            <div class="form-item col-12 mb-2">
                                <input type="text" name="mobile" id="register_mobile" class="flex-label" required="" readonly="">
                                <label for="register_mobile" class="fixed">شماره موبایل</label>
                                <span class="error-input">شماره موبایل خود را وارد نمایید</span>
                            </div>
                        </div>

                        <div class="row">
                            <div class="form-item col-12 mb-2">
                                <input type="text" name="code" id="register_code" class="flex-label" minlength="6" maxlength="6" required="">
                                <label for="register_code">کد ارسالی</label>
                                <span class="error-input">کد ۶ رقمی را وارد نمایید</span>
                            </div>
                        </div>

                        <div class="row pt-3">
                            <div class="col-12">
                                <button type="submit" class="shabesh-button green w-100 auth-button submit-button submit-form ">ادامه</button>
                            </div>
                        </div>
                        <input type="hidden" name="reg_id" id="register_id">

                        <div class="row">
                            <div class="col-12 text-center resend-timer py-2">
                                <span class="timer-span">60</span>
                                <span class="resend-span resend-register">ارسال مجدد</span>
                            </div>
                        </div>

                    </form>

                </div>


                <div class="auth-container register-container" style="display: none;">
                    <div class="auth-head">

                        <span>
                            <i class="sh-user"></i>
                            ورود / ثبت نام
                        </span>
                    </div>

                    <form class="auth-form" data-submit="register/register">

                        <div class="form-group">
                            <div class="custom-control initial-position custom-radio d-inline-block">
                                <input name="type" type="radio" class="custom-control-input" id="for-user" value="User" required="">
                                <label class="custom-control-label" for="for-user">
                                    شخصی
                                </label>
                                <span class="error-input abs-input">نوع کاربری را انتخاب کنید .</span>
                            </div>

                            <div class="custom-control custom-radio d-inline-block">
                                <input name="type" type="radio" class="custom-control-input" id="for-agent" value="Agent" required="">
                                <label class="custom-control-label" for="for-agent">
                                    مشاور املاک
                                </label>
                            </div>

                            <div class="custom-control custom-radio d-inline-block">
                                <input name="type" type="radio" class="custom-control-input" id="for-agency" value="Agency" required="">
                                <label class="custom-control-label" for="for-agency">
                                    آژانس املاک
                                </label>
                            </div>
                        </div>

                        <div class="row">
                            <div class="form-item col-12 mb-2">
                                <input type="text" class="flex-label" name="name" id="register_name" data-errormessage-value-missing="نام و نام خانوادگی را وارد نمایید" required="">
                                <label for="register_name">نام و نام خانوادگی</label>
                                <span class="error-input">نام و نام خانوادگی را وارد کنید .</span>
                            </div>
                        </div>

                        <div class="row">
                            <div class="form-item col-12 mb-2">
                                <input type="text" class="flex-label" name="email" id="register_email" required="">
                                <label for="register_email">ایمیل</label>
                                <span class="error-input">پست الکترونیک را وارد کنید .</span>
                            </div>
                        </div>

                        <div class="row for-agency hidden">
                            <div class="form-item col-12 mb-2">
                                <input type="text" class="flex-label agency-required" name="nationalcode" id="nationalcode">
                                <label for="nationalcode">کد ملی</label>
                                <span class="error-input">کد ملی را وارد کنید .</span>
                            </div>
                        </div>

                        <div class="row for-agency hidden">
                            <div class="form-item col-12 mb-2">
                                <input type="text" class="flex-label agency-required" name="agency_code" id="agency_code">
                                <label for="agency_code">کد صنفی</label>
                                <span class="error-input">کد صنفی را وارد کنید .</span>
                            </div>
                        </div>

                        <div class="row for-agent hidden">
                            <div class="form-item col-12 mb-2">
                                <input type="text" class="flex-label agent-required" name="agency_name" id="agency_name">
                                <label for="agency_name">نام آژانس</label>
                                <span class="error-input">نام آژانس را وارد کنید .</span>
                            </div>
                        </div>

                        <div class="row for-agency hidden">
                            <div class="form-item col-12 mb-2">
                                <input type="text" class="flex-label" name="phone" id="agency_phone">
                                <label for="agency_phone">تلفن تماس</label>
                            </div>
                        </div>

                        <div class="row for-agency hidden">
                            <div class="form-item col-12 mb-2">
                                <input type="text" class="flex-label" name="address" id="agency_address">
                                <label for="agency_address">آدرس آژانس</label>
                            </div>
                        </div>

                        <div class="row">
                            <div class="form-item col-12 mb-2">
                                <input type="password" id="reg_password" name="password" class="flex-label" minlength="8" autocomplete="off" required="">
                                <label for="reg_password">رمز عبور</label>
                                <span class="error-input">رمز عبور را حداقل ۸ کاراکتر وارد نمایید</span>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-12">
                                <button type="submit" class="shabesh-button green w-100 auth-button submit-button submit-form ">ثبت اطلاعات</button>
                            </div>
                        </div>
                        <input type="hidden" name="reg_id" id="reg_id">
                        <input type="hidden" name="mobile" id="reg_mobile">
                        <input type="hidden" name="verify_code" id="reg_code">
                    </form>

                </div>

                <div class="row login-message mb-3 hidden">
                    <div class="col-12">
                        <span></span>
                        <i class="sh-quit"></i>
                    </div>
                </div>

            </div>



        </div>
    </div>
</div>

</div><!--/.l-main-->




<script type="text/javascript" async="" src="{{env('APP_URL')}}/build/presalebuild/f.txt"></script><script async="" src="{{env('APP_URL')}}/build/presalebuild/analytics.js.download"></script> 




<script src="{{env('APP_URL')}}/build/presalebuild/jquery.js.download"></script>
<script defer="" src="{{env('APP_URL')}}/build/presalebuild/base.js.download"></script>
<script defer="" src="{{env('APP_URL')}}/build/presalebuild/app.js.download"></script>
  
<script defer="" type="text/javascript">
    </script>

<script defer="">
    (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
                (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
            m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
    })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
    ga('create', 'UA-85204224-1', 'auto');
    ga('send', 'pageview');
</script>
<!-- Global site tag (gtag.js) - AdWords: 937169138 -->
<script async="" src="{{env('APP_URL')}}/build/presalebuild/js"></script>
<script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());

    gtag('config', 'AW-937169138');
</script>
 

<div id="lightboxOverlay" class="lightboxOverlay" style="display: none;"></div><div id="lightbox" class="lightbox" style="display: none;"><div class="lb-outerContainer"><div class="lb-container"><img class="lb-image" src="data:image/gif;base64,R0lGODlhAQABAIAAAP///wAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw=="><div class="lb-nav"><a class="lb-prev" href="#"></a><a class="lb-next" href="#"></a></div><div class="lb-loader"><a class="lb-cancel"></a></div></div></div><div class="lb-dataContainer"><div class="lb-data"><div class="lb-details"><span class="lb-caption"></span><span class="lb-number"></span></div><div class="lb-closeContainer"><a class="lb-close"></a></div></div></div></div><script src="{{env('APP_URL')}}/build/presalebuild/f(1).txt"></script></body></html>
 
 
        