
@extends('ajency.layoutajency')

@section('title')
<title>فعالسازی اکانت  </title>
@stop

 
@section('superadmin')
       
@foreach ($admins as $admin)  



<section class="content">  
 
      <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">فعالسازی ایمیل </h3>
              <div class="box-tools pull-right">
                <button class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse"><i class="fa fa-minus"></i></button>
                <button class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove"><i class="fa fa-times"></i></button>
              </div>
            </div>           
@if ($admin->ajency_emailactive == '0') 
<div class="box-body">
    <div class="col-lg-4 col-xs-12">             
ایمیل من:<b>{{$admin->ajency_email}}</b> </div>
  <div class="col-lg-4 col-xs-12">
  
  {!! Form::open([ 'route' => [ 'emailajencyactivitionverfy' ], 'files' => true, 'enctype' => 'multipart/form-data' ]) !!}         
  
   
  <input  type="hidden" class="form-control" name="email" value="{{$admin->ajency_email}}" maxlength="44"    />
  <button  class="btn btn-flickr pull-right"><i class="fa fa-credit-card"></i>ارسال کد ورفای به ایمیل</button> 
               </br> </br>   
                	@if(count($errors))
			<div class="alert alert-danger">
		
				<strong>اخطار!</strong> لطفا بررسی نمایید
				<br/>
				<ul>
					@foreach($errors->all() as $error)
					<li>{{ $error }}</li>
					@endforeach
				</ul>
			</div>
		@endif
  
  {!! Form::close() !!} 
  <div id="re"></div>
  </div>  
 <div class="col-lg-4 col-xs-12"> 
   
  {!! Form::open([ 'route' => [ 'emailajencyactivition' ], 'files' => true, 'enctype' => 'multipart/form-data' ]) !!}         
   

<div class="input-group">
                    <div class="input-group-btn">
                      <button  class="btn btn-danger">فعالسازی ایمیل</button>
                    </div><!-- /btn-group -->
 <input  type="text"  name="codemail"  class="form-control" placeholder="کدفعالسازی">
                  </div><!-- /input-group --></br></br></br>
                              </br> </br>   
               	@if(count($errors))
			<div class="alert alert-danger">
		
				<strong>اخطار!</strong> لطفا بررسی نمایید
				<br/>
				<ul>
					@foreach($errors->all() as $error)
					<li>{{ $error }}</li>
					@endforeach
				</ul>
			</div>
		@endif
  
  {!! Form::close() !!} 
  <div id="rea"></div>
</div>
</div>
@elseif ($admin->ajency_emailactive == '1')  
<div class="box-body">
<div class="col-lg-4 col-xs-12">             
ایمیل من:<b>{{$admin->ajency_email}}</b> </div>
<div class="col-lg-8 col-xs-12"> 
<div class="callout callout-success">
                    <h4>فعالسازی ایمیل</h4> 
</div> 
</div>
<br>
</div>
@endif
</div>
   
    
    
    
    
       		     
      <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">فعالسازی تلفن همراه</h3>
              <div class="box-tools pull-right">
                <button class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse"><i class="fa fa-minus"></i></button>
                <button class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            
            
@if ($admin->ajency_tellactive == '0')

<div class="box-body">
 <div class="col-lg-4 col-xs-12">             
تلفن من:<b>{{$admin->ajency_tell}}</b> </div>

  <div class="col-lg-4 col-xs-12"> 
   
  {!! Form::open([ 'route' => [ 'tellajencyactivitionverfy' ], 'files' => true, 'enctype' => 'multipart/form-data' ]) !!} 
  <input  type="hidden" class="form-control" name="tell" value="{{$admin->ajency_tell}}" maxlength="44"  placeholder="عنوان سایت را وارد نمایید..." />
  <button  class="btn btn-microsoft pull-right"><i class="fa fa-credit-card"></i>ارسال کد ورفای به شماره همراه  </button>
  
   </br> </br>   
                                  	@if(count($errors))
			<div class="alert alert-danger">
		
				<strong>اخطار!</strong> لطفا بررسی نمایید
				<br/>
				<ul>
					@foreach($errors->all() as $error)
					<li>{{ $error }}</li>
					@endforeach
				</ul>
			</div>
		@endif
  
  
  
  {!! Form::close() !!} 
  
  
  <div id="res"></div>
  </div>  
   
<div class="col-lg-4 col-xs-12">  

  {!! Form::open([ 'route' => [ 'tellajencyactivition' ], 'files' => true, 'enctype' => 'multipart/form-data' ]) !!}         
   

<div class="input-group">
                    <div class="input-group-btn">
                      <button class="btn btn-facebook">فعالسازی تلفن همراه	</button>
                    </div><!-- /btn-group -->
 <input  type="text"  name="codtell"  class="form-control" placeholder="کدفعالسازی ">
                  </div><!-- /input-group -->
                  
   </br> </br>   
                       	@if(count($errors))
			<div class="alert alert-danger">
		
				<strong>اخطار!</strong> لطفا بررسی نمایید
				<br/>
				<ul>
					@foreach($errors->all() as $error)
					<li>{{ $error }}</li>
					@endforeach
				</ul>
			</div>
		@endif
  
  
  {!! Form::close() !!} 
  
  
  <div id="reas"></div>
</div>
<br>
 </div>
 
 @elseif ($admin->ajency_tellactive == '1')             

<div class="box-body"> 
    <div class="col-lg-4 col-xs-12">             
شماره همراه من:<b>{{$admin->ajency_tell}}</b> </div>

  <div class="col-lg-8 col-xs-12"> 
  
  <div class="callout callout-success">
                    <h4>فعالسازی تلفن</h4> 
                  </div> 

</div>

<br>



            </div><!-- /.box-body -->
    @endif     
          </div> 
          
       
 
 
 
 
 
 
  
     
       
       
     
     			     
      <div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">فعالسازی</h3>
              <div class="box-tools pull-right">
                <button class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse"><i class="fa fa-minus"></i></button>
                <button class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove"><i class="fa fa-times"></i></button>
              </div>
            </div>
            <div class="box-body">

  
    <div class="col-lg-2 col-xs-12">    </div>
 @if ($admin->ajency_active == '0') 
  <div class="col-lg-8 col-xs-12"> 
 <div class="callout callout-warning">
 
 
                    <h4>غیرفعال</h4>
                   
                      <p>لطفا نسبت به فعالسازی شماره همراه و ایمیل اقدام نمایید    </p>
                      
                  </div>
                  </br>
                 
  </div> 
  
   @elseif ($admin->ajency_active == '1')
   
    <div class="col-lg-8 col-xs-12">
  
  <div class="callout callout-success">  
                    <h4>فعال </h4>
                  </div>
  </div>   
  @endif
    
 <div class="col-lg-2 col-xs-12">  </div>

<br>



            </div> 
           
          </div> 
    
 

                </section>


         
   @endforeach      

@stop

